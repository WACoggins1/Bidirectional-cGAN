"""
Build the final presentation deck.

SHAPE OF THE TALK. The final is not the midterm. Fourteen minutes split
2 / 10 / 2: two minutes of recap, TEN MINUTES OF LIVE CODE WALKTHROUGH, two
minutes of questions. So this deck is deliberately thin. It carries the recap,
the two mandatory accountability slides, the results you cannot show by
scrolling through source, and the disclosure slide. Everything else happens in
the editor.

A twenty-slide deck would be a mistake here: you would spend the walkthrough
budget reading slides, and the rubric's largest single item (25%) is the
walkthrough itself.

NOTHING IS TYPED BY HAND. Every number is read from outputs/results/*.json.
Missing evidence renders as an orange TODO card naming the script that fills
it, so you can build the deck early and watch it fill in.

Run:
    python scripts/14_build_final_deck.py --author "Anthony Coggins" \
                                          --date "November 2026"
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import config

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# ---------------------------------------------------------------- palette
INK = RGBColor(0x14, 0x18, 0x24)
INK_2 = RGBColor(0x44, 0x47, 0x4D)
MUTED = RGBColor(0x6B, 0x72, 0x80)
BLUE = RGBColor(0x25, 0x63, 0xEB)
GREEN = RGBColor(0x0F, 0x9D, 0x58)
ORANGE = RGBColor(0xE8, 0x59, 0x0C)
RED = RGBColor(0xD3, 0x3B, 0x3B)
PAPER = RGBColor(0xFA, 0xFA, 0xFA)
CARD = RGBColor(0xF1, 0xF4, 0xF8)
CARD_WARN = RGBColor(0xFD, 0xF1, 0xE6)
CARD_GOOD = RGBColor(0xEC, 0xF7, 0xF0)
CARD_BAD = RGBColor(0xFD, 0xEC, 0xEC)
DARK = RGBColor(0x0E, 0x17, 0x2A)

W, H = Inches(13.333), Inches(7.5)
MARGIN = Inches(0.62)
CONTENT_W = W - 2 * MARGIN

FIG = config.FIGURE_DIR
RES = config.RESULTS_DIR


# ---------------------------------------------------------------- helpers
def jload(name: str):
    p = RES / name
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return None


def fig(name: str) -> Path | None:
    p = FIG / name
    return p if p.exists() else None


def num(v, fmt="{:.3f}", dash="—"):
    """Format a value that may legitimately be absent. 0.0 is NOT absent."""
    if v is None:
        return dash
    try:
        if isinstance(v, float) and (v != v):      # NaN
            return dash
        return fmt.format(v)
    except (TypeError, ValueError):
        return str(v)


def blank(prs):
    return prs.slides.add_slide(prs.slide_layouts[6])


def bg(slide, color=PAPER):
    r = slide.shapes.add_shape(1, 0, 0, W, H)
    r.fill.solid(); r.fill.fore_color.rgb = color
    r.line.fill.background()
    r.shadow.inherit = False
    slide.shapes._spTree.remove(r._element)
    slide.shapes._spTree.insert(2, r._element)
    return r


def textbox(slide, x, y, w, h, text, size=14, bold=False, color=INK,
            align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, space_after=6,
            line_spacing=1.0):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    lines = text.split("\n") if isinstance(text, str) else list(text)
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(space_after)
        p.line_spacing = line_spacing
        run = p.add_run(); run.text = line
        run.font.size = Pt(size); run.font.bold = bold
        run.font.color.rgb = color
        run.font.name = "Calibri"
    return tb


def eyebrow(slide, text, color=BLUE):
    textbox(slide, MARGIN, Inches(0.42), CONTENT_W, Inches(0.3),
            text.upper(), size=11.5, bold=True, color=color)


def title(slide, text, sub=None):
    textbox(slide, MARGIN, Inches(0.74), CONTENT_W, Inches(0.62),
            text, size=29, bold=True, color=INK)
    if sub:
        textbox(slide, MARGIN, Inches(1.36), CONTENT_W, Inches(0.34),
                sub, size=13.5, color=MUTED)


def card(slide, x, y, w, h, fill=CARD, accent=None):
    r = slide.shapes.add_shape(1, x, y, w, h)
    r.fill.solid(); r.fill.fore_color.rgb = fill
    r.line.fill.background()
    r.shadow.inherit = False
    if accent:
        bar = slide.shapes.add_shape(1, x, y, Emu(int(Inches(0.045))), h)
        bar.fill.solid(); bar.fill.fore_color.rgb = accent
        bar.line.fill.background(); bar.shadow.inherit = False
    return r


def todo(slide, x, y, w, h, what, script):
    card(slide, x, y, w, h, CARD_WARN, ORANGE)
    textbox(slide, x + Inches(0.26), y + Inches(0.18), w - Inches(0.5), h - Inches(0.3),
            [f"NOT YET GENERATED — {what}", f"Run:  {script}"],
            size=12.5, bold=True, color=ORANGE, space_after=5)


def picture(slide, path: Path, x, y, max_w, max_h):
    """Fit an image inside a box without distorting it."""
    from PIL import Image
    iw, ih = Image.open(path).size
    scale = min(max_w / iw, max_h / ih)
    w, h = int(iw * scale), int(ih * scale)
    slide.shapes.add_picture(str(path), int(x + (max_w - w) / 2),
                             int(y + (max_h - h) / 2), w, h)


def table(slide, x, y, w, rows, col_w=None, header=True, row_h=Inches(0.36),
          size=12):
    n_r, n_c = len(rows), len(rows[0])
    shp = slide.shapes.add_table(n_r, n_c, x, y, w, row_h * n_r)
    t = shp.table
    if col_w:
        total = sum(col_w)
        for i, cw in enumerate(col_w):
            t.columns[i].width = Emu(int(w * cw / total))
    for ri, row in enumerate(rows):
        t.rows[ri].height = row_h
        for ci, val in enumerate(row):
            cell = t.cell(ri, ci)
            cell.text = str(val)
            cell.margin_left = Inches(0.1); cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.03); cell.margin_bottom = Inches(0.03)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.fill.solid()
            cell.fill.fore_color.rgb = (CARD if (header and ri == 0)
                                        else PAPER if ri % 2 else RGBColor(0xF7, 0xF8, 0xFA))
            p = cell.text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT if ci == 0 else PP_ALIGN.RIGHT
            for run in p.runs:
                run.font.size = Pt(size)
                run.font.bold = bool(header and ri == 0)
                run.font.color.rgb = INK if (header and ri == 0) else INK_2
                run.font.name = "Calibri"
    return shp


def notes(slide, text: str):
    slide.notes_slide.notes_text_frame.text = text.strip()


def footer(slide, text):
    textbox(slide, MARGIN, H - Inches(0.52), CONTENT_W, Inches(0.3),
            text, size=10, color=MUTED)


# ---------------------------------------------------------------- slides
def s_title(prs, author, date):
    s = blank(prs); bg(s, DARK)
    textbox(s, MARGIN, Inches(1.9), CONTENT_W, Inches(0.3),
            "ADVANCED COMPUTER VISION & DEEP LEARNING  ·  FINAL",
            size=12, bold=True, color=RGBColor(0x60, 0xA5, 0xFA))
    textbox(s, MARGIN, Inches(2.3), CONTENT_W, Inches(0.9),
            "AerialCartographer", size=42, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    textbox(s, MARGIN, Inches(3.25), CONTENT_W, Inches(0.5),
            "What the map metric cannot see",
            size=18, color=RGBColor(0xCB, 0xD5, 0xE1))
    bar = s.shapes.add_shape(1, MARGIN, Inches(3.95), Inches(0.9), Inches(0.05))
    bar.fill.solid(); bar.fill.fore_color.rgb = BLUE
    bar.line.fill.background(); bar.shadow.inherit = False
    textbox(s, MARGIN, Inches(4.3), CONTENT_W, Inches(0.9),
            [author, f"Dr. Cruz  ·  {date}"],
            size=14, color=RGBColor(0x94, 0xA3, 0xB8), space_after=4)
    notes(s, """
TIMING: 14 minutes total, hard cut. 2 recap / 10 code walkthrough / 2 Q&A.
Start the clock now. The walkthrough is the biggest rubric item (25%) and the
one thing you cannot rush -- so do not spend more than 2 minutes before you
open the editor.
""")
    return s


def s_recap(prs):
    s = blank(prs); bg(s)
    eyebrow(s, "recap · 2 minutes")
    title(s, "Where the midterm left this",
          "Paired satellite → map translation with a conditional GAN, on one consumer GPU.")

    y = Inches(1.95)
    cw = (CONTENT_W - Inches(0.5)) / 2

    card(s, MARGIN, y, cw, Inches(2.5), CARD, BLUE)
    textbox(s, MARGIN + Inches(0.3), y + Inches(0.22), cw - Inches(0.6), Inches(0.3),
            "ESTABLISHED AT THE MIDTERM", size=11.5, bold=True, color=BLUE)
    textbox(s, MARGIN + Inches(0.3), y + Inches(0.62), cw - Inches(0.6), Inches(1.8),
            ["Pipeline built; every preprocessing choice measured, not assumed",
             "Split stratified on scene composition; leakage audited by pHash",
             "Ten-configuration ablation, one variable per row",
             "Finding: the reported metric and road structure disagree (r = +0.28)"],
            size=12.5, color=INK_2, space_after=9)

    card(s, MARGIN + cw + Inches(0.5), y, cw, Inches(2.5), CARD_WARN, ORANGE)
    textbox(s, MARGIN + cw + Inches(0.8), y + Inches(0.22), cw - Inches(0.6), Inches(0.3),
            "WHAT WAS STILL OPEN", size=11.5, bold=True, color=ORANGE)
    textbox(s, MARGIN + cw + Inches(0.8), y + Inches(0.62), cw - Inches(0.6), Inches(1.8),
            ["No full-length training run — 12-epoch ablations only",
             "Test split never opened",
             "Metric claim rested on a tolerance I had not traced to a source",
             "No error analysis, no synthesis-direction metric"],
            size=12.5, color=INK_2, space_after=9)

    textbox(s, MARGIN, Inches(4.75), CONTENT_W, Inches(0.8),
            "The extension I proposed was to close all four. The next two slides "
            "are the accounting.",
            size=14, bold=True, color=INK)
    notes(s, """
SAY (45 seconds, no more):
"At the midterm I had a working pipeline, measured preprocessing, an audited
split, and a ten-row ablation. The finding was that pixel accuracy and road
structure disagree. What I did NOT have was a full training run, a test-set
number, or a source for the tolerance my claim depended on. Those were the
extension. Here's the accounting."

Then go straight to the next slide. Do not narrate the bullets.
""")
    return s


def s_commitments(prs, status: list[dict]):
    s = blank(prs); bg(s)
    eyebrow(s, "midterm commitments · 20% of the final grade")
    title(s, "Promised at the midterm → delivered",
          "Every item from the midterm status slide, with where to find it.")

    rows = [["Committed to at the midterm", "Status", "Where"]]
    for it in status:
        rows.append([it["promise"], it["status"], it["where"]])
    shp = table(s, MARGIN, Inches(2.0), CONTENT_W, rows,
                col_w=[0.44, 0.18, 0.38], row_h=Inches(0.42), size=11.5)

    # Colour the status column by outcome so the slide reads at a glance.
    t = shp.table
    for ri, it in enumerate(status, start=1):
        cell = t.cell(ri, 1)
        c = (GREEN if it["status"].startswith("Done")
             else ORANGE if it["status"].startswith("Partial")
             else RED)
        cell.fill.solid()
        cell.fill.fore_color.rgb = (CARD_GOOD if c == GREEN
                                    else CARD_WARN if c == ORANGE else CARD_BAD)
        for p in cell.text_frame.paragraphs:
            for run in p.runs:
                run.font.color.rgb = c
                run.font.bold = True

    notes(s, """
SAY (30 seconds): "Six commitments. Four done, [N] partial, and I'll be
explicit about why." Then NAME the partial ones and give the reason in one
sentence each. Do not read the table.

The rubric says the promised extension must be implemented. A 'Partial' row
with an honest reason scores better than a 'Done' you cannot defend when they
open the code.
""")
    return s


def s_feedback(prs, fb: dict | None):
    s = blank(prs); bg(s)
    eyebrow(s, "midterm commitments · 20%")
    title(s, "Feedback received → what I changed")

    if not fb or not fb.get("comments") or any(
            "REPLACE ME" in str(c.get("comment", "")) for c in fb["comments"]):
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(2.0),
             "the instructor's midterm comments are not filled in",
             "edit midterm_feedback.json, then rebuild this deck")
        textbox(s, MARGIN, Inches(4.35), CONTENT_W, Inches(1.4),
                ["The rubric is explicit: “List each comment and show what you "
                 "changed in response. Feedback that is not addressed will cost marks.”",
                 "",
                 "If no written comments were given, say so on this slide and list "
                 "what you took from the conversation instead. An empty slide is "
                 "worse than an honest one."],
                size=13, color=INK_2, space_after=8)
        notes(s, """
THIS SLIDE IS NOT FINISHED. Edit midterm_feedback.json and rebuild.
This is a mandatory rubric item inside the 20% Midterm Commitments block.
""")
        return s

    rows = [["Comment received", "What I changed", "Evidence"]]
    for c in fb["comments"]:
        rows.append([c.get("comment", ""), c.get("response", ""),
                     c.get("evidence", "")])
    table(s, MARGIN, Inches(2.0), CONTENT_W, rows,
          col_w=[0.34, 0.42, 0.24], row_h=Inches(0.52), size=11)

    if fb.get("no_comments_note"):
        textbox(s, MARGIN, H - Inches(1.1), CONTENT_W, Inches(0.5),
                fb["no_comments_note"], size=12, color=MUTED)
    notes(s, """
SAY (30 seconds): walk the rows left to right, one sentence each. "They said X,
I did Y, it's in Z." Then move on.

Do not get defensive about any comment. 'They were right, here's the fix' is
the strongest possible delivery of this slide.
""")
    return s


def s_noise_floor(prs, nf: dict | None):
    s = blank(prs); bg(s)
    eyebrow(s, "midterm commitments \u00b7 20%  \u00b7  feedback item")
    title(s, "Applying the noise floor to every delta",
          "\u201cApply the same noise floor to your preprocessing/augmentation "
          "deltas.\u201d  Done \u2014 and it cost me a claim.")

    if nf is None:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.6),
             "noise-floor analysis not run", "python scripts/15_noise_floor.py")
        notes(s, "Run scripts/15_noise_floor.py. This slide answers the one "
                 "actionable item in the midterm feedback.")
        return s

    p = fig("15_noise_floor.png")
    if p:
        picture(s, p, MARGIN, Inches(1.95), CONTENT_W, Inches(4.35))

    aug = next((c for c in nf["configs"] if c["tag"] == "A1_noaug"), None)
    line = ""
    if aug and aug["verdict"] == "unresolved on both":
        dp = aug["metrics"]["pixel_accuracy"]["delta"] * 100
        line = (f"Augmentation moves pixel accuracy {dp:+.2f} pp against a "
                f"{nf['bands']['pixel_accuracy']['band']*100:.2f} pp floor \u2014 "
                f"unresolved. My midterm slide \u201caugmentation earns its "
                f"place\u201d overstated the evidence.")
    textbox(s, MARGIN, Inches(6.45), CONTENT_W, Inches(0.8), line,
            size=13, bold=True, color=INK, line_spacing=1.12)
    notes(s, """
SAY (40 seconds): "The one change they asked for was to apply my seed-noise
floor to the preprocessing and augmentation rows, not just to ResNet-9. Fair
hit -- I'd used rigour selectively. Here it is applied uniformly."

Then the cost: "It cost me a claim. Augmentation moves pixel accuracy by 1.3
points against a 3.25-point floor. Unresolved. My midterm slide said
augmentation earns its place -- that overstated what I had."

Then the payoff: "And it produced something. A bilinear map resize, which I
showed damages road structure before training even starts, IMPROVES pixel
accuracy by 4.9 points and clears the floor. The metric rewards the
preprocessing choice that wrecks the cartography."

That last line is the strongest single sentence in the talk. Do not rush it.
""")
    return s


def s_walkthrough_map(prs, order: list[tuple[str, str, str]]):
    s = blank(prs); bg(s)
    eyebrow(s, "implementation & code walkthrough · 25% — 10 minutes")
    title(s, "What I'm about to show you",
          "The order I'll open these in, and the one decision each file exists to make.")

    rows = [["File", "The decision it owns", "~time"]]
    for f, d, t in order:
        rows.append([f, d, t])
    table(s, MARGIN, Inches(2.0), CONTENT_W, rows,
          col_w=[0.28, 0.58, 0.14], row_h=Inches(0.44), size=11.5)

    textbox(s, MARGIN, H - Inches(1.15), CONTENT_W, Inches(0.6),
            "Submitted code is exactly what is on screen — same commit, no edits after submission.",
            size=13, bold=True, color=BLUE)
    notes(s, """
SAY (20 seconds): "Here's the route. Six files, ten minutes." Then SWITCH TO
THE EDITOR and do not come back to slides until the results section.

This slide exists so they can follow your navigation. Leave it up for a beat,
then switch. Have the editor already open on config.py behind the slides --
alt-tab, do not fumble with file explorers on the clock.
""")
    return s


def s_test_results(prs, te: dict | None, direction="sat2map"):
    s = blank(prs); bg(s)
    eyebrow(s, "results & analysis · 20%")
    title(s, "Held-out test set — opened once, at the end")

    if te is None:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.6),
             "no test-set evaluation yet",
             f"python scripts/09_test_eval.py --direction {direction}")
        notes(s, "Run 09_test_eval.py. This is a mandatory rubric item.")
        return s

    m, b = te["model"], te["baselines"]["constant_colour"]
    rows = [["", "Our model", "Blank tile", "Verdict"]]
    for key, label, fmt in (("pixel_accuracy_d5", "Pixel accuracy, δ = 5", "{:.2%}"),
                            ("pixel_accuracy_d20", "Pixel accuracy, δ = 20", "{:.2%}"),
                            ("road_iou", "Road IoU", "{:.4f}"),
                            ("ssim", "SSIM", "{:.3f}"),
                            ("psnr", "PSNR (dB)", "{:.2f}")):
        mv, bv = m.get(key), b.get(key)
        verdict = "—"
        if mv is not None and bv is not None:
            verdict = "model wins" if mv > bv else "blank tile wins"
        rows.append([label, num(mv, fmt), num(bv, fmt), verdict])

    shp = table(s, MARGIN, Inches(2.0), Inches(8.5), rows,
                col_w=[0.36, 0.2, 0.2, 0.24], row_h=Inches(0.44), size=11.5)
    t = shp.table
    for ri in range(1, len(rows)):
        txt = rows[ri][3]
        if txt == "—":
            continue
        cell = t.cell(ri, 3)
        c = GREEN if txt == "model wins" else RED
        cell.fill.solid()
        cell.fill.fore_color.rgb = CARD_GOOD if c == GREEN else CARD_BAD
        for p in cell.text_frame.paragraphs:
            for run in p.runs:
                run.font.color.rgb = c; run.font.bold = True

    x = MARGIN + Inches(8.8)
    cw = CONTENT_W - Inches(8.8)
    card(s, x, Inches(2.0), cw, Inches(3.1), CARD, BLUE)
    sel = te.get("selection", {})
    textbox(s, x + Inches(0.26), Inches(2.18), cw - Inches(0.5), Inches(0.3),
            "NO TEST-SET LEAKAGE", size=11.5, bold=True, color=BLUE)
    textbox(s, x + Inches(0.26), Inches(2.56), cw - Inches(0.5), Inches(1.7),
            [f"Selected: {sel.get('tag', '?')}",
             (f"Eligible: {len(sel.get('candidates', []))} full-protocol run"
              f"{'' if len(sel.get('candidates', [])) == 1 else 's'}"
              + (f"; {len(sel.get('excluded', []))} shorter runs excluded"
                 if sel.get("excluded") else "")),
             f"Ranked on: {sel.get('selection_key', 'val_road_iou').replace('val_', 'validation ').replace('_', ' ')}",
             f"Test tiles: {te.get('n_test_tiles', '?')}",
             "Test opened after selection, once."],
            size=11.5, color=INK_2, space_after=7)

    # The takeaway line is DERIVED, not asserted. An earlier version hard-coded
    # "road IoU separates model from blank tile", which would have been on the
    # slide even when the numbers said otherwise -- precisely the claim the
    # walkthrough would expose.
    dr = te.get("dynamic_range") or {}
    h5, h20 = dr.get("5") or dr.get(5), dr.get("20") or dr.get(20)
    if h5 and h20 and (h20.get("band") or 0) > 1e-9:
        free = (h20.get("fraction_of_scale_free") or 0) * 100
        ratio = (h5.get("band") or 0) / h20["band"]
        line = (f"At \u03b4 = 20, {free:.0f}% of the score is reachable with no model "
                f"at all \u2014 the usable band is only {h20['band']*100:.1f} points "
                f"wide. At \u03b4 = 5 it is {ratio:.0f}\u00d7 wider. Same metric name, "
                f"same images, different instrument.")
    elif m.get("road_iou") is not None and b.get("road_iou") is not None \
            and m["road_iou"] > b["road_iou"]:
        line = ("Road IoU separates the model from a blank tile without needing "
                "a tolerance at all.")
    else:
        line = ("Per-pixel agreement is the wrong instrument in this direction \u2014 "
                "see the FID slide.")
    textbox(s, MARGIN, Inches(4.75), Inches(8.5), Inches(1.6), line,
            size=13.5, bold=True, color=INK, line_spacing=1.15)
    notes(s, """
SAY: "Test set, opened once, after selection. Here's the table." Then point at
the delta=5 row and the delta=20 row and say: "Same model, same images, same
metric name. Different answer." That's the hand-off to the next slide.

IF ASKED how you avoided leakage: 09_test_eval.py separates selection from
evaluation mechanically -- phase 1 reads val only and records the decision,
phase 2 opens test. The JSON records which tag was selected and on what.
""")
    return s


def s_tolerance(prs, ts: dict | None, te: dict | None = None):
    s = blank(prs); bg(s)
    eyebrow(s, "results & analysis · 20%  ·  the finding")
    title(s, "The metric is a step function of an unspecified parameter")

    if ts is None:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.6),
             "no tolerance sweep yet", "python scripts/11_tolerance_sweep.py")
        return s

    p = fig("11_tolerance_sweep.png")
    if p:
        picture(s, p, MARGIN, Inches(1.85), Inches(8.1), Inches(4.3))

    x = MARGIN + Inches(8.4)
    cw = CONTENT_W - Inches(8.4)
    crit = ts.get("critical_tolerance")
    cross = ts.get("crossover")

    card(s, x, Inches(1.95), cw, Inches(1.55), CARD_BAD, RED)
    textbox(s, x + Inches(0.26), Inches(2.1), cw - Inches(0.5), Inches(1.3),
            [f"Road vs background differ by {num(crit, '{:.0f}')} per channel.",
             f"Any tolerance above {num(crit, '{:.0f}')} scores blank background "
             f"as correct road."],
            size=12, bold=True, color=RED, space_after=7)

    card(s, x, Inches(3.65), cw, Inches(2.5), CARD, BLUE)
    textbox(s, x + Inches(0.26), Inches(3.82), cw - Inches(0.5), Inches(0.3),
            "WHAT THE SOURCE ACTUALLY SAYS", size=11.5, bold=True, color=BLUE)
    textbox(s, x + Inches(0.26), Inches(4.2), cw - Inches(0.5), Inches(1.85),
            ["Aggarwal et al. (2024) report Pix2Pix at 42.09% and describe the "
             "tolerance only as an “error factor of 5”.",
             "No formula. No per-channel statement. No colour scale.",
             f"My midterm used 20. The published numbers and mine are not the "
             f"same measurement."],
            size=11.5, color=INK_2, space_after=8)

    msg = (f"Ranking inverts at δ = {cross}." if cross
           else "No inversion in the swept range.")
    textbox(s, MARGIN, Inches(6.3), Inches(8.1), Inches(0.7),
            f"{msg}  The literature does not state which side of "
            f"{num(crit, '{:.0f}')} its numbers were computed on.",
            size=13, bold=True, color=INK)
    notes(s, """
THIS IS THE SLIDE. Spend 60-75 seconds here, more than any other results slide.

SAY: "At the midterm I said this metric was degenerate. That was half right and
I had not traced it to a source. Here's what I found. The survey I cite reports
Pix2Pix at 42 percent and defines its tolerance as -- quote -- an error factor
of 5. No formula. Meanwhile background and road in this dataset differ by 17.
So below 17 the metric sees roads; at and above 17 it doesn't, and a blank tile
wins. I was computing at 20. They may have been computing at 5. Those are
different metrics with the same name, which is why my 79 percent floor and
their 42 percent both exist."

IF ASKED "so was your midterm claim wrong?": "The direction was right, the
grounding wasn't. I'd now state it as a reproducibility problem rather than a
degeneracy claim -- and it's stronger that way, because it's checkable."
""")
    return s


def s_literature(prs, te: dict | None):
    s = blank(prs); bg(s)
    eyebrow(s, "results & analysis · 20%")
    title(s, "Against published numbers on this dataset",
          "Reported at δ = 5, the tolerance the source names.")

    p = fig("09_literature.png")
    if p:
        picture(s, p, MARGIN, Inches(1.9), Inches(7.9), Inches(4.4))

    x = MARGIN + Inches(8.2)
    cw = CONTENT_W - Inches(8.2)
    card(s, x, Inches(2.0), cw, Inches(4.1), CARD_WARN, ORANGE)
    textbox(s, x + Inches(0.26), Inches(2.18), cw - Inches(0.5), Inches(0.3),
            "READ THIS WITH CARE", size=11.5, bold=True, color=ORANGE)
    textbox(s, x + Inches(0.26), Inches(2.58), cw - Inches(0.5), Inches(3.3),
            ["These bars are indicative, not like-for-like.",
             "",
             "The source does not specify its tolerance precisely enough to "
             "reproduce. Mine is computed at δ = 5 because that is the number "
             "the source names — but “error factor of 5” is not a definition.",
             "",
             "Reproducing Pix2Pix within a few points was the stated goal. "
             "Whether that has been achieved depends on a parameter the "
             "literature leaves open, and saying so is the honest result."],
            size=11.5, color=INK_2, space_after=7)
    notes(s, """
SAY (30 seconds): "Target was to reproduce the Pix2Pix row. Here's where I land
at delta 5. And here's the caveat -- I can't claim a like-for-like match
because the protocol isn't specified tightly enough to reproduce."

This slide is where Originality (10%) and Results (20%) overlap. Claiming a
clean match you cannot defend is the failure mode. Saying "the comparison is
not well-posed, and that is itself the finding" is the win.
""")
    return s


def s_error_analysis(prs, ea: dict | None):
    s = blank(prs); bg(s)
    eyebrow(s, "results & analysis · 20%")
    title(s, "Error analysis — which half of the error is it?")

    if ea is None:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.6),
             "no error analysis yet", "python scripts/10_error_analysis.py")
        return s

    p = fig("10_precision_recall.png")
    if p:
        picture(s, p, MARGIN, Inches(1.85), Inches(5.6), Inches(4.5))
    p2 = fig("10_by_stratum.png")
    if p2:
        picture(s, p2, MARGIN + Inches(5.8), Inches(1.85), Inches(6.3), Inches(2.3))

    o = ea.get("overall", {})
    x = MARGIN + Inches(5.8)
    cw = CONTENT_W - Inches(5.8)
    card(s, x, Inches(4.35), cw, Inches(1.85), CARD, BLUE)
    textbox(s, x + Inches(0.26), Inches(4.5), cw - Inches(0.5), Inches(1.6),
            [f"Recall {num(o.get('road_recall'), '{:.3f}')}   "
             f"Precision {num(o.get('road_precision'), '{:.3f}')}   "
             f"IoU {num(o.get('road_iou'), '{:.3f}')}",
             "",
             ea.get("dominant_failure_mode", "")],
            size=12.5, bold=True, color=INK_2, space_after=7)
    notes(s, """
SAY (45 seconds): "Road error has two halves and they have opposite fixes.
Recall is roads I missed. Precision is roads I invented. Averaging them into
one number hides which problem you have. Mine is [recall-limited /
precision-limited], which means [the model omits cartography / the model
smears bright pixels]."

Then the stratum panel: "And it's worst on [X] tiles, which is the cut I
balanced the split on -- so that loop closes."
""")
    return s


def s_fid(prs, fid: dict | None, curves: dict | None,
          tag: str | None = None):
    s = blank(prs); bg(s)
    eyebrow(s, "results & analysis · 20%")
    title(s, "The other direction, and training health")

    half = (CONTENT_W - Inches(0.4)) / 2
    if fid is None:
        todo(s, MARGIN, Inches(2.0), half, Inches(1.5),
             "no FID yet", "python scripts/12_fid.py --direction map2sat")
    else:
        p = fig("12_fid_map2sat.png")
        if p:
            picture(s, p, MARGIN, Inches(1.9), half, Inches(3.0))
        textbox(s, MARGIN, Inches(5.05), half, Inches(1.5),
                ["Map → satellite is synthesis, not abstraction: no single "
                 "output is correct, so per-pixel metrics are the wrong "
                 "instrument. FID compares distributions instead.",
                 f"Model {num(fid.get('fid_model'), '{:.1f}')}   vs "
                 f"sample floor {num(fid.get('fid_real_vs_real_floor'), '{:.1f}')}"],
                size=12, color=INK_2, space_after=8)

    x = MARGIN + half + Inches(0.4)
    # Use the run that was actually selected and reported. An earlier version
    # took sorted(...)[0], which is alphabetical -- that put a 12-epoch
    # ablation (A0_baseline) on the slide under a caption describing the
    # 300-epoch baseline.
    divs = []
    if tag:
        cand = fig("13_divergence_%s.png" % tag)
        if cand:
            divs = [cand]
    if not divs:
        divs = sorted(fig_names_for("13_divergence_"))
    if not divs:
        todo(s, x, Inches(2.0), half, Inches(1.5),
             "no training curves yet", "python scripts/13_training_curves.py")
    else:
        picture(s, divs[0], x, Inches(1.9), half, Inches(3.0))
        line = "Within one run: same model, same seed, same data."
        if curves:
            first = curves.get(tag) or next(iter(curves.values()))
            # Late-phase, not full-run: see late_pct_change() in script 13 for
            # why the full-run number is not evidence of anything.
            di = first.get("road_iou_late_pct_change")
            dp = first.get("pixel_accuracy_late_pct_change")
            if di is not None and dp is not None:
                # A run that converged shows near-zero movement in BOTH metrics.
                # Quoting those percentages as divergence would be reading
                # noise as a finding; say what actually happened instead.
                if abs(di) < 5 and abs(dp) < 5:
                    line = (f"The second half of training moved nothing: road "
                            f"structure {di:+.1f}%, pixel accuracy {dp:+.1f}%. "
                            f"The model had converged — the decay phase added "
                            f"no measurable quality.")
                else:
                    line = (f"Second half of training: road structure {di:+.1f}%, "
                            f"pixel accuracy {dp:+.1f}%. Same seed, same data, "
                            f"no confounds to control for.")
        textbox(s, x, Inches(5.05), half, Inches(1.5), line,
                size=12, bold=True, color=INK_2)
    notes(s, """
SAY (45 seconds, two beats):

FID: "Map to satellite is a different problem -- synthesis, not abstraction.
There's no single right answer, so I measure distributions instead of pixels."

Divergence: "And this is the cleanest version of the whole finding. One run.
Same seed, same data, only more epochs. Structure improves; the reported
metric doesn't move. Nothing to control for."
""")
    return s


def fig_names_for(prefix: str) -> list[Path]:
    return sorted(FIG.glob(f"{prefix}*.png"))


def s_limits(prs, items: list[str]):
    s = blank(prs); bg(s)
    eyebrow(s, "originality · 10%")
    title(s, "What this does not establish",
          "Stated so the Q&A is about the work rather than about what was left out.")
    card(s, MARGIN, Inches(2.0), CONTENT_W, Inches(3.4), CARD_WARN, ORANGE)
    textbox(s, MARGIN + Inches(0.35), Inches(2.22), CONTENT_W - Inches(0.7), Inches(3.0),
            items, size=13, color=INK_2, space_after=12)
    notes(s, """
SAY (20 seconds): "Four things I can't claim." Read them fast. Then stop.

This slide buys you enormous credibility and it pre-empts the hardest Q&A
questions by asking them yourself. Do not apologise while delivering it --
these are scoped limitations, not failures.
""")
    return s


def s_ai_disclosure(prs, text: list[str]):
    s = blank(prs); bg(s)
    eyebrow(s, "academic integrity")
    title(s, "AI-use disclosure")
    card(s, MARGIN, Inches(2.0), CONTENT_W, Inches(3.2), CARD, BLUE)
    textbox(s, MARGIN + Inches(0.35), Inches(2.25), CONTENT_W - Inches(0.7), Inches(2.8),
            text, size=13.5, color=INK_2, space_after=11)
    notes(s, """
MANDATORY SLIDE -- the requirements list it explicitly.

Read it out loud. Do not rush past it; reading it deliberately signals you are
not hiding anything. Then invite questions.

EDIT THE TEXT IN THE SCRIPT so it describes what you actually did. A disclosure
that overstates or understates is worse than none.
""")
    return s


def s_qa(prs):
    s = blank(prs); bg(s, DARK)
    textbox(s, MARGIN, Inches(2.6), CONTENT_W, Inches(0.4), "Q&A",
            size=13, bold=True, color=RGBColor(0x60, 0xA5, 0xFA))
    textbox(s, MARGIN, Inches(3.0), CONTENT_W, Inches(0.9),
            "Questions", size=40, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    textbox(s, MARGIN, Inches(4.1), CONTENT_W, Inches(0.5),
            "Thank you — Dr. Cruz, Mr. Akshay",
            size=15, color=RGBColor(0x94, 0xA3, 0xB8))
    textbox(s, MARGIN, Inches(5.1), CONTENT_W, Inches(0.4),
            "Backup slides follow.", size=12, color=RGBColor(0x64, 0x74, 0x8B))
    notes(s, """
2 minutes. Likely questions and your one-line answers:

Q: Isn't road IoU a metric you invented to flatter yourself?
A: It's not flattering -- at delta 20 my model still loses to a blank tile on
   pixel accuracy. And it reproduces Isola's known L1-blur result, which pixel
   accuracy gets backwards. That's validation against a known answer.

Q: Why delta 5 now when you used 20 before?
A: Because I traced the source. 20 was mine; 5 is what the survey names. I
   report both, and the sweep shows the whole range.

Q: Why is your model worse than published Pix2Pix?
A: Different training budget, and -- more importantly -- the comparison isn't
   well-posed until the protocol is specified. That's the finding.

Q: What would you do next?
A: FCN-score as an independent structural check, more seeds, and a human
   perceptual study.
""")
    return s


def s_backup_ablation(prs, abl):
    s = blank(prs); bg(s)
    eyebrow(s, "backup", MUTED)
    title(s, "Ablation grid (midterm, short runs)")
    if not abl:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.4),
             "no ablation results", "python scripts/04_ablation.py")
        return s
    rows = [["Config", "Pixel acc.", "Road IoU"]]
    for r in abl[:11]:
        sv = r.get("stable_val") or {}
        rows.append([r.get("label") or r.get("tag", "?"),
                     num(sv.get("pixel_accuracy"), "{:.1%}"),
                     num(sv.get("road_iou"), "{:.3f}")])
    table(s, MARGIN, Inches(2.0), Inches(9.0), rows, col_w=[0.5, 0.25, 0.25],
          row_h=Inches(0.36), size=11)
    textbox(s, MARGIN, H - Inches(1.0), CONTENT_W, Inches(0.5),
            "Short runs: they rank options, they do not settle magnitudes.",
            size=12, color=MUTED)
    notes(s, """
Pull this up if asked about the ablation. The line to lead with: every row is
the baseline with exactly one thing changed -- same seed, same epochs, same
data order -- so each gap is attributable to that one change.

If asked why these are short runs: twelve epochs rank options, they do not
settle magnitudes, and running the grid at full length was about twenty GPU
hours I chose to spend on the two full baselines instead.
""")
    return s


def s_backup_worst(prs):
    s = blank(prs); bg(s)
    eyebrow(s, "backup", MUTED)
    title(s, "Worst test tiles, and why they fail")
    p = fig("10_worst_cases.png")
    if p:
        picture(s, p, MARGIN, Inches(1.7), CONTENT_W, Inches(5.2))
    else:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.4),
             "no worst-case gallery", "python scripts/10_error_analysis.py")
    notes(s, """
Pull this up if asked "where does it fail?" -- or volunteer it if Q&A is quiet.

These are the four worst tiles by road IoU, chosen by rank rather than by eye.
Red is road the model missed, orange is road it invented. Showing failures you
selected by a rule is more credible than a gallery of best cases.
""")
    return s


def s_backup_val_test(prs, direction="sat2map"):
    s = blank(prs); bg(s)
    eyebrow(s, "backup", MUTED)
    title(s, "Validation estimate vs held-out test",
          "How much the number moved when the split it had never seen was opened.")
    p = fig(f"09_val_vs_test_{direction}.png")
    if p:
        picture(s, p, MARGIN, Inches(1.9), CONTENT_W, Inches(4.7))
    else:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.4),
             "no val/test comparison", "python scripts/09_test_eval.py")
    notes(s, """
Pull this up if asked how much the validation number overstated things. A small
gap is evidence the selection protocol worked; a large one is worth owning
rather than explaining away.
""")
    return s


def s_backup_crossover(prs):
    s = blank(prs); bg(s)
    eyebrow(s, "backup", MUTED)
    title(s, "The ranking inversion, tolerance by tolerance")
    p = fig("11_crossover.png")
    if p:
        picture(s, p, MARGIN, Inches(1.8), CONTENT_W, Inches(4.8))
    else:
        todo(s, MARGIN, Inches(2.1), CONTENT_W, Inches(1.4),
             "no crossover figure", "python scripts/11_tolerance_sweep.py")
    notes(s, """
The signed gap between model and blank tile at every tolerance. Blue means the
metric prefers the model, red means it prefers a blank image.

Use this if someone pushes on the tolerance finding and wants it tolerance by
tolerance rather than as a curve. The sign flip is the whole argument.
""")
    return s


# ---------------------------------------------------------------- build
def commitment_status(te, ea, fidj, curves, histories) -> list[dict]:
    """
    Derive the promised-vs-delivered table from what is actually on disk.

    Hard-coding "Done" would be exactly the kind of claim the walkthrough
    exposes, so each row is decided by whether its evidence file exists.
    """
    full_runs = [h for h in histories
                 if len(h.get("epochs", [])) >= 100
                 and (h.get("config", {}).get("n_train") or 0) >= 1000]
    sat = [h for h in full_runs if h.get("config", {}).get("direction") == "sat2map"]
    m2s = [h for h in full_runs if h.get("config", {}).get("direction") == "map2sat"]

    def st(ok, partial=False, note_done="Done", note_part="Partial"):
        return note_done if ok else (note_part if partial else "Not done")

    any_sat = [h for h in histories
               if h.get("config", {}).get("direction") == "sat2map"]
    any_m2s = [h for h in histories
               if h.get("config", {}).get("direction") == "map2sat"]

    return [
        {"promise": "Full 200-epoch baseline, satellite → map",
         "status": st(bool(sat), bool(any_sat)),
         "where": (f"{sat[0]['tag']}_history.json" if sat
                   else f"{any_sat[0]['tag']}_history.json (short)" if any_sat
                   else "python -m src.train --direction sat2map --epochs 200")},
        {"promise": "Same again, map → satellite",
         "status": st(bool(m2s), bool(any_m2s)),
         "where": (f"{m2s[0]['tag']}_history.json" if m2s
                   else f"{any_m2s[0]['tag']}_history.json (short)" if any_m2s
                   else "python -m src.train --direction map2sat --epochs 200")},
        {"promise": "Complete the ablation grid at full length",
         "status": "Partial — scoped",
         "where": "10 configs at short length; full length was ~20 GPU-hours"},
        {"promise": "FID for the synthesis direction",
         "status": st(fidj is not None),
         "where": "scripts/12_fid.py → 12_fid_map2sat.json" if fidj
                  else "python scripts/12_fid.py"},
        {"promise": "Error analysis focused on road recall",
         "status": st(ea is not None),
         "where": "scripts/10_error_analysis.py → precision/recall split" if ea
                  else "python scripts/10_error_analysis.py"},
        {"promise": "Results on the held-out test split",
         "status": st(te is not None),
         "where": "scripts/09_test_eval.py — selection and evaluation separated"
                  if te else "python scripts/09_test_eval.py"},
    ]


WALKTHROUGH = [
    ("config.py", "Every path and hyperparameter, in one place — including the "
                  "tolerance this whole project turns on", "0:45"),
    ("src/dataset.py", "Split membership decided before any transform; one crop "
                       "window for both halves", "2:00"),
    ("src/models.py", "U-Net skips, and the discriminator receptive field that "
                      "decides what ‘realistic’ means", "2:00"),
    ("src/metrics.py", "The two metric families, and why road IoU compares masks "
                       "rather than values", "2:00"),
    ("src/train.py", "The GAN update order, detach(), and AMP", "1:45"),
    ("scripts/09_test_eval.py", "Selection and evaluation separated so leakage is "
                                "structurally impossible", "1:30"),
]

LIMITS = [
    "•   Road IoU uses a colour heuristic as a proxy label, not ground truth. "
    "It is validated against a known result (L1 blur), but never checked against "
    "an independent annotation — an FCN-score is the missing piece.",
    "•   One seed per configuration at full length. The ablation has a measured "
    "noise floor; the final runs do not.",
    "•   ~1,100 training pairs is small for a GAN. Augmentation showed no "
    "measurable effect at ablation length, which is a null result, not evidence "
    "of no effect.",
    "•   The comparison with published numbers is not like-for-like, because "
    "the published protocol is not specified tightly enough to reproduce.",
]

# EDIT THIS TO MATCH WHAT YOU WILL DEFEND. A disclosure that understates is
# worse than one that overstates: the rubric penalises work "found to be"
# primarily AI-generated, and being found out is the expensive outcome. The
# draft below is written to be accurate rather than flattering.
AI_DISCLOSURE = [
    "I used Claude (Anthropic) throughout this project, as an assistant and as "
    "a drafting tool. Specifically:",
    "",
    "•   Code — much of the pipeline and all of the evaluation and "
    "figure-generation scripts were drafted in collaboration with Claude. I "
    "specified what each should do, reviewed and corrected the output, ran "
    "everything on my own hardware, and debugged the results.",
    "•   Debugging — an OpenMP runtime clash on Windows, a channel-count bug "
    "in the ResNet upsampling path, and a stdout-buffering issue that made a "
    "healthy run look hung. I also caught and corrected errors in Claude's own "
    "diagnoses.",
    "•   Concepts — CUDA execution model, FID, and evaluation-protocol "
    "questions.",
    "",
    "What is mine: the project direction, the experimental decisions, every "
    "run, and the interrogation that produced the metric finding. I can "
    "explain and defend any line of the submitted code — which is what the "
    "last ten minutes were.",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--author", default="Anthony Coggins")
    ap.add_argument("--date", default="November 2026")
    ap.add_argument("--direction", default="sat2map")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    print("=" * 72)
    print("14  BUILD FINAL DECK")
    print("=" * 72)

    te = jload(f"09_test_eval_{args.direction}.json")
    ea = jload(f"10_error_analysis_{args.direction}.json")
    ts = jload("11_tolerance_sweep.json")
    fidj = jload("12_fid_map2sat.json")
    curves = jload("13_training_curves.json")
    abl = jload("04_ablations.json")
    nf = jload("15_noise_floor.json")
    histories = []
    for p in RES.glob("*_history.json"):
        try:
            histories.append(json.loads(p.read_text()))
        except json.JSONDecodeError:
            pass

    fb = None
    fbp = Path(__file__).parent.parent / "midterm_feedback.json"
    if fbp.exists():
        try:
            fb = json.loads(fbp.read_text())
        except json.JSONDecodeError:
            print("  WARNING: midterm_feedback.json is not valid JSON; ignoring")

    have = {"test eval": te, "error analysis": ea, "tolerance sweep": ts,
            "FID": fidj, "training curves": curves, "ablations": abl,
            "noise floor (feedback item)": nf}
    for k, v in have.items():
        print(f"  {'OK  ' if v else 'MISS'}  {k}")
    print(f"  {'OK  ' if fb and fb.get('comments') and not any('REPLACE ME' in str(c) for c in fb['comments']) else 'MISS'}  midterm feedback (edit midterm_feedback.json)")

    sel_tag = (te or {}).get("selection", {}).get("tag")

    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    s_title(prs, args.author, args.date)
    s_recap(prs)
    s_commitments(prs, commitment_status(te, ea, fidj, curves, histories))
    s_feedback(prs, fb)
    s_noise_floor(prs, nf)
    s_walkthrough_map(prs, WALKTHROUGH)
    s_test_results(prs, te, args.direction)
    s_tolerance(prs, ts, te)
    s_literature(prs, te)
    s_error_analysis(prs, ea)
    s_fid(prs, fidj, curves, sel_tag)
    s_limits(prs, LIMITS)
    s_ai_disclosure(prs, AI_DISCLOSURE)
    s_qa(prs)
    s_backup_ablation(prs, abl)
    s_backup_worst(prs)
    s_backup_crossover(prs)
    s_backup_val_test(prs, args.direction)

    out = Path(args.out) if args.out else (
        Path(__file__).parent.parent / "AerialCartographer_Final.pptx")
    try:
        prs.save(out)
    except PermissionError:
        # PowerPoint holds a lock on an open file. Save beside it rather than
        # losing the build.
        for i in range(2, 20):
            alt = out.with_name(f"{out.stem}_{i}{out.suffix}")
            try:
                prs.save(alt)
                print(f"\n  {out.name} was locked (open in PowerPoint?)")
                print(f"  saved as {alt.name} instead")
                out = alt
                break
            except PermissionError:
                continue
        else:
            raise
    print(f"\n  {len(prs.slides.__iter__.__self__._sldIdLst)} slides -> {out}")
    print("  Every slide has speaker notes. Read them once before presenting.")


if __name__ == "__main__":
    main()
