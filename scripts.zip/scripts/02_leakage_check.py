"""
Train/val/test leakage audit.

Why this matters for THIS dataset specifically: the Maps tiles were scraped
from a contiguous area of Google Maps. Tiles that are geographically adjacent
can share content, and the author-provided train/val partition carries no
guarantee that the two directories cover disjoint ground. If a near-duplicate
of a training tile sits in the test set, the reported test score is inflated
and the split is not measuring generalisation.

So we measure it rather than assume it. Every tile is reduced to a 64-bit
perceptual hash (DCT-based pHash) of its SATELLITE half, and we count pairs
whose Hamming distance falls at or below the duplicate threshold:

  * within each split   -- redundancy, which inflates effective epoch count
  * across split pairs  -- leakage, which invalidates the evaluation

Anything found across a boundary is written to a quarantine list that the
training pipeline can exclude.

Run:  python scripts/02_leakage_check.py [--threshold 5]
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.fftpack import dct

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import SplitManifest, build_splits, load_pair
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS, apply_style,
                           bar_labels, clean_axes, save)

import matplotlib.pyplot as plt


def phash(img: Image.Image, hash_size: int = 8, highfreq_factor: int = 4) -> np.ndarray:
    """
    DCT-based perceptual hash. Returns a boolean array of hash_size**2 bits.

    Implemented directly so the audit does not depend on an extra package.
    Robust to rescaling and mild compression, which is what we need -- we are
    looking for tiles showing the same ground, not byte-identical files.
    """
    size = hash_size * highfreq_factor
    gray = img.convert("L").resize((size, size), Image.LANCZOS)
    a = np.asarray(gray, dtype=np.float64)

    d = dct(dct(a, axis=0, norm="ortho"), axis=1, norm="ortho")
    low = d[:hash_size, :hash_size]

    # Exclude the DC term from the median so overall brightness does not
    # dominate the comparison.
    med = np.median(low.flatten()[1:])
    return (low > med).flatten()


def hamming(a: np.ndarray, b: np.ndarray) -> int:
    return int(np.count_nonzero(a != b))


def hash_split(paths: list[str], name: str) -> tuple[np.ndarray, list[str]]:
    """pHash every satellite half in a split. Returns (N, 64) bool matrix."""
    print(f"    hashing {name} ({len(paths)} tiles)...")
    rows = []
    for i, p in enumerate(paths):
        if i and i % 400 == 0:
            print(f"      {i}/{len(paths)}")
        sat, _ = load_pair(Path(p))
        rows.append(phash(sat))
    return np.array(rows, dtype=bool), list(paths)


def pairwise_distances(A: np.ndarray, B: np.ndarray | None = None) -> np.ndarray:
    """
    Hamming distance matrix via matrix multiply -- fast enough for ~2k x 2k.

    XOR count == a·(1-b) + (1-a)·b, both computable as float matmuls.
    """
    Af = A.astype(np.float32)
    Bf = Af if B is None else B.astype(np.float32)
    return (Af @ (1.0 - Bf).T + (1.0 - Af) @ Bf.T).astype(np.int16)


def find_within(A: np.ndarray, paths: list[str], threshold: int) -> list[dict]:
    d = pairwise_distances(A)
    np.fill_diagonal(d, 99)
    ii, jj = np.where(d <= threshold)
    seen, out = set(), []
    for i, j in zip(ii, jj):
        key = (min(i, j), max(i, j))
        if key in seen:
            continue
        seen.add(key)
        out.append({"a": Path(paths[i]).name, "b": Path(paths[j]).name,
                    "distance": int(d[i, j])})
    return sorted(out, key=lambda r: r["distance"])


def find_across(A: np.ndarray, pa: list[str], B: np.ndarray, pb: list[str],
                threshold: int) -> list[dict]:
    d = pairwise_distances(A, B)
    ii, jj = np.where(d <= threshold)
    return sorted(
        [{"a": Path(pa[i]).name, "b": Path(pb[j]).name,
          "a_path": pa[i], "b_path": pb[j], "distance": int(d[i, j])}
         for i, j in zip(ii, jj)],
        key=lambda r: r["distance"])


def fig_distance_histogram(dists: dict[str, np.ndarray], threshold: int, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 3.8))
    bins = np.arange(0, 41, 1)
    for k, (name, d) in enumerate(dists.items()):
        ax.hist(d, bins=bins, density=True, histtype="step", linewidth=2.2,
                color=SERIES[k], label=name)
    ax.axvline(threshold, color=STATUS["critical"], linestyle="--", linewidth=1.8)
    ax.annotate(f"duplicate threshold = {threshold}", (threshold, ax.get_ylim()[1] * 0.88),
                xytext=(8, 0), textcoords="offset points", fontsize=10,
                color=STATUS["critical"], fontweight="bold")
    ax.set_xlabel("pHash Hamming distance to nearest tile in the other split")
    ax.set_ylabel("Density")
    ax.set_title("Cross-split similarity — everything left of the line is leakage")
    ax.legend()
    clean_axes(ax)
    fig.tight_layout()
    save(fig, out)


def fig_closest_pairs(pairs: list[dict], out: Path, n: int = 3) -> None:
    """Render the most similar cross-split pairs so the finding is inspectable."""
    if not pairs:
        fig, ax = plt.subplots(figsize=(8, 2.2))
        ax.text(0.5, 0.5, "No cross-split near-duplicates found\nat the configured threshold",
                ha="center", va="center", fontsize=14, fontweight="bold",
                color=STATUS["good"], transform=ax.transAxes)
        ax.axis("off")
        fig.tight_layout()
        save(fig, out)
        return

    n = min(n, len(pairs))
    fig, axes = plt.subplots(n, 2, figsize=(6.5, 3.1 * n), squeeze=False)
    for r in range(n):
        pr = pairs[r]
        for c, key in enumerate(("a_path", "b_path")):
            sat, _ = load_pair(Path(pr[key]))
            ax = axes[r][c]
            ax.imshow(sat)
            ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
            ax.set_title(f"{Path(pr[key]).name}" + (f"  (d={pr['distance']})" if c else ""),
                         fontsize=9, color=INK_SECONDARY)
    fig.suptitle("Closest cross-split pairs", fontsize=13, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=int, default=config.PHASH_DUPLICATE_THRESHOLD)
    args = ap.parse_args()

    apply_style()
    print("=" * 70)
    print("02  LEAKAGE AUDIT")
    print("=" * 70)

    manifest_path = config.RESULTS_DIR / "split_manifest.json"
    manifest = (SplitManifest.load(manifest_path) if manifest_path.exists()
                else build_splits(save_to=manifest_path))
    print(f"  splits: {manifest.sizes}")

    hashes, paths = {}, {}
    for name in ("train", "val", "test"):
        hashes[name], paths[name] = hash_split(getattr(manifest, name), name)

    print("\n  within-split duplicates:")
    within = {}
    for name in ("train", "val", "test"):
        within[name] = find_within(hashes[name], paths[name], args.threshold)
        print(f"    {name:6s}: {len(within[name])} pairs at distance <= {args.threshold}")

    print("\n  cross-split near-duplicates (leakage):")
    across, nearest = {}, {}
    for a, b in combinations(("train", "val", "test"), 2):
        key = f"{a}-{b}"
        across[key] = find_across(hashes[a], paths[a], hashes[b], paths[b], args.threshold)
        d = pairwise_distances(hashes[b], hashes[a])
        nearest[key] = d.min(axis=1)
        status = "CLEAN" if not across[key] else "LEAKAGE"
        print(f"    [{status}] {key:12s}: {len(across[key])} pairs, "
              f"min distance {int(nearest[key].min())}")

    # Anything crossing into val or test is quarantined from training.
    quarantine = sorted({p["a_path"] for k in ("train-val", "train-test")
                         for p in across.get(k, [])})

    results = {
        "threshold": args.threshold,
        "hash": "DCT pHash, 8x8 (64-bit), computed on the satellite half",
        "split_sizes": manifest.sizes,
        "within_split_duplicate_pairs": {k: len(v) for k, v in within.items()},
        "within_split_examples": {k: v[:5] for k, v in within.items()},
        "cross_split_pairs": {k: len(v) for k, v in across.items()},
        "cross_split_examples": {k: v[:10] for k, v in across.items()},
        "nearest_neighbour_distance": {
            k: {"min": int(v.min()), "median": float(np.median(v)), "mean": float(v.mean())}
            for k, v in nearest.items()
        },
        "quarantine_train_files": quarantine,
        "verdict": ("clean" if not quarantine
                    else f"{len(quarantine)} training tiles quarantined"),
    }

    (config.RESULTS_DIR / "02_leakage.json").write_text(json.dumps(results, indent=2))
    if quarantine:
        (config.RESULTS_DIR / "quarantine.json").write_text(json.dumps(quarantine, indent=2))
        print(f"\n  {len(quarantine)} training tiles quarantined -> outputs/results/quarantine.json")
    else:
        print("\n  No cross-split leakage at this threshold.")

    print("\n  figures...")
    fig_distance_histogram(
        {"train vs val": nearest["train-val"], "train vs test": nearest["train-test"]},
        args.threshold, config.FIGURE_DIR / "02_leakage_histogram.png")
    worst = sorted(across.get("train-val", []) + across.get("train-test", []),
                   key=lambda r: r["distance"])
    fig_closest_pairs(worst, config.FIGURE_DIR / "02_closest_pairs.png")

    print(f"\n  results -> {config.RESULTS_DIR / '02_leakage.json'}")


if __name__ == "__main__":
    main()
