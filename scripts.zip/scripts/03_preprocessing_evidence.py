"""
Measured justification for every preprocessing decision.

The rubric is explicit that a stated preference scores zero. So each choice
below is settled by a measurement on this dataset, not by convention:

  1. RESIZE INTERPOLATION, per domain.
     Map tiles use a small discrete cartographic palette. Smooth interpolation
     invents colours that exist nowhere in the source tile. We measure how far
     resized pixels drift from the source palette and compare that drift
     against the tolerance our own evaluation metric uses (20/255). A choice
     that pushes pixels past that tolerance is manufacturing error before
     training even starts.

     Satellite tiles are continuous photography, where the opposite holds:
     nearest-neighbour aliases. We measure high-frequency energy retention to
     show the asymmetry, which is why the two domains get different filters.

  2. ROAD EDGE PRESERVATION.
     Roads are the thin minority structure every paper on this task reports
     losing. We measure how much road-edge contrast each filter preserves.

  3. NORMALISATION.
     The generator ends in tanh, whose range is [-1, 1]. We report the actual
     channel statistics next to the fixed 0.5/0.5 transform so the deck can
     state plainly that the constants are range-matching, not data-fitted --
     which is also why they carry no leakage risk.

  4. AUGMENTATION.
     Rendered here; measured in scripts/04_ablation.py.

Run:  python scripts/03_preprocessing_evidence.py [--sample 60]
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import RESAMPLE, list_pairs, load_pair
from src.metrics import road_mask
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS, apply_style,
                           bar_labels, clean_axes, save)

import matplotlib.pyplot as plt

METHODS = ["nearest", "bilinear", "bicubic", "lanczos"]


# ---------------------------------------------------------------------------
# 1. Palette fidelity
# ---------------------------------------------------------------------------
def dominant_palette(orig: Image.Image, coverage: float = 0.98,
                     bits: int = 6, max_entries: int = 64) -> np.ndarray:
    """
    The colours a map tile is actually *made of*.

    Taking every colour present is far too permissive -- JPEG ringing alone
    smears a flat fill across hundreds of near-shades, and then any
    interpolated colour lands close to something. Instead we keep only the
    dominant colours that together cover `coverage` of the tile. Those are the
    cartographic palette; everything else is noise or an artefact.
    """
    src = np.asarray(orig, dtype=np.uint8).reshape(-1, 3)
    shift = 8 - bits
    # int32: a 6-bit code reaches 262143, well past int16's range.
    q = (src >> shift).astype(np.int32)
    n = 1 << bits
    codes = (q[:, 0] * n + q[:, 1]) * n + q[:, 2]

    counts = np.bincount(codes)
    order = np.argsort(-counts)
    cum = np.cumsum(counts[order]) / counts.sum()
    keep = order[:max(1, min(max_entries, int(np.searchsorted(cum, coverage) + 1)))]

    half = 1 << (shift - 1)
    pal = np.stack([keep // (n * n), (keep // n) % n, keep % n], axis=1)
    return (pal << shift).astype(np.int16) + half


def palette_drift(orig: Image.Image, size: int, method: str,
                  tolerance: int = config.PIXEL_ACC_TOLERANCE) -> dict:
    """
    How far does resizing push pixels away from the tile's real palette?

    Each resized pixel is scored by its Chebyshev (max-channel) distance to
    the nearest dominant source colour -- the same distance our pixel-accuracy
    metric uses. A pixel beyond `tolerance` is a colour the map never
    contained, and one the metric will count as wrong even for a perfect
    model.
    """
    palette = dominant_palette(orig)
    resized = np.asarray(orig.resize((size, size), RESAMPLE[method]),
                         dtype=np.int16).reshape(-1, 3)

    out = np.empty(len(resized), dtype=np.int16)
    step = 16384
    for i in range(0, len(resized), step):
        chunk = resized[i:i + step]
        d = np.abs(chunk[:, None, :] - palette[None, :, :]).max(axis=2)
        out[i:i + step] = d.min(axis=1)

    return {
        "method": method,
        "mean_drift": float(out.mean()),
        "p95_drift": float(np.percentile(out, 95)),
        "max_drift": float(out.max()),
        "frac_beyond_tolerance": float((out > tolerance).mean()),
        "source_palette_size": int(len(palette)),
    }


def road_retention(orig: Image.Image, size: int, method: str) -> float:
    """
    How faithfully the road network's area survives the resize.

    Roads are thin bright ribbons on a light background. A smoothing filter
    blends road-white outward into that background, and the intermediate
    shades it produces are still bright and desaturated -- so they read as
    road too. The network does not vanish; it *swells*. Measured on thin
    roads, smooth filters inflate road area by half again or more.

    Either direction is damage: the target the model trains against no longer
    matches the cartography, so the model learns to draw roads at the wrong
    width. Returns resized road share / source road share, where 1.0 is
    faithful and any departure -- above or below -- is distortion.
    """
    src_share = road_mask(np.asarray(orig, dtype=np.uint8)).mean()
    if src_share == 0:
        return float("nan")
    small = np.asarray(orig.resize((size, size), RESAMPLE[method]), dtype=np.uint8)
    return float(road_mask(small).mean() / src_share)


def high_frequency_retention(orig: Image.Image, size: int, method: str) -> float:
    """
    Fraction of high-frequency energy surviving a resize, for the satellite
    domain. Computed as the ratio of mean gradient magnitude after resizing
    to that of an area-averaged reference at the same scale.
    """
    ref = np.asarray(orig.resize((size, size), Image.BOX).convert("L"), dtype=np.float64)
    got = np.asarray(orig.resize((size, size), RESAMPLE[method]).convert("L"), dtype=np.float64)

    def grad_energy(a):
        gy, gx = np.gradient(a)
        return float(np.sqrt(gx ** 2 + gy ** 2).mean())

    r = grad_energy(ref)
    return grad_energy(got) / r if r > 0 else float("nan")


def road_edge_contrast(orig: Image.Image, size: int, method: str) -> float:
    """
    Mean gradient magnitude along road boundaries after resizing.

    Roads are thin, high-contrast ribbons. A filter that blurs them lowers
    this number, and blurred road edges are exactly the failure mode reported
    across this literature.
    """
    small = orig.resize((size, size), RESAMPLE[method])
    arr = np.asarray(small, dtype=np.float64)
    mask = road_mask(np.asarray(small, dtype=np.uint8))
    if mask.sum() == 0:
        return float("nan")

    gray = arr.mean(axis=2)
    gy, gx = np.gradient(gray)
    mag = np.sqrt(gx ** 2 + gy ** 2)

    # Boundary = road pixels adjacent to non-road.
    from scipy.ndimage import binary_dilation
    border = binary_dilation(mask) & ~mask
    return float(mag[border].mean()) if border.sum() else float("nan")


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
def fig_drift(map_res: dict, road_res: dict, best_map: str, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
    tol = config.PIXEL_ACC_TOLERANCE
    colors = [STATUS["good"] if m == best_map else SERIES[0] for m in METHODS]

    vals = [map_res[m]["frac_beyond_tolerance"] * 100 for m in METHODS]
    bars = axes[0].bar(METHODS, vals, color=colors, width=0.6)
    axes[0].set_ylabel(f"% of pixels beyond ±{tol}")
    axes[0].set_title("Colours the source tile never contained")
    clean_axes(axes[0])
    bar_labels(axes[0], bars, "{:.1f}%", pad=4)
    axes[0].set_ylim(0, max(max(vals) * 1.28, 1))
    axes[0].tick_params(axis="x", rotation=15)

    vals2 = [road_res[m] * 100 for m in METHODS]
    bars2 = axes[1].bar(METHODS, vals2, color=colors, width=0.6)
    axes[1].axhline(100, color=STATUS["critical"], linestyle="--", linewidth=1.6)
    axes[1].annotate("true road area", (len(METHODS) - 0.5, 100),
                     xytext=(0, 5), textcoords="offset points", ha="right",
                     fontsize=9, color=STATUS["critical"], fontweight="bold")
    axes[1].set_ylabel("Road area vs. source (%)")
    axes[1].set_title("Road network fidelity")
    clean_axes(axes[1])
    bar_labels(axes[1], bars2, "{:.0f}%", pad=4)
    axes[1].set_ylim(0, max(max(vals2) * 1.22, 115))
    axes[1].tick_params(axis="x", rotation=15)

    # Which way the distortion runs is a property of the data, not an
    # assumption: on tiles with thin roads smoothing erases them, on thicker
    # ones it smears them wider. State whichever actually happened.
    worst = max(vals2, key=lambda v: abs(v - 100))
    verb = ("erases thin roads" if worst < 100 else "smears thin roads wider")
    fig.suptitle(f"Map domain: smoothing {verb} — the weakest filter distorts "
                 f"road area by {abs(worst-100):.0f}% before training starts",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_domain_asymmetry(road_res: dict, sat_res: dict, best_map: str,
                         best_sat: str, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))

    # Both panels show distortion: distance from faithful, lower is better.
    vals = [abs(road_res[m] - 1.0) * 100 for m in METHODS]
    c = [STATUS["good"] if m == best_map else SERIES[0] for m in METHODS]
    b = axes[0].bar(METHODS, vals, color=c, width=0.6)
    axes[0].set_title(f"Map domain → {best_map}")
    axes[0].set_ylabel("Road area error: |area − 100| (%)")
    clean_axes(axes[0]); bar_labels(axes[0], b, "{:.0f}", pad=4)
    axes[0].set_ylim(0, max(max(vals) * 1.28, 5)); axes[0].tick_params(axis="x", rotation=15)

    # Distance from 100% -- over-retention is aliasing, under is blurring.
    vals2 = [abs(sat_res[m]["hf_retention"] - 1.0) * 100 for m in METHODS]
    c2 = [STATUS["good"] if m == best_sat else SERIES[1] for m in METHODS]
    b2 = axes[1].bar(METHODS, vals2, color=c2, width=0.6)
    axes[1].set_title(f"Satellite domain → {best_sat}")
    axes[1].set_ylabel("Detail error: |retained − 100| (%)")
    clean_axes(axes[1]); bar_labels(axes[1], b2, "{:.0f}", pad=4)
    axes[1].set_ylim(0, max(vals2) * 1.28); axes[1].tick_params(axis="x", rotation=15)

    fig.suptitle("The two domains rank filters differently — which is why each gets its own",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_visual_comparison(path: Path, out: Path, zoom: int = 110) -> None:
    """
    Show the road loss, rather than asserting it.

    Two things this has to get right. First the crop: scoring windows by total
    road pixels picks a big pale building over a street grid, so we score by
    THIN road pixels -- those that vanish under erosion -- which is exactly the
    structure the resize destroys. Second the honesty of the comparison: we
    downsample at the pipeline's real 600->256 ratio, not an exaggerated one.

    The bottom row is the payoff: road pixels present in the source but gone
    after the resize, drawn in red. That is the measured percentage, visible.
    """
    from scipy.ndimage import binary_erosion

    _, mp = load_pair(path)
    full = np.asarray(mp, dtype=np.uint8)
    mask = road_mask(full)

    # Thin structure only: a wide bright blob survives erosion, a 2px road
    # does not. Scoring on this is what keeps the crop on a street grid.
    thin = mask & ~binary_erosion(mask, iterations=2)

    h, w = thin.shape
    best, by, bx = -1, 0, 0
    for yy in range(0, max(1, h - 2 * zoom), 40):
        for xx in range(0, max(1, w - 2 * zoom), 40):
            score = thin[yy:yy + 2 * zoom, xx:xx + 2 * zoom].sum()
            if score > best:
                best, by, bx = score, yy, xx
    crop = mp.crop((bx, by, bx + 2 * zoom, by + 2 * zoom))
    crop_arr = np.asarray(crop, dtype=np.uint8)
    src_mask = road_mask(crop_arr)

    # The pipeline's own ratio: a 600px tile becomes 256px.
    small_px = max(8, int(round(crop.size[0] * config.CROP_SIZE / 600)))

    fig, axes = plt.subplots(2, len(METHODS) + 1,
                             figsize=(2.55 * (len(METHODS) + 1), 5.5))

    axes[0][0].imshow(crop)
    axes[0][0].set_title(f"Source\n({crop.size[0]}px crop)", fontsize=11)
    axes[1][0].imshow(np.where(src_mask[..., None], [40, 40, 40], [245, 245, 242]
                               ).astype(np.uint8))
    axes[1][0].set_title(f"{src_mask.mean()*100:.1f}% road pixels", fontsize=10,
                         color=INK_SECONDARY)

    for i, m in enumerate(METHODS, start=1):
        small = crop.resize((small_px, small_px), RESAMPLE[m])
        shown = small.resize(crop.size, Image.NEAREST)      # magnify to compare
        axes[0][i].imshow(shown)
        chosen = (m == config.MAP_INTERP)
        axes[0][i].set_title(m + ("  ← chosen" if chosen else ""), fontsize=11,
                             fontweight="bold" if chosen else "normal",
                             color=STATUS["good"] if chosen else INK_SECONDARY)

        # Road pixels the resize destroyed, at source resolution.
        got = road_mask(np.asarray(shown, dtype=np.uint8))
        lost = src_mask & ~got
        canvas = np.where(got[..., None], [40, 40, 40], [245, 245, 242]
                          ).astype(np.uint8)
        canvas[lost] = [211, 59, 59]                        # status: critical
        axes[1][i].imshow(canvas)

        # Headline the SAME quantity the chart plots -- road area retained --
        # so the picture and the measurement can never disagree. Dropped
        # pixels still show in red, but they are the texture of the finding,
        # not a competing number.
        area = got.sum() / max(1, src_mask.sum()) * 100
        drop = lost.sum() / max(1, src_mask.sum()) * 100
        axes[1][i].set_title(f"{area:.0f}% road area kept", fontsize=10,
                             fontweight="bold",
                             color=STATUS["good"] if abs(area - 100) < 5
                                   else STATUS["critical"])
        axes[1][i].set_xlabel(f"{drop:.0f}% of source road pixels dropped",
                              fontsize=8.5, color=INK_SECONDARY)

    for row in axes:
        for ax in row:
            ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

    fig.suptitle("Downsampled at the pipeline's real 600→256 ratio.  "
                 "Bottom row: road pixels present in the source but gone after "
                 "the resize, in red.",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_normalization(paths: list[Path], out: Path, n: int = 40) -> None:
    sat_px, map_px = [], []
    for p in paths[:n]:
        sat, mp = load_pair(p)
        sat_px.append(np.asarray(sat.resize((64, 64)), dtype=np.float32).ravel() / 255.0)
        map_px.append(np.asarray(mp.resize((64, 64)), dtype=np.float32).ravel() / 255.0)
    sat_px = np.concatenate(sat_px)
    map_px = np.concatenate(map_px)

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    bins = np.linspace(0, 1, 60)
    axes[0].hist(sat_px, bins=bins, density=True, histtype="step",
                 linewidth=2.2, color=SERIES[0], label="Satellite")
    axes[0].hist(map_px, bins=bins, density=True, histtype="step",
                 linewidth=2.2, color=SERIES[1], label="Map")
    axes[0].set_title("Raw pixel values  [0, 1]")
    axes[0].set_xlabel("Intensity"); axes[0].set_ylabel("Density")
    axes[0].legend(); clean_axes(axes[0])

    bins2 = np.linspace(-1, 1, 60)
    axes[1].hist((sat_px - 0.5) / 0.5, bins=bins2, density=True, histtype="step",
                 linewidth=2.2, color=SERIES[0], label="Satellite")
    axes[1].hist((map_px - 0.5) / 0.5, bins=bins2, density=True, histtype="step",
                 linewidth=2.2, color=SERIES[1], label="Map")
    for xv in (-1, 1):
        axes[1].axvline(xv, color=STATUS["critical"], linestyle="--", linewidth=1.6)
    axes[1].annotate("tanh output range", (0, axes[1].get_ylim()[1] * 0.92),
                     ha="center", fontsize=10, color=STATUS["critical"], fontweight="bold")
    axes[1].set_title("After normalisation  [-1, 1]")
    axes[1].set_xlabel("Normalised value")
    axes[1].legend(); clean_axes(axes[1])

    fig.suptitle("Normalisation is range-matching to the generator's tanh — "
                 "constants are fixed, not fitted, so it cannot leak",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_augmentation(path: Path, out: Path, n: int = 4, seed: int = 0) -> None:
    import random
    rng = random.Random(seed)
    sat, mp = load_pair(path)

    fig, axes = plt.subplots(2, n + 1, figsize=(2.5 * (n + 1), 5.2))
    for r, (img, label, filt) in enumerate(
            ((sat, "Satellite", RESAMPLE[config.SATELLITE_INTERP]),
             (mp, "Map", RESAMPLE[config.MAP_INTERP]))):
        axes[r][0].imshow(img.resize((config.CROP_SIZE, config.CROP_SIZE), filt))
        axes[r][0].set_title(f"{label}\noriginal", fontsize=10)
        axes[r][0].set_ylabel(label, fontsize=11, fontweight="bold")

    # Same crop window and flip applied to both halves -- pairs stay aligned.
    for c in range(1, n + 1):
        big = config.LOAD_SIZE - config.CROP_SIZE
        x, y = rng.randint(0, big), rng.randint(0, big)
        flip = rng.random() < 0.5
        for r, (img, filt) in enumerate(((sat, RESAMPLE[config.SATELLITE_INTERP]),
                                         (mp, RESAMPLE[config.MAP_INTERP]))):
            a = img.resize((config.LOAD_SIZE, config.LOAD_SIZE), filt)
            a = a.crop((x, y, x + config.CROP_SIZE, y + config.CROP_SIZE))
            if flip:
                a = a.transpose(Image.FLIP_LEFT_RIGHT)
            axes[r][c].imshow(a)
            if r == 0:
                axes[r][c].set_title(f"jitter {c}\n({x},{y}){' +flip' if flip else ''}",
                                     fontsize=10)
    for row in axes:
        for ax in row:
            ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    fig.suptitle("Random jitter (286→crop 256 + flip) applies the SAME window to both halves",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=60,
                    help="tiles measured for the interpolation experiment")
    args = ap.parse_args()

    apply_style()
    print("=" * 70)
    print("03  PREPROCESSING EVIDENCE")
    print("=" * 70)

    paths = list_pairs(config.DATA_ROOT / "train")
    rng = np.random.default_rng(0)
    sample = [paths[i] for i in rng.choice(len(paths), min(args.sample, len(paths)),
                                           replace=False)]

    print(f"\n  interpolation experiment on {len(sample)} tiles...")
    map_acc = {m: [] for m in METHODS}
    sat_acc = {m: [] for m in METHODS}
    edge_acc = {m: [] for m in METHODS}
    road_acc = {m: [] for m in METHODS}

    for i, p in enumerate(sample):
        if i and i % 20 == 0:
            print(f"    {i}/{len(sample)}")
        sat, mp = load_pair(p)
        for m in METHODS:
            map_acc[m].append(palette_drift(mp, config.CROP_SIZE, m))
            sat_acc[m].append(high_frequency_retention(sat, config.CROP_SIZE, m))
            edge_acc[m].append(road_edge_contrast(mp, config.CROP_SIZE, m))
            road_acc[m].append(road_retention(mp, config.CROP_SIZE, m))

    map_res = {
        m: {k: float(np.mean([r[k] for r in map_acc[m]]))
            for k in ("mean_drift", "p95_drift", "frac_beyond_tolerance",
                      "source_palette_size")}
        for m in METHODS
    }
    sat_res = {m: {"hf_retention": float(np.nanmean(sat_acc[m]))} for m in METHODS}
    edge_res = {m: float(np.nanmean(edge_acc[m])) for m in METHODS}
    road_res = {m: float(np.nanmean(road_acc[m])) for m in METHODS}

    # The evidence picks the filter, not the other way round. Road-area
    # distortion is scored as distance from 1.0 -- swelling and shrinking are
    # both wrong.
    best_map = min(METHODS, key=lambda m: (round(abs(road_res[m] - 1.0), 3),
                                           map_res[m]["frac_beyond_tolerance"]))
    best_sat = min(METHODS, key=lambda m: abs(sat_res[m]["hf_retention"] - 1.0))

    print("\n  MAP domain (road area: 100% = faithful, above = roads smeared wider):")
    print(f"    {'method':10s} {'road area':>10s} {'distortion':>11s} "
          f"{'off-palette':>12s} {'edge contrast':>14s}")
    for m in METHODS:
        mark = "  <-- best" if m == best_map else ""
        print(f"    {m:10s} {road_res[m]*100:9.1f}% {abs(road_res[m]-1)*100:10.1f}% "
              f"{map_res[m]['frac_beyond_tolerance']*100:11.2f}% {edge_res[m]:14.2f}{mark}")

    print("\n  SATELLITE domain (100% = neither blurred nor aliased):")
    for m in METHODS:
        mark = "  <-- best" if m == best_sat else ""
        print(f"    {m:10s} {sat_res[m]['hf_retention']*100:6.1f}%{mark}")

    print("\n  RECOMMENDATION")
    print(f"    config.MAP_INTERP       = {best_map!r}   (currently {config.MAP_INTERP!r})")
    print(f"    config.SATELLITE_INTERP = {best_sat!r}   (currently {config.SATELLITE_INTERP!r})")
    mismatch = (best_map != config.MAP_INTERP) or (best_sat != config.SATELLITE_INTERP)
    if mismatch:
        print("    ** config does not match the measurement -- update config.py **")
    else:
        print("    config matches the measurement.")

    results = {
        "n_tiles": len(sample),
        "target_size": config.CROP_SIZE,
        "metric_tolerance": config.PIXEL_ACC_TOLERANCE,
        "map_domain": map_res,
        "satellite_domain": sat_res,
        "road_edge_contrast": edge_res,
        "road_retention": road_res,
        "recommended": {"map": best_map, "satellite": best_sat},
        "configured": {"map": config.MAP_INTERP, "satellite": config.SATELLITE_INTERP},
        "config_matches_evidence": not mismatch,
        "normalization": {
            "transform": "(x/255 - 0.5) / 0.5  ->  [-1, 1]",
            "rationale": ("range-matches the generator's tanh output; constants are "
                          "fixed a priori rather than estimated from data, so the "
                          "transform carries no train/test leakage risk"),
        },
    }
    (config.RESULTS_DIR / "03_preprocessing.json").write_text(json.dumps(results, indent=2))

    print("\n  figures...")
    fig_drift(map_res, road_res, best_map, config.FIGURE_DIR / "03_palette_drift.png")
    fig_domain_asymmetry(road_res, sat_res, best_map, best_sat,
                         config.FIGURE_DIR / "03_domain_asymmetry.png")
    fig_visual_comparison(sample[0], config.FIGURE_DIR / "03_interp_visual.png")
    fig_normalization(sample, config.FIGURE_DIR / "03_normalization.png")
    fig_augmentation(sample[0], config.FIGURE_DIR / "03_augmentation.png")

    print(f"\n  results -> {config.RESULTS_DIR / '03_preprocessing.json'}")


if __name__ == "__main__":
    main()
