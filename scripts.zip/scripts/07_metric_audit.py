"""
Metric audit: does the headline metric measure what we care about?

The short answer on this dataset is no, and this script is the demonstration.

Pixel accuracy is what the satellite-to-map literature reports, so we report
it. But the map background (#f2f0ea) and the local-road colour (#fdfdfb)
differ by at most 17 per channel, inside the +/-20 tolerance the protocol
allows. The metric therefore cannot distinguish a drawn road from blank
background, and it rewards whichever model paints flat regions most
confidently.

This is not a theoretical worry. Two configurations in the ablation score
ABOVE the baseline on pixel accuracy while drawing essentially no roads at
all. Plotting the two metrics against each other makes that visible in one
picture, and it is the evidence for reporting road IoU alongside.

Every claim is tested against measured noise -- both the spread across
baseline seeds and each run's own spread across its evaluation points. A gap
smaller than either is reported as unresolved rather than as a finding.

Run:  python scripts/07_metric_audit.py
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS, apply_style,
                           clean_axes, save)

import matplotlib.pyplot as plt

SEED_TAGS = ("A0_baseline", "N1_seed1438", "N2_seed1539")


def load_rows() -> list[dict]:
    p = config.RESULTS_DIR / "04_ablations.json"
    if not p.exists():
        raise SystemExit("Run scripts/04_ablation.py first.")
    return [r for r in json.loads(p.read_text()) if r.get("stable_val")]


def baseline_stats(by: dict, key: str) -> tuple[float, float]:
    vals = [by[t]["stable_val"][key] for t in SEED_TAGS if t in by]
    return float(np.mean(vals)), float(max(vals) - min(vals))


def classify(rows: list[dict], by: dict) -> list[dict]:
    """Label each config against BOTH noise estimates."""
    pa_mean, pa_band = baseline_stats(by, "pixel_accuracy")
    iou_mean, iou_band = baseline_stats(by, "road_iou")

    out = []
    for r in rows:
        if r["tag"] in SEED_TAGS[1:]:
            continue
        pa = r["stable_val"]["pixel_accuracy"]
        iou = r["stable_val"]["road_iou"]
        d_pa, d_iou = pa - pa_mean, iou - iou_mean
        # A gap counts only if it clears the seed-to-seed band AND this run's
        # own spread across evaluation points.
        pa_real = abs(d_pa) > max(pa_band, r["stable_spread"]["pixel_accuracy"])
        iou_real = abs(d_iou) > max(iou_band, r["stable_spread"]["road_iou"])

        if r["tag"] == "A0_baseline":
            verdict = "reference"
        elif d_iou < 0 and iou_real and d_pa > 0:
            # The indictment: road structure measurably collapsed while the
            # headline metric moved the WRONG WAY. A config that loses on both
            # is not evidence against the metric -- there the metric agreed.
            verdict = "metric fails to penalise"
        elif iou_real and d_iou < 0:
            verdict = "worse road structure"
        elif iou_real and d_iou > 0:
            verdict = "better road structure"
        else:
            verdict = "not resolved at this budget"

        out.append({**r, "d_pa": d_pa, "d_iou": d_iou,
                    "pa_real": pa_real, "iou_real": iou_real,
                    "verdict": verdict})
    return out


def fig_divergence(items: list[dict], by: dict, out: Path) -> None:
    pa_mean, pa_band = baseline_stats(by, "pixel_accuracy")
    iou_mean, iou_band = baseline_stats(by, "road_iou")

    fig, ax = plt.subplots(figsize=(10, 5.6))

    # Baseline noise rectangle -- anything inside is indistinguishable from
    # simply re-running the baseline with a different seed.
    ax.axhspan(iou_mean - iou_band, iou_mean + iou_band, color=SERIES[0], alpha=0.07)
    ax.axvspan((pa_mean - pa_band) * 100, (pa_mean + pa_band) * 100,
               color=SERIES[0], alpha=0.07)
    ax.annotate("baseline noise band (seed-to-seed)",
                ((pa_mean - pa_band) * 100, iou_mean + iou_band),
                xytext=(-10, 10), textcoords="offset points", ha="right",
                fontsize=9, color=INK_MUTED)

    collapsed = [i for i in items if i["verdict"] == "metric fails to penalise"]
    for it in items:
        x, y = it["stable_val"]["pixel_accuracy"] * 100, it["stable_val"]["road_iou"]
        is_base = it["tag"] == "A0_baseline"
        is_bad = it in collapsed
        color = (STATUS["critical"] if is_bad
                 else STATUS["good"] if is_base else SERIES[0])
        ax.errorbar(x, y, yerr=it["stable_spread"]["road_iou"],
                    xerr=it["stable_spread"]["pixel_accuracy"] * 100,
                    fmt="o", markersize=11 if (is_bad or is_base) else 8,
                    color=color, ecolor=INK_MUTED, elinewidth=1.0, capsize=3,
                    zorder=3 if (is_bad or is_base) else 2)
        label = it["tag"].split("_", 1)[1]
        # Nudge labels apart: the interesting configs cluster tightly on the
        # right, and stacked text there is unreadable.
        dy, ha = (-20 if is_bad else 14), "center"
        # The two collapsed points nearly coincide; push their labels to
        # opposite sides so neither is unreadable.
        if label == "pixelgan":
            dy, ha = -6, "right"
        elif label == "l1_only":
            dy, ha = 12, "left"
        elif label in ("noaug", "bilinear_map"):
            dy, ha = 16, "left"
        ax.annotate(label, (x, y), xytext=(0, dy), textcoords="offset points",
                    ha=ha, fontsize=9.5,
                    fontweight="bold" if (is_bad or is_base) else "normal",
                    color=color if (is_bad or is_base) else INK_SECONDARY)

    ax.set_xlabel("Pixel accuracy (%) — the metric the literature reports")
    ax.set_ylabel("Road IoU — structural agreement")
    ax.set_title("The two metrics disagree, and the disagreement is systematic")
    clean_axes(ax)
    ax.grid(axis="x")

    if collapsed:
        ns = sorted(c["tag"].split("_", 1)[1] for c in collapsed)
        names = ns[0] if len(ns) == 1 else ", ".join(ns[:-1]) + " and " + ns[-1]
        ax.annotate(
            f"{names} score ABOVE the baseline on pixel\n"
            f"accuracy while losing most of the road network",
            xy=(np.mean([c["stable_val"]["pixel_accuracy"] * 100 for c in collapsed]),
                np.mean([c["stable_val"]["road_iou"] for c in collapsed])),
            xytext=(-150, 60), textcoords="offset points",
            fontsize=10.5, color=STATUS["critical"], fontweight="bold",
            ha="center",
            arrowprops=dict(arrowstyle="->", color=STATUS["critical"], lw=1.5))
    fig.tight_layout()
    save(fig, out)


def fig_ranking(items: list[dict], out: Path) -> None:
    """Rank flip between the two metrics, as a slope chart."""
    pa_order = sorted(items, key=lambda i: -i["stable_val"]["pixel_accuracy"])
    iou_order = sorted(items, key=lambda i: -i["stable_val"]["road_iou"])
    pa_rank = {i["tag"]: n for n, i in enumerate(pa_order)}
    iou_rank = {i["tag"]: n for n, i in enumerate(iou_order)}

    fig, ax = plt.subplots(figsize=(8.5, 5.6))
    for it in items:
        t = it["tag"]
        a, b = pa_rank[t], iou_rank[t]
        moved = b - a
        color = (STATUS["critical"] if moved >= 4
                 else STATUS["good"] if t == "A0_baseline" else SERIES[0])
        ax.plot([0, 1], [a, b], "-o", color=color, linewidth=2.2, markersize=7,
                zorder=3 if moved >= 4 else 2)
        ax.annotate(t.split("_", 1)[1], (0, a), xytext=(-8, 0),
                    textcoords="offset points", ha="right", va="center",
                    fontsize=9.5, color=color)
        ax.annotate(t.split("_", 1)[1], (1, b), xytext=(8, 0),
                    textcoords="offset points", ha="left", va="center",
                    fontsize=9.5, color=color)

    ax.set_xlim(-0.55, 1.55)
    ax.invert_yaxis()
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Ranked by\npixel accuracy", "Ranked by\nroad IoU"],
                       fontsize=11, fontweight="bold")
    ax.set_yticks([])
    ax.set_title("Same runs, two metrics — the ranking inverts")
    for s in ("top", "right", "left", "bottom"):
        ax.spines[s].set_visible(False)
    ax.grid(False)
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    apply_style()
    print("=" * 70)
    print("07  METRIC AUDIT")
    print("=" * 70)

    rows = load_rows()
    by = {r["tag"]: r for r in rows}
    items = classify(rows, by)

    pa_mean, pa_band = baseline_stats(by, "pixel_accuracy")
    iou_mean, iou_band = baseline_stats(by, "road_iou")
    print(f"\n  baseline over {len(SEED_TAGS)} seeds:")
    print(f"    pixel accuracy {pa_mean*100:.1f}%  (band {pa_band*100:.2f} pts)")
    print(f"    road IoU       {iou_mean:.3f}   (band {iou_band:.3f})")

    print(f"\n  {'config':20s} {'pixel':>7s} {'road IoU':>9s}  verdict")
    for it in sorted(items, key=lambda i: -i["stable_val"]["pixel_accuracy"]):
        print(f"  {it['tag']:20s} {it['stable_val']['pixel_accuracy']*100:6.1f}% "
              f"{it['stable_val']['road_iou']:9.3f}  {it['verdict']}")

    collapsed = [i for i in items if i["verdict"] == "metric fails to penalise"]
    if collapsed:
        print(f"\n  {len(collapsed)} configuration(s) beat the baseline on the headline")
        print(f"  metric while losing road structure:")
        for c in collapsed:
            ratio = iou_mean / max(c["stable_val"]["road_iou"], 1e-9)
            print(f"    {c['tag']:20s} pixel {c['d_pa']*100:+.1f} pts, "
                  f"road IoU {ratio:.0f}x worse")
        print("\n  -> pixel accuracy is not measuring map quality on this dataset.")

    # correlation across configs: if the metrics agreed this would be strongly
    # positive. It is not.
    pa = [i["stable_val"]["pixel_accuracy"] for i in items]
    iou = [i["stable_val"]["road_iou"] for i in items]
    r = float(np.corrcoef(pa, iou)[0, 1])
    print(f"\n  correlation between the two metrics across configs: r = {r:+.2f}")

    out = {
        "baseline": {"pixel_accuracy": pa_mean, "pixel_band": pa_band,
                     "road_iou": iou_mean, "road_iou_band": iou_band},
        "correlation_pixel_vs_roadiou": r,
        "configs": [{k: it[k] for k in
                     ("tag", "label", "verdict", "d_pa", "d_iou",
                      "pa_real", "iou_real")} for it in items],
    }
    (config.RESULTS_DIR / "07_metric_audit.json").write_text(json.dumps(out, indent=2))

    print("\n  figures...")
    fig_divergence(items, by, config.FIGURE_DIR / "07_metric_divergence.png")
    fig_ranking(items, config.FIGURE_DIR / "07_rank_flip.png")
    print(f"\n  results -> {config.RESULTS_DIR / '07_metric_audit.json'}")


if __name__ == "__main__":
    main()
