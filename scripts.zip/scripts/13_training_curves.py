"""
Training curves — and the within-run metric divergence.

This is the cleanest evidence in the project, because it has no confounds.
The cross-configuration scatter in script 07 compares runs that differ in
architecture as well as score, so a sceptic can always say the configurations
differ in other ways too. This figure compares a run to ITSELF at different
points in training: same model, same seed, same data, same everything, only
more epochs.

If road structure improves substantially over that span while pixel accuracy
and SSIM stay flat, the metric is not tracking map quality. That is the whole
argument, in one panel, with nothing to control for.

Also plots the loss curves, which earn their place for a different reason: in
a GAN they are a health check rather than a quality measure. A discriminator
loss collapsing to zero means the generator stopped receiving useful gradient.
Showing that it did not is how you justify the training setup.

Run:  python scripts/13_training_curves.py [--tags a b c]
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.viz_style import (INK, INK_MUTED, INK_SECONDARY, SERIES, STATUS,
                           apply_style, clean_axes, save)

import matplotlib.pyplot as plt


def load_history(tag: str) -> dict | None:
    p = config.RESULTS_DIR / f"{tag}_history.json"
    if not p.exists():
        return None
    return json.loads(p.read_text())


def eval_points(hist: dict) -> tuple[list[int], dict[str, list[float]]]:
    eps, series = [], {}
    for e in hist.get("epochs", []):
        if "val" not in e:
            continue
        eps.append(e["epoch"])
        for k, v in e["val"].items():
            series.setdefault(k, []).append(v)
    return eps, series


def pct_change(vals: list[float]) -> float | None:
    """Change from the first evaluation point to the last."""
    vals = [v for v in vals if v is not None and not np.isnan(v)]
    if len(vals) < 2 or abs(vals[0]) < 1e-9:
        return None
    return (vals[-1] - vals[0]) / abs(vals[0]) * 100


def late_pct_change(vals: list[float]) -> float | None:
    """
    Change across the SECOND HALF of training.

    This is the number the divergence argument needs, and the full-run figure
    is not it. Road IoU starts near zero, so first-to-last comes out as
    +11,000% -- arithmetically true, meaningless as evidence, and the kind of
    number that invites a question you cannot answer. Worse, it conflates two
    different phases: early on BOTH metrics improve, because the model is
    learning to paint the right background colour and pixel accuracy genuinely
    rewards that. The divergence is a late-training phenomenon, so measure it
    late.
    """
    vals = [v for v in vals if v is not None and not np.isnan(v)]
    if len(vals) < 4:
        return None
    mid = len(vals) // 2
    base = vals[mid]
    if abs(base) < 1e-9:
        return None
    return (vals[-1] - base) / abs(base) * 100


def fig_divergence(tag: str, eps, series, floor: float | None, out: Path) -> dict:
    """Road IoU against pixel accuracy on twin axes, same run."""
    fig, ax1 = plt.subplots(figsize=(11.0, 5.8))
    ax2 = ax1.twinx()

    l1, = ax1.plot(eps, series["road_iou"], "-o", color=SERIES[0], linewidth=2.6,
                   markersize=5, label="Road IoU (structure)", zorder=3)
    ax1.set_ylabel("Road IoU", color=SERIES[0])
    ax1.tick_params(axis="y", labelcolor=SERIES[0])
    ax1.set_xlabel("Epoch")

    pa = [v * 100 for v in series["pixel_accuracy"]]
    l2, = ax2.plot(eps, pa, "-s", color=STATUS["critical"], linewidth=2.2,
                   markersize=4, label="Pixel accuracy (the reported metric)",
                   zorder=3)
    handles = [l1, l2]
    if "ssim" in series:
        l3, = ax2.plot(eps, [v * 100 for v in series["ssim"]], "--^",
                       color=INK_MUTED, linewidth=1.8, markersize=4,
                       label="SSIM (×100)", zorder=2)
        handles.append(l3)
    ax2.set_ylabel("Pixel accuracy / SSIM (%)", color=STATUS["critical"])
    ax2.tick_params(axis="y", labelcolor=STATUS["critical"])

    if floor is not None:
        # The label matters: an unlabelled axhline lands in the legend as
        # "_child2", which looks like a bug on a slide. It is already
        # annotated on the plot, so it does not need a legend entry at all.
        ax2.axhline(floor * 100, color=STATUS["warn"], linestyle=":",
                    linewidth=2.0, zorder=1)
        ax2.annotate(f"blank-tile floor ({floor*100:.1f}%)",
                     xy=(eps[-1], floor * 100), xytext=(-6, 6),
                     textcoords="offset points", ha="right", fontsize=9.5,
                     color=STATUS["warn"], fontweight="bold")

    d_iou = late_pct_change(series["road_iou"])
    d_pa = late_pct_change(series["pixel_accuracy"])
    if d_iou is not None and d_pa is not None:
        ax1.set_title(
            f"Second half of training, same seed and data — road structure "
            f"{d_iou:+.1f}%, pixel accuracy {d_pa:+.1f}%")
    else:
        ax1.set_title("Metric divergence within a single training run")

    ax1.legend(handles=handles, loc="lower right", fontsize=10)
    ax1.grid(axis="y"); ax1.grid(axis="x", visible=False)
    ax2.grid(False)
    for s in ("top",):
        ax1.spines[s].set_visible(False); ax2.spines[s].set_visible(False)
    fig.tight_layout()
    save(fig, out)
    return {
        # full-run change: dominated by early training, reported for context
        "road_iou_pct_change": pct_change(series["road_iou"]),
        "pixel_accuracy_pct_change": pct_change(series["pixel_accuracy"]),
        "ssim_pct_change": pct_change(series.get("ssim", [])),
        # second-half change: this is the divergence claim
        "road_iou_late_pct_change": d_iou,
        "pixel_accuracy_late_pct_change": d_pa,
        "ssim_late_pct_change": late_pct_change(series.get("ssim", [])),
    }


def fig_losses(tag: str, hist: dict, out: Path) -> dict:
    eps = [e["epoch"] for e in hist["epochs"]]
    gl1 = [e["losses"]["G_L1"] for e in hist["epochs"]]
    dloss = [0.5 * (e["losses"]["D_real"] + e["losses"]["D_fake"])
             for e in hist["epochs"]]
    ggan = [e["losses"]["G_GAN"] for e in hist["epochs"]]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.0, 4.6))
    ax1.plot(eps, gl1, color=SERIES[0], linewidth=2.2)
    ax1.set_xlabel("Epoch"); ax1.set_ylabel("G_L1  (λ × L1)")
    ax1.set_title("Reconstruction loss")
    clean_axes(ax1)

    ax2.plot(eps, dloss, color=SERIES[1], linewidth=2.2, label="D (mean real/fake)")
    ax2.plot(eps, ggan, color=SERIES[3], linewidth=1.8, alpha=0.85, label="G_GAN")
    ax2.axhline(0, color=INK_SECONDARY, linewidth=1.0)
    ax2.set_xlabel("Epoch"); ax2.set_ylabel("Adversarial loss")
    ax2.set_title("Adversarial balance — a health check, not a quality measure")
    ax2.legend(loc="upper right")
    clean_axes(ax2)

    # Collapse is a SUSTAINED state, not a single bad epoch. The first version
    # of this flagged any run whose D loss touched 0.05 once, which condemned a
    # 300-epoch run for one transient dip. A discriminator that wins for one
    # epoch and recovers has not starved the generator of anything.
    THRESH = 0.05
    dmin, dmax = float(np.min(dloss)), float(np.max(dloss))
    below = [d < THRESH for d in dloss]
    frac_below = sum(below) / len(below)
    tail = below[-max(1, len(below) // 10):]          # final 10% of training
    tail_collapsed = sum(tail) / len(tail) > 0.5
    collapsed = frac_below > 0.10 or tail_collapsed
    dipped = (dmin < THRESH) and not collapsed

    if collapsed:
        msg = (f"D collapsed — below {THRESH} for {frac_below*100:.0f}% of epochs"
               + (", including the end of training" if tail_collapsed else ""))
        color = STATUS["critical"]
    elif dipped:
        msg = (f"D dipped to {dmin:.3f} on {sum(below)} of {len(below)} epochs "
               f"and recovered — transient, not collapse")
        color = STATUS["warn"]
    else:
        msg = f"D stayed in [{dmin:.2f}, {dmax:.2f}] — no collapse"
        color = STATUS["good"]
    ax2.annotate(msg, xy=(0.5, 0.04), xycoords="axes fraction", ha="center",
                 fontsize=10, fontweight="bold", color=color)
    fig.suptitle(f"Training health — {tag}", fontsize=12.5, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    save(fig, out)
    return {"d_loss_min": dmin, "d_loss_max": dmax, "d_collapsed": collapsed,
            "d_transient_dip": dipped,
            "d_epochs_below_threshold": int(sum(below)),
            "d_fraction_below_threshold": frac_below,
            "d_collapsed_at_end": tail_collapsed}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", nargs="*", default=None,
                    help="history tags to plot; default is every run found")
    args = ap.parse_args()

    apply_style()
    print("=" * 72)
    print("13  TRAINING CURVES")
    print("=" * 72)

    if args.tags:
        tags = args.tags
    else:
        tags = sorted(p.name.replace("_history.json", "")
                      for p in config.RESULTS_DIR.glob("*_history.json"))
    if not tags:
        raise SystemExit("No *_history.json in outputs/results. Train something first.")

    floor = None
    bp = config.RESULTS_DIR / "06_baselines.json"
    if bp.exists():
        floor = json.loads(bp.read_text()).get("trivial_floor_pixel_accuracy")

    summary = {}
    for tag in tags:
        hist = load_history(tag)
        if hist is None:
            print(f"  skip {tag}: no history file")
            continue
        eps, series = eval_points(hist)
        if len(eps) < 2 or "road_iou" not in series:
            print(f"  skip {tag}: fewer than two evaluation points with road IoU")
            continue
        print(f"\n  {tag}: {len(hist['epochs'])} epochs, "
              f"{len(eps)} evaluation points")
        d = fig_divergence(tag, eps, series, floor,
                           config.FIGURE_DIR / f"13_divergence_{tag}.png")
        h = fig_losses(tag, hist, config.FIGURE_DIR / f"13_losses_{tag}.png")
        print("    full run (early training dominates):")
        for k in ("road_iou_pct_change", "pixel_accuracy_pct_change",
                  "ssim_pct_change"):
            if d.get(k) is not None:
                print(f"      {k:34s} {d[k]:+10.1f}%")
        print("    second half (the divergence claim):")
        for k in ("road_iou_late_pct_change", "pixel_accuracy_late_pct_change",
                  "ssim_late_pct_change"):
            if d.get(k) is not None:
                print(f"      {k:34s} {d[k]:+10.1f}%")
        state = ("  COLLAPSED" if h["d_collapsed"]
                 else "  transient dip" if h["d_transient_dip"] else "")
        print(f"    D loss range                 "
              f"[{h['d_loss_min']:.3f}, {h['d_loss_max']:.3f}]"
              f"  ({h['d_epochs_below_threshold']}/{h['epochs'] if 'epochs' in h else '?'} "
              f"epochs below 0.05){state}")
        summary[tag] = {**d, **h, "epochs": len(hist["epochs"]),
                        "config": hist.get("config", {})}

    p = config.RESULTS_DIR / "13_training_curves.json"
    p.write_text(json.dumps(summary, indent=2))
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
