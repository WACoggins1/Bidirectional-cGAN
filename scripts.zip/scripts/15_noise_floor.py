"""
Apply the measured noise floor to EVERY ablation delta.

WHY THIS EXISTS. Direct response to midterm feedback:

    "You used seed noise (around 3.3pp) to withhold the ResNet-9 claim.
     Apply the same noise floor to your preprocessing/augmentation deltas."

That was a fair hit. At the midterm the seed band was used to withhold one
claim and then not applied to the others -- so the preprocessing and
augmentation rows were presented as if their gaps were real, when they had
never been tested against the same standard. Rigour applied selectively is
not rigour.

This script applies it uniformly. Every configuration's delta from the
baseline is tested against two noise estimates and must clear BOTH:

  seed band        spread of the baseline across three seeds (the same
                   number the ResNet-9 claim was withheld on)
  run spread       that run's own variation across its evaluation points

A delta smaller than either is reported as UNRESOLVED. Not "no effect" --
unresolved. Those are different statements and the distinction is the whole
point of the exercise.

WHAT IT FINDS. The augmentation delta does not clear the floor on either
metric, which means the midterm slide titled "augmentation earns its place"
overstated what the data supports. It is now reported as unresolved.

Run:  python scripts/15_noise_floor.py
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.viz_style import (INK, INK_MUTED, INK_SECONDARY, SERIES, STATUS,
                           apply_style, clean_axes, save)

import matplotlib.pyplot as plt

SEED_TAGS = ("A0_baseline", "N1_seed1438", "N2_seed1539")

METRICS = [
    ("pixel_accuracy", "Pixel accuracy", 100.0, "{:+.2f} pp"),
    ("road_iou", "Road IoU", 1.0, "{:+.4f}"),
]

# Which rows the feedback specifically named. Flagged in the output so the
# response to the comment is visible rather than implied.
FEEDBACK_ROWS = {"A1_noaug", "A2_bilinear_map"}


def load_rows():
    p = config.RESULTS_DIR / "04_ablations.json"
    if not p.exists():
        raise SystemExit("Run scripts/04_ablation.py first.")
    return [r for r in json.loads(p.read_text()) if r.get("stable_val")]


def seed_band(by: dict, key: str) -> tuple[float, float]:
    vals = [by[t]["stable_val"][key] for t in SEED_TAGS if t in by]
    if len(vals) < 2:
        raise SystemExit(
            "Need the seed-replicate runs (N1_seed1438, N2_seed1539) to "
            "estimate the noise floor.")
    return float(np.mean(vals)), float(max(vals) - min(vals))


def analyse(rows: list[dict]) -> dict:
    by = {r["tag"]: r for r in rows}
    bands = {k: seed_band(by, k) for k, *_ in METRICS}

    out = []
    for r in sorted(rows, key=lambda r: r["tag"]):
        if r["tag"] in SEED_TAGS[1:]:
            continue
        rec = {"tag": r["tag"], "label": r.get("label") or r["tag"],
               "is_reference": r["tag"] == "A0_baseline",
               "named_in_feedback": r["tag"] in FEEDBACK_ROWS,
               "metrics": {}}
        for key, _, _, _ in METRICS:
            mean, band = bands[key]
            delta = r["stable_val"][key] - mean
            spread = r["stable_spread"][key]
            threshold = max(band, spread)
            rec["metrics"][key] = {
                "value": r["stable_val"][key],
                "delta": delta,
                "seed_band": band,
                "run_spread": spread,
                "threshold": threshold,
                "resolved": bool(abs(delta) > threshold),
            }
        res = [m["resolved"] for m in rec["metrics"].values()]
        rec["verdict"] = ("reference" if rec["is_reference"] else
                          "resolved on both" if all(res) else
                          "unresolved on both" if not any(res) else
                          "resolved on one metric only")
        out.append(rec)
    return {"seed_tags": list(SEED_TAGS),
            "bands": {k: {"mean": v[0], "band": v[1]} for k, v in bands.items()},
            "configs": out}


def fig_forest(res: dict, out: Path) -> None:
    """Delta per configuration against the shaded noise floor."""
    cfgs = [c for c in res["configs"] if not c["is_reference"]]
    cfgs.sort(key=lambda c: c["metrics"]["road_iou"]["delta"])
    n = len(cfgs)
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 0.42 * n + 2.0), sharey=True)

    for ax, (key, title, scale, fmt) in zip(axes, METRICS):
        band = res["bands"][key]["band"] * scale
        ax.axvspan(-band, band, color=INK_MUTED, alpha=0.13, zorder=0)
        ax.axvline(0, color=INK_SECONDARY, linewidth=1.3, zorder=1)

        ys = np.arange(n)
        for y, c in zip(ys, cfgs):
            m = c["metrics"][key]
            d = m["delta"] * scale
            err = m["threshold"] * scale
            resolved = m["resolved"]
            # Colour encodes RESOLVED vs UNRESOLVED, not direction. Using
            # green for a positive delta would paint "bilinear map resize
            # improves pixel accuracy by 4.92 pp" as a good outcome, when
            # that row is the metric rewarding a preprocessing choice that
            # damages the cartography. Direction is already legible from
            # position relative to zero.
            color = SERIES[0] if resolved else INK_MUTED
            ax.errorbar(d, y, xerr=err, fmt="o", markersize=8,
                        color=color, ecolor=INK_MUTED, elinewidth=1.1,
                        capsize=3, zorder=3)
            ax.annotate(fmt.format(d), (d, y), xytext=(0, 9),
                        textcoords="offset points", ha="center", fontsize=8.8,
                        color=color, fontweight="bold" if resolved else "normal")

        ax.set_yticks(ys)
        ax.set_yticklabels([c["label"] for c in cfgs], fontsize=10)
        ax.set_xlabel(f"Change from baseline — {title}")
        ax.set_title(title, fontsize=12)
        ax.grid(axis="x"); ax.grid(axis="y", visible=False)
        for sdir in ("top", "right", "left"):
            ax.spines[sdir].set_visible(False)
        ax.set_ylim(-0.8, n - 0.2)
        ax.annotate("inside the noise floor\n(unresolved)", (0, -0.62),
                    ha="center", va="center", fontsize=9, color=INK_MUTED,
                    style="italic")

    fig.suptitle("Every ablation delta against the same measured noise floor",
                 fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.012,
             "Bars span the larger of the seed-to-seed band and the run's own "
             "evaluation spread. Grey = inside the floor, so unresolved. "
             "Colour marks resolved, not good.",
             ha="center", fontsize=9.5, color=INK_MUTED)
    fig.tight_layout(rect=(0, 0.035, 1, 0.95))
    save(fig, out)


def main() -> None:
    apply_style()
    print("=" * 74)
    print("15  NOISE FLOOR APPLIED UNIFORMLY  (midterm feedback item)")
    print("=" * 74)

    rows = load_rows()
    res = analyse(rows)

    print(f"\n  noise floor from {len(SEED_TAGS)} baseline seeds:")
    for key, title, scale, fmt in METRICS:
        b = res["bands"][key]
        unit = " pp" if scale == 100 else ""
        print(f"    {title:16s} mean {b['mean']*scale:.3f}{unit}   "
              f"band {b['band']*scale:.3f}{unit}")

    print(f"\n  {'config':20s} {'d pixel':>10s} {'':>4s} {'d road IoU':>11s} "
          f"{'':>4s}  verdict")
    print("  " + "-" * 72)
    for c in res["configs"]:
        p = c["metrics"]["pixel_accuracy"]
        i = c["metrics"]["road_iou"]
        star = " *" if c["named_in_feedback"] else "  "
        print(f"  {c['label'][:20]:20s} {p['delta']*100:+9.2f}p "
              f"{'YES' if p['resolved'] else '--':>4s} {i['delta']:+11.4f} "
              f"{'YES' if i['resolved'] else '--':>4s}  {c['verdict']}{star}")
    print("\n  * named in the midterm feedback")

    named = [c for c in res["configs"] if c["named_in_feedback"]]
    print("\n  RESPONSE TO THE FEEDBACK")
    for c in named:
        p, i = c["metrics"]["pixel_accuracy"], c["metrics"]["road_iou"]
        if not p["resolved"] and not i["resolved"]:
            print(f"    {c['label']}: delta is inside the noise floor on BOTH "
                  f"metrics.")
            print(f"      -> unresolved. The midterm presented this as a result; "
                  f"it is not one.")
        else:
            which = "pixel accuracy" if p["resolved"] else "road IoU"
            print(f"    {c['label']}: clears the floor on {which} only.")

    aug = next((c for c in res["configs"] if c["tag"] == "A1_noaug"), None)
    if aug and aug["verdict"] == "unresolved on both":
        print("\n    Correction carried into the final: the midterm slide")
        print("    \"augmentation earns its place\" overstated the evidence.")
        print("    Augmentation is unresolved at this budget.")

    bil = next((c for c in res["configs"] if c["tag"] == "A2_bilinear_map"), None)
    if bil and bil["metrics"]["pixel_accuracy"]["resolved"] \
            and bil["metrics"]["pixel_accuracy"]["delta"] > 0:
        print("\n    And it produced a new result: a bilinear map resize, which")
        print("    measurably damages road structure in preprocessing, IMPROVES")
        print(f"    pixel accuracy by {bil['metrics']['pixel_accuracy']['delta']*100:.2f} pp"
              f" — clearing the floor. The metric rewards")
        print("    a preprocessing choice that degrades the cartography.")

    p = config.RESULTS_DIR / "15_noise_floor.json"
    p.write_text(json.dumps(res, indent=2))
    print("\n  figure...")
    fig_forest(res, config.FIGURE_DIR / "15_noise_floor.png")
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
