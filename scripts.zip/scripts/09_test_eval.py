"""
Final evaluation on the held-out test split.

This is the only script that reads `manifest.test`. Everything else in the
project reads train or val, by design.

THE DISCIPLINE THIS SCRIPT ENFORCES
-----------------------------------
Model selection and model evaluation are separated, in that order, and the
separation is mechanical rather than a promise:

  Phase 1  Selection. Reads the validation metric out of each run's history
           JSON and picks a winner. The test split is not opened. The decision
           and the numbers it was made on are recorded.
  Phase 2  Evaluation. Loads exactly the one checkpoint Phase 1 chose and
           scores it on test, once.

If you want to evaluate a different model, change what Phase 1 selects on --
do not hand-pick the tag after seeing test numbers. The output JSON records
which tag was selected and on what, so the audit trail survives into the deck.

REPORTING AT TWO TOLERANCES
---------------------------
Pixel accuracy is reported at delta=5 and delta=20 because those are different
metrics with the same name. The satellite-to-map literature does not define
the tolerance rigorously -- Aggarwal et al. (2024) describe an "error factor
of 5" with no formula, no per-channel statement and no colour scale -- and on
this dataset the choice decides whether the metric can see roads at all. See
scripts/11_tolerance_sweep.py for the characterisation.

Run:
    python scripts/09_test_eval.py                     # select, then evaluate
    python scripts/09_test_eval.py --tag baseline_sat2map   # force a tag
    python scripts/09_test_eval.py --direction map2sat
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import (RESAMPLE, MapsDataset, SplitManifest, build_splits,
                         denormalize, load_pair)
from src.metrics import (critical_tolerance, evaluate_batch, l1_error,
                         pixel_accuracy, psnr, road_iou, road_precision,
                         road_recall, ssim)
from src.models import build_generator
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS,
                           apply_style, bar_labels, clean_axes, save)

import matplotlib.pyplot as plt

# Published numbers on this dataset, for the comparison panel. Source is the
# survey cited in the midterm deck. Their tolerance is not precisely specified,
# which is itself part of the finding -- see the note in the figure.
LITERATURE = [
    ("Pix2Pix (our target)", 0.4209, 0.64, 25.29),
    ("CycleGAN (unpaired)", 0.3647, 0.63, 24.05),
    ("MapGen-GAN", 0.3854, 0.64, 24.64),
    ("CscGAN", 0.4686, 0.73, 27.20),
    ("HPix (current best)", 0.6104, 0.75, 26.98),
]
LITERATURE_SOURCE = "Aggarwal et al. (2024), arXiv:2407.13680"

TOLERANCES = (5, 20)


# ---------------------------------------------------------------- phase 1
def select_on_val(direction: str, explicit: str | None,
                  manifest=None, min_train_frac: float = 0.9) -> dict:
    """
    Pick the checkpoint to evaluate. Reads validation metrics ONLY.

    ELIGIBILITY COMES BEFORE RANKING. Only runs trained under the final
    protocol -- the full training split -- are candidates. Ablation runs and
    short diagnostic runs are excluded by construction, for two reasons:

    1. They are not the model being reported. The deliverable is "the full
       baseline", so selecting a 12-epoch subset run and reporting its test
       score would contradict the commitments table on the next slide.
    2. Their validation scores are not comparable anyway. A run trained with
       --limit-val 120 was scored on 120 tiles; a full run with
       --eval-batches 25 was scored on 200. Ranking those against each other
       compares numbers computed on different data.

    This bit first, before the fix: selection picked a 112-epoch 600-tile run
    over the 300-epoch full-split baseline by 0.0155 road IoU -- measured on
    different validation subsets. The ranking was noise dressed as a decision.

    Returns a record of the decision so the deck can show what was selected,
    on what evidence, from how many candidates, and what was excluded.
    """
    if explicit:
        return {"tag": explicit, "selected_on": "explicit --tag",
                "candidates": [], "note": "selection overridden on the command line"}

    histories = sorted(config.RESULTS_DIR.glob("*_history.json"))
    cands = []
    for h in histories:
        try:
            d = json.loads(h.read_text())
        except json.JSONDecodeError:
            continue
        if d.get("config", {}).get("direction") != direction:
            continue
        if not (config.CHECKPOINT_DIR / f"{d['tag']}_latest.pt").exists():
            continue
        vals = [e["val"] for e in d.get("epochs", []) if "val" in e]
        if not vals:
            continue
        # Mean over the last three evaluation points rather than the single
        # best: the best point is partly luck, and picking it is a mild form
        # of overfitting the validation split.
        tail = vals[-3:]
        cands.append({
            "tag": d["tag"],
            "val_road_iou": float(np.mean([v["road_iou"] for v in tail])),
            "val_ssim": float(np.mean([v["ssim"] for v in tail])),
            "val_pixel_accuracy": float(np.mean([v["pixel_accuracy"] for v in tail])),
            "epochs_trained": len(d.get("epochs", [])),
            "n_train": d["config"].get("n_train"),
        })

    if not cands:
        raise SystemExit(
            f"No trained {direction} runs with checkpoints found in {config.RESULTS_DIR}.\n"
            f"  Train one first:\n"
            f"    python -m src.train --direction {direction} --epochs 200 "
            f"--tag baseline_{direction}")

    # Road IoU is the right selection criterion only when the target domain is
    # the map. For map2sat it is identically ~0 for every checkpoint -- the
    # mask finds no roads in satellite imagery -- so ranking on it would be
    # ranking on noise. SSIM is the least-bad metric available during
    # training for that direction; FID would be better but is not computed
    # in the training loop.
    if road_metrics_apply(direction):
        key, why = "val_road_iou", ("highest mean validation road IoU over the "
                                    "final three evaluation points")
    else:
        key, why = "val_ssim", ("highest mean validation SSIM over the final "
                                "three evaluation points (road IoU is ~0 for "
                                "every map2sat checkpoint, so it cannot rank "
                                "them; FID is reported separately)")
    # -- eligibility ------------------------------------------------------
    full_train = len(manifest.train) if manifest is not None else None
    excluded = []
    if full_train:
        threshold = int(full_train * min_train_frac)
        eligible = []
        for c in cands:
            n = c.get("n_train") or 0
            if n >= threshold:
                eligible.append(c)
            else:
                excluded.append({**c, "excluded_because":
                                 f"trained on {n} tiles, below the {threshold} "
                                 f"required for the final protocol "
                                 f"({full_train} available)"})
        if eligible:
            cands = eligible
        else:
            print(f"\n   WARNING: no run used at least {threshold} training tiles.")
            print( "   Falling back to all candidates. The reported model is NOT")
            print( "   the full-protocol baseline -- say so in the presentation.")
            excluded = []

    cands.sort(key=lambda c: -c[key])
    return {"tag": cands[0]["tag"],
            "selected_on": why,
            "selection_key": key,
            "candidates": cands,
            "excluded": excluded,
            "eligibility": (f"n_train >= {int(full_train * min_train_frac)} "
                            f"of {full_train} available"
                            if full_train else "no manifest; all runs eligible"),
            "note": "test split not opened during selection"}


# ---------------------------------------------------------------- phase 2
def load_maps(paths, limit, direction):
    """Target-domain images at evaluation resolution, as uint8 (N,H,W,3)."""
    out = []
    for p in paths[:limit]:
        sat, mp = load_pair(Path(p))
        if direction == "sat2map":
            img, interp = mp, config.MAP_INTERP
        else:
            img, interp = sat, config.SATELLITE_INTERP
        img = img.resize((config.CROP_SIZE, config.CROP_SIZE), RESAMPLE[interp])
        out.append(np.asarray(img, dtype=np.uint8))
    return np.stack(out)


@torch.no_grad()
def run_model(ckpt_path: Path, paths, device, limit):
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ckpt.get("config", {})
    netG = build_generator(cfg.get("generator", "unet")).to(device)
    netG.load_state_dict(ckpt["netG"])
    netG.eval()

    ds = MapsDataset(paths[:limit],
                     direction=cfg.get("direction", config.DEFAULT_DIRECTION),
                     augment=False,
                     sat_interp=cfg.get("sat_interp", config.SATELLITE_INTERP),
                     map_interp=cfg.get("map_interp", config.MAP_INTERP))
    preds, tgts, rows = [], [], []
    for i in range(len(ds)):
        item = ds[i]
        fake = netG(item["src"].unsqueeze(0).to(device))
        f = denormalize(fake.squeeze(0))
        t = denormalize(item["tgt"])
        preds.append(f); tgts.append(t)
        rows.append({
            "path": Path(item["path"]).name,
            "road_iou": road_iou(f, t),
            "road_recall": road_recall(f, t),
            "road_precision": road_precision(f, t),
            "ssim": ssim(f, t),
            "psnr": psnr(f, t),
            **{f"pixel_accuracy_d{d}": pixel_accuracy(f, t, d) for d in TOLERANCES},
        })
        if i and i % 50 == 0:
            print(f"    {i}/{len(ds)}")
    return np.stack(preds), np.stack(tgts), rows, cfg, int(ckpt.get("epoch", -1))


def best_constant_colour(maps, n_candidates=48, seed=0):
    """Fitted on TRAIN maps only -- the baseline must not see test either."""
    flat = maps.reshape(-1, 3)
    idx = np.random.default_rng(seed).choice(
        len(flat), size=min(400_000, len(flat)), replace=False)
    sample = flat[idx].astype(np.int32)
    q = sample >> 3
    codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
    top = np.argsort(-np.bincount(codes, minlength=32768))[:n_candidates]
    cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4
    best, best_acc = None, -1.0
    for c in cands.astype(np.int16):
        acc = float((np.abs(sample - c).max(axis=1) < config.PIXEL_ACC_TOLERANCE).mean())
        if acc > best_acc:
            best, best_acc = c, acc
    return best.astype(np.uint8)


def _pct(v, places: int = 1) -> str:
    """Percentage, or a dash when the quantity is undefined (zero-width band)."""
    if v is None:
        return "--"
    return f"{v * 100:.{places}f}%"


def road_metrics_apply(direction: str) -> bool:
    """
    Road metrics are only meaningful when the TARGET domain is the map.

    road_mask() finds bright, desaturated pixels, which is what a cartographic
    renderer uses for roads. Satellite imagery has no such convention, so in
    the map2sat direction the mask finds essentially nothing and road IoU
    comes out 0.0000 for every model including a good one. Reporting that as
    a score is worse than not reporting it: an earlier version printed
    "0.0000 vs 0.0000 -- the structural metric separates them", which is
    false, and would have been on a slide.
    """
    return direction == "sat2map"


def metrics_at(pred, tgt, direction: str = "sat2map") -> dict:
    m = {
        "psnr": psnr(pred, tgt),
        "l1": l1_error(pred, tgt),
        "ssim": ssim(pred, tgt),
    }
    if road_metrics_apply(direction):
        m["road_iou"] = road_iou(pred, tgt)
        m["road_recall"] = road_recall(pred, tgt)
        m["road_precision"] = road_precision(pred, tgt)
    else:
        m["road_iou"] = None
        m["road_recall"] = None
        m["road_precision"] = None
        m["road_metrics_note"] = (
            "not applicable: the target domain is satellite imagery, which "
            "has no colour convention for roads to recover")
    for d in TOLERANCES:
        m[f"pixel_accuracy_d{d}"] = pixel_accuracy(pred, tgt, d)
    return m


# ---------------------------------------------------------------- figures
def fig_headline(model_m, const_m, oracle_pa, out: Path) -> None:
    """Model against the trivial floor, at both tolerances plus road IoU."""
    panels = [
        ("Pixel accuracy, δ = 5",
         [model_m["pixel_accuracy_d5"] * 100, const_m["pixel_accuracy_d5"] * 100],
         "{:.1f}%", oracle_pa.get(5, None)),
        ("Pixel accuracy, δ = 20",
         [model_m["pixel_accuracy_d20"] * 100, const_m["pixel_accuracy_d20"] * 100],
         "{:.1f}%", oracle_pa.get(20, None)),
    ]
    # The road panel only exists when road metrics apply to this direction;
    # map2sat has no road mask to compare, and plotting None crashes bar().
    if model_m.get("road_iou") is not None and const_m.get("road_iou") is not None:
        panels.append(("Road IoU",
                       [model_m["road_iou"], const_m["road_iou"]], "{:.3f}", None))

    fig, axes = plt.subplots(1, len(panels), figsize=(4.5 * len(panels), 4.4),
                             squeeze=False)
    axes = axes[0]
    for ax, (title, vals, fmt, oracle) in zip(axes, panels):
        colors = [SERIES[0], STATUS["critical"]]
        bars = ax.bar(["Our model", "Blank tile"], vals, color=colors, width=0.58)
        bar_labels(ax, bars, fmt, pad=4)
        ax.set_title(title, fontsize=12)
        clean_axes(ax)
        top = max(vals + ([oracle * 100] if oracle else []))
        ax.set_ylim(0, max(top * 1.3, 1e-3))
        if oracle:
            ax.axhline(oracle * 100, color=INK_MUTED, linestyle=":", linewidth=1.4)
            ax.annotate("per-tile oracle", (1.45, oracle * 100), xytext=(0, 4),
                        textcoords="offset points", ha="right", fontsize=9,
                        color=INK_MUTED)
    fig.suptitle("Held-out test set — the model against a model-free floor",
                 fontsize=13.5, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save(fig, out)


def fig_literature(model_m, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(10.5, 5.0))
    names = [n for n, *_ in LITERATURE] + ["AerialCartographer (ours)"]
    vals = [pa * 100 for _, pa, _, _ in LITERATURE] + [model_m["pixel_accuracy_d5"] * 100]
    colors = [INK_SECONDARY] * len(LITERATURE) + [SERIES[0]]
    colors[0] = SERIES[1]                     # the target row
    bars = ax.barh(names, vals, color=colors, height=0.62)
    bar_labels_h(ax, bars)
    ax.set_xlabel("Pixel accuracy (%)")
    ax.set_title("Against published numbers on this dataset — ours at δ = 5")
    ax.invert_yaxis()
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis="x"); ax.grid(axis="y", visible=False)
    ax.set_xlim(0, max(vals) * 1.22)
    ax.annotate(
        "Published tolerances are not precisely specified in the source, so\n"
        "these bars are indicative rather than a like-for-like comparison.\n"
        f"Source: {LITERATURE_SOURCE}",
        xy=(0.99, 0.04), xycoords="axes fraction", ha="right", va="bottom",
        fontsize=9, color=INK_MUTED)
    fig.tight_layout()
    save(fig, out)


def bar_labels_h(ax, bars, fmt="{:.1f}%", pad=4):
    for b in bars:
        w = b.get_width()
        ax.annotate(fmt.format(w), (w, b.get_y() + b.get_height() / 2),
                    xytext=(pad, 0), textcoords="offset points",
                    ha="left", va="center", fontsize=9.5, fontweight="bold",
                    color=INK_SECONDARY)


def fig_val_vs_test(sel: dict, test_m: dict, out: Path) -> None:
    """Does the validation estimate hold up on data never used for anything?"""
    chosen = next((c for c in sel["candidates"] if c["tag"] == sel["tag"]), None)
    if chosen is None:
        return
    # Plot whatever the model was actually SELECTED on -- comparing val and
    # test on a different metric than the one that drove selection would not
    # measure the thing this figure is for.
    key = sel.get("selection_key", "val_road_iou")
    test_key = {"val_road_iou": "road_iou", "val_ssim": "ssim"}.get(key, "road_iou")
    label = {"road_iou": "Road IoU", "ssim": "SSIM"}[test_key]
    if chosen.get(key) is None or test_m.get(test_key) is None:
        return
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    labels = ["Validation\n(used for selection)", "Test\n(opened once)"]
    vals = [chosen[key], test_m[test_key]]
    bars = ax.bar(labels, vals, color=[INK_SECONDARY, SERIES[0]], width=0.5)
    bar_labels(ax, bars, "{:.3f}", pad=4)
    ax.set_ylabel(label)
    ax.set_title("Generalisation gap — validation estimate vs held-out test")
    clean_axes(ax)
    # A degenerate run can leave both bars at zero; matplotlib warns and the
    # axis collapses. Floor the top so the figure still renders.
    ax.set_ylim(0, max(max(vals) * 1.35, 1e-3))
    gap = test_m[test_key] - chosen[key]
    rel = gap / chosen[key] * 100 if chosen[key] else 0.0
    verdict = ("test tracks validation closely" if abs(rel) < 10 else
               "test falls short of validation" if rel < 0 else
               "test exceeds validation")
    ax.annotate(f"{gap:+.3f} ({rel:+.1f}%) — {verdict}",
                xy=(0.5, 0.92), xycoords="axes fraction", ha="center",
                fontsize=10.5, fontweight="bold",
                color=STATUS["good"] if abs(rel) < 10 else STATUS["warn"])
    fig.tight_layout()
    save(fig, out)


# ---------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--direction", default=config.DEFAULT_DIRECTION,
                    choices=config.DIRECTIONS)
    ap.add_argument("--tag", default=None,
                    help="force a checkpoint tag instead of selecting on val")
    ap.add_argument("--limit", type=int, default=None,
                    help="cap test tiles (debug only -- the report should use all)")
    args = ap.parse_args()

    apply_style()
    print("=" * 72)
    print("09  HELD-OUT TEST EVALUATION")
    print("=" * 72)

    mp = config.RESULTS_DIR / "split_manifest.json"
    manifest = SplitManifest.load(mp) if mp.exists() else build_splits(save_to=mp)

    # -- phase 1 -----------------------------------------------------------
    print("\n  PHASE 1 — selection (validation only, test not opened)")
    sel = select_on_val(args.direction, args.tag, manifest)
    print(f"   eligible: {sel.get('eligibility', '')}")
    for c in sel["candidates"]:
        mark = "->" if c["tag"] == sel["tag"] else "  "
        print(f"   {mark} {c['tag']:28s} val road IoU {c['val_road_iou']:.4f}  "
              f"({c['epochs_trained']} epochs, n_train={c['n_train']})")
    if sel.get("excluded"):
        print(f"   excluded {len(sel['excluded'])} run(s) not trained under the "
              f"final protocol:")
        for c in sel["excluded"][:4]:
            print(f"      {c['tag']:25s} n_train={c['n_train']}")
        if len(sel["excluded"]) > 4:
            print(f"      ... and {len(sel['excluded']) - 4} more")
    print(f"   selected: {sel['tag']}")
    print(f"   on: {sel['selected_on']}")

    ckpt_path = config.CHECKPOINT_DIR / f"{sel['tag']}_latest.pt"
    if not ckpt_path.exists():
        raise SystemExit(f"Checkpoint missing: {ckpt_path}")

    # -- phase 2 -----------------------------------------------------------
    n_test = len(manifest.test) if args.limit is None else min(args.limit, len(manifest.test))
    print(f"\n  PHASE 2 — evaluation on {n_test} held-out test tiles")
    if args.limit:
        print("   WARNING: --limit set. Do not report these numbers as final.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    preds, tgts, rows, cfg, epoch = run_model(ckpt_path, manifest.test, device, n_test)
    model_m = metrics_at(preds, tgts, args.direction)

    train_maps = load_maps(manifest.train, min(200, len(manifest.train)), args.direction)
    const = best_constant_colour(train_maps)
    const_pred = np.ascontiguousarray(np.broadcast_to(const, tgts.shape))
    const_m = metrics_at(const_pred, tgts, args.direction)

    sats = load_maps(manifest.test, n_test,
                     "map2sat" if args.direction == "sat2map" else "sat2map")
    copy_m = metrics_at(sats, tgts, args.direction)

    oracle_pa = {}
    for d in TOLERANCES:
        accs = []
        for t in tgts:
            flat = t.reshape(-1, 3).astype(np.int32)
            q = flat >> 3
            codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
            top = np.argsort(-np.bincount(codes, minlength=32768))[:12]
            cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4
            accs.append(max(float((np.abs(flat - c).max(axis=1) < d).mean())
                            for c in cands.astype(np.int16)))
        oracle_pa[d] = float(np.mean(accs))

    # -- report ------------------------------------------------------------
    print(f"\n  {'':26s} {'pa d=5':>8s} {'pa d=20':>8s} {'road IoU':>9s} "
          f"{'SSIM':>7s} {'PSNR':>7s}")
    for name, m in (("Our model", model_m), ("Constant colour", const_m),
                    ("Copy input", copy_m)):
        iou_txt = ("     n/a" if m.get("road_iou") is None
                   else f"{m['road_iou']:9.4f}")
        print(f"  {name:26s} {m['pixel_accuracy_d5']*100:7.2f}% "
              f"{m['pixel_accuracy_d20']*100:7.2f}% {iou_txt:>9s} "
              f"{m['ssim']:7.3f} {m['psnr']:7.2f}")
    print(f"  {'Per-tile oracle':26s} {oracle_pa[5]*100:7.2f}% "
          f"{oracle_pa[20]*100:7.2f}% {'--':>9s} {'--':>7s} {'--':>7s}")

    # ---- dynamic range ------------------------------------------------
    # The midterm's claim was "a blank tile beats every model". On a properly
    # trained model that is simply no longer true, so the finding has to be
    # restated in a form the data supports. This is it: the tolerance decides
    # how much of the metric's scale is handed out for free before any model
    # does anything, and how much room is left to distinguish models.
    #
    #   floor     what a constant colour scores (no model at all)
    #   oracle    best achievable per-tile constant, with ground truth known
    #   headroom  oracle - floor: the band a real model competes in
    #
    # A metric reported on a 0-100 scale that actually operates in a 5-point
    # band is not wrong, but it is not comparable across papers either.
    headroom = {}
    for d in TOLERANCES:
        floor = const_m[f"pixel_accuracy_d{d}"]
        oracle = oracle_pa[d]
        band = oracle - floor
        mdl = model_m[f"pixel_accuracy_d{d}"]
        headroom[d] = {
            "floor": floor, "oracle": oracle, "band": band,
            "model": mdl,
            "fraction_of_band_achieved": ((mdl - floor) / band) if band > 1e-9 else None,
            "fraction_of_scale_free": (floor / oracle) if oracle > 1e-9 else None,
        }

    print(f"\n  DYNAMIC RANGE — how much of the scale is actually in play")
    print(f"  {'delta':>6s} {'floor':>8s} {'oracle':>8s} {'band':>8s} "
          f"{'model':>8s} {'of band':>9s} {'free':>7s}")
    for d in TOLERANCES:
        h = headroom[d]
        print(f"  {d:6d} {h['floor']*100:7.2f}% {h['oracle']*100:7.2f}% "
              f"{h['band']*100:7.2f}p {h['model']*100:7.2f}% "
              f"{_pct(h['fraction_of_band_achieved'], 1):>9s} "
              f"{_pct(h['fraction_of_scale_free'], 0):>7s}")
    lo, hi = min(TOLERANCES), max(TOLERANCES)
    if headroom[hi]["band"] > 1e-9 and headroom[lo]["band"] > 1e-9:
        ratio = headroom[lo]["band"] / headroom[hi]["band"]
        print(f"\n  The usable band is {ratio:.1f}x wider at delta={lo} than at "
              f"delta={hi}.")
        print(f"  At delta={hi}, {headroom[hi]['fraction_of_scale_free']*100:.0f}% of "
              f"the score is reachable with no model at all.")

    crit = critical_tolerance()
    print(f"\n  critical tolerance (road vs background) = {crit}")
    for d in TOLERANCES:
        beat = model_m[f"pixel_accuracy_d{d}"] > const_m[f"pixel_accuracy_d{d}"]
        print(f"   delta={d:2d}: model {'BEATS' if beat else 'LOSES TO'} the blank tile "
              f"({model_m[f'pixel_accuracy_d{d}']*100:.2f}% vs "
              f"{const_m[f'pixel_accuracy_d{d}']*100:.2f}%)")
    if model_m.get("road_iou") is None:
        print(f"\n  Road metrics are not reported for {args.direction}: the target")
        print( "  domain is satellite imagery, which carries no colour convention")
        print( "  for roads to recover. Use FID for this direction instead")
        print( "  (scripts/12_fid.py) -- per-pixel agreement is the wrong")
        print( "  instrument when many different outputs are equally correct.")
    elif model_m["road_iou"] > const_m["road_iou"]:
        print(f"\n  road IoU: model {model_m['road_iou']:.4f} vs blank "
              f"{const_m['road_iou']:.4f} — the structural metric separates them "
              f"without needing a tolerance at all.")
    else:
        print(f"\n  road IoU: model {model_m['road_iou']:.4f} vs blank "
              f"{const_m['road_iou']:.4f} — the model does NOT beat a blank tile "
              f"on structure. That is a training result, not a metric result.")

    out = {
        "direction": args.direction,
        "selection": sel,
        "checkpoint": {"tag": sel["tag"], "epoch": epoch, "config": cfg},
        "n_test_tiles": int(n_test),
        "limited": bool(args.limit),
        "tolerances": list(TOLERANCES),
        "critical_tolerance": crit,
        "dynamic_range": headroom,
        "model": model_m,
        "baselines": {"constant_colour": {"colour": "#" + "".join(f"{v:02x}" for v in const),
                                          **const_m},
                      "copy_input": copy_m,
                      "per_tile_oracle_pixel_accuracy": oracle_pa},
        "literature": [{"name": n, "pixel_accuracy": pa, "ssim": s, "psnr": ps}
                       for n, pa, s, ps in LITERATURE],
        "literature_source": LITERATURE_SOURCE,
        "per_tile": rows,
    }
    p = config.RESULTS_DIR / f"09_test_eval_{args.direction}.json"
    p.write_text(json.dumps(out, indent=2))

    print("\n  figures...")
    suffix = args.direction
    fig_headline(model_m, const_m, oracle_pa,
                 config.FIGURE_DIR / f"09_test_headline_{suffix}.png")
    if args.direction == "sat2map":
        fig_literature(model_m, config.FIGURE_DIR / "09_literature.png")
    if sel["candidates"]:
        fig_val_vs_test(sel, model_m, config.FIGURE_DIR / f"09_val_vs_test_{suffix}.png")
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
