"""
Error analysis on the held-out test split, focused on road structure.

Promised on the midterm status slide: "error analysis focused on road recall".
This delivers it, and goes one step further by splitting road error into its
two halves, because they have opposite causes and opposite fixes:

  recall     of the roads that exist, how many did the model draw?
             Low recall = the model is omitting cartography. Usually a
             capacity or training-length problem.
  precision  of the roads the model drew, how many are real?
             Low precision = the model is hallucinating roads, typically by
             smearing bright pixels across the background. Usually an
             adversarial-balance or over-smoothing problem.

A single "road accuracy" number averages these two failure modes together and
hides which one you have.

Analysis runs over three cuts:
  1. the precision/recall plane, tile by tile
  2. performance by scene-composition stratum (the same strata the split was
     balanced on, so this closes that loop)
  3. the relationship between how much road a tile contains and how well the
     model does on it -- the sparse-structure hypothesis

Reads only the per-tile rows that 09 already computed where possible, and
re-runs the model when it needs the images themselves.

Run:  python scripts/10_error_analysis.py [--direction sat2map]
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import MapsDataset, SplitManifest, build_splits, denormalize
from src.metrics import (road_iou, road_mask, road_precision, road_recall,
                         pixel_accuracy, ssim)
from src.models import build_generator
from src.viz_style import (INK, INK_MUTED, INK_SECONDARY, SERIES, STATUS,
                           apply_style, bar_labels, clean_axes, save)

import matplotlib.pyplot as plt

STRATUM_NAMES = ["dense urban", "mixed", "green-dominant", "water/sparse"]


def nanmean(values) -> float:
    """
    Mean over the defined entries, NaN when there are none.

    road_precision is undefined for a tile where the model drew no road at
    all, and road_recall is undefined where the ground truth has none. Both
    are legitimate states -- an undertrained model produces a whole split of
    them -- so this returns NaN quietly instead of emitting a RuntimeWarning
    per call and burying the real output.
    """
    vals = [float(v) for v in values if v is not None and not np.isnan(v)]
    return float(np.mean(vals)) if vals else float("nan")


def jsonable(obj):
    """
    Replace NaN/Inf with None before serialising.

    json.dumps happily writes bare NaN, which is not valid JSON and which the
    deck builder's json.loads will refuse. Converting to null keeps the file
    readable by anything.
    """
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, (float, np.floating)):
        f = float(obj)
        return None if (np.isnan(f) or np.isinf(f)) else f
    if isinstance(obj, (np.integer,)):
        return int(obj)
    return obj


def composition(img: np.ndarray) -> dict:
    """Share of the map tile that reads as each land class."""
    arr = img.astype(np.int16)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    mx, mn = arr.max(-1), arr.min(-1)
    road = (mx >= 246) & ((mx - mn) <= 18)
    green = (g > r + 8) & (g > b + 8)
    water = (b > r + 12) & (b > g + 4)
    n = arr.shape[0] * arr.shape[1]
    return {"road": float(road.sum() / n), "green": float(green.sum() / n),
            "water": float(water.sum() / n)}


def assign_stratum(c: dict) -> int:
    """
    Interpretable bins, deliberately NOT the k-means labels.

    The split used k-means cluster indices, which are arbitrary integers. For
    an error-analysis figure the reader needs bins they can name, so this
    re-bins on the same features with fixed rules.
    """
    if c["water"] > 0.15:
        return 3
    if c["green"] > 0.25:
        return 2
    if c["road"] > 0.12:
        return 0
    return 1


def fig_precision_recall(rows, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.6, 6.4))
    rec = [r["road_recall"] for r in rows]
    pre = [r["road_precision"] for r in rows]
    iou = [r["road_iou"] for r in rows]
    sc = ax.scatter(rec, pre, c=iou, cmap="viridis", s=46, alpha=0.85,
                    edgecolors="white", linewidths=0.6, zorder=3)
    cb = fig.colorbar(sc, ax=ax); cb.set_label("road IoU", fontsize=10)

    mr, mp_ = (nanmean(rec)), (nanmean(pre))
    ax.axvline(mr, color=INK_MUTED, linestyle=":", linewidth=1.2)
    ax.axhline(mp_, color=INK_MUTED, linestyle=":", linewidth=1.2)
    ax.annotate(f"mean recall {mr:.2f}", (mr, 1.01), ha="center", fontsize=9.5,
                color=INK_MUTED)
    ax.annotate(f"mean precision {mp_:.2f}", (1.01, mp_), va="center",
                rotation=90, fontsize=9.5, color=INK_MUTED)

    ax.set_xlabel("Road recall — of the roads that exist, how many were drawn")
    ax.set_ylabel("Road precision — of the roads drawn, how many are real")
    ax.set_title("Every test tile, split by failure mode")
    ax.set_xlim(-0.02, 1.05); ax.set_ylim(-0.02, 1.05)
    clean_axes(ax); ax.grid(axis="x")

    # Name the corners so the plot reads without a caption.
    for (x, y, label, col) in ((0.04, 0.96, "conservative:\nmisses roads,\nbut what it draws is real", INK_SECONDARY),
                               (0.96, 0.04, "over-draws:\nfinds roads but\ninvents many more", STATUS["critical"]),
                               (0.96, 0.96, "accurate", STATUS["good"])):
        ax.annotate(label, (x, y), ha="right" if x > 0.5 else "left",
                    va="top" if y > 0.5 else "bottom", fontsize=9.5,
                    color=col, style="italic")
    fig.tight_layout()
    save(fig, out)


def fig_by_stratum(rows, out: Path) -> None:
    groups: dict[int, list] = {}
    for r in rows:
        groups.setdefault(r["stratum"], []).append(r)
    present = sorted(groups)
    if not present:
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.0, 4.8))
    labels = [f"{STRATUM_NAMES[s]}\n(n={len(groups[s])})" for s in present]

    ious = [(nanmean([r["road_iou"] for r in groups[s]])) for s in present]
    bars = ax1.bar(labels, ious, color=SERIES[0], width=0.6)
    bar_labels(ax1, bars, "{:.3f}", pad=4)
    ax1.set_ylabel("Road IoU")
    ax1.set_title("Structural accuracy by scene type")
    clean_axes(ax1)
    ax1.set_ylim(0, max(max(ious) * 1.3, 1e-3))
    worst = present[int(np.argmin(ious))]
    ax1.annotate(f"weakest: {STRATUM_NAMES[worst]}",
                 xy=(0.5, 0.93), xycoords="axes fraction", ha="center",
                 fontsize=10, color=STATUS["warn"], fontweight="bold")

    width = 0.38
    xs = np.arange(len(present))
    recs = [(nanmean([r["road_recall"] for r in groups[s]])) for s in present]
    pres = [(nanmean([r["road_precision"] for r in groups[s]])) for s in present]
    b1 = ax2.bar(xs - width / 2, recs, width, label="recall", color=SERIES[0])
    b2 = ax2.bar(xs + width / 2, pres, width, label="precision", color=SERIES[1])
    bar_labels(ax2, b1, "{:.2f}", pad=3); bar_labels(ax2, b2, "{:.2f}", pad=3)
    ax2.set_xticks(xs); ax2.set_xticklabels(labels)
    ax2.set_title("Which half of the error dominates, by scene type")
    ax2.legend(loc="upper right")
    clean_axes(ax2)
    ax2.set_ylim(0, max(max(recs + pres) * 1.3, 1e-3))
    fig.tight_layout()
    save(fig, out)


def fig_density(rows, out: Path) -> None:
    """Does the model do worse where there is less road to find?"""
    dens = [r["road_share_true"] * 100 for r in rows]
    iou = [r["road_iou"] for r in rows]
    fig, ax = plt.subplots(figsize=(9.0, 5.2))
    ax.scatter(dens, iou, s=44, color=SERIES[0], alpha=0.8,
               edgecolors="white", linewidths=0.6, zorder=3)
    # Both axes need variance: a model that scores identically everywhere
    # (an untrained one scores 0 on every tile) makes the correlation 0/0.
    if len(dens) >= 3 and np.std(dens) > 1e-9 and np.std(iou) > 1e-9:
        r = float(np.corrcoef(dens, iou)[0, 1])
        k, b = np.polyfit(dens, iou, 1)
        xs = np.linspace(min(dens), max(dens), 50)
        ax.plot(xs, k * xs + b, "--", color=STATUS["warn"], linewidth=1.8,
                label=f"trend (r = {r:+.2f})")
        ax.legend(loc="lower right")
    else:
        r = float("nan")
    ax.set_xlabel("Road share of the ground-truth tile (%)")
    ax.set_ylabel("Road IoU")
    ax.set_title("Sparse-structure hypothesis: is thin cartography the hard case?")
    clean_axes(ax); ax.grid(axis="x")
    fig.tight_layout()
    save(fig, out)
    return r


def fig_worst(rows, images, out: Path, n: int = 4) -> None:
    """The n worst tiles by road IoU, with the road-difference panel."""
    order = sorted(range(len(rows)), key=lambda i: rows[i]["road_iou"])[:n]
    fig, axes = plt.subplots(n, 4, figsize=(14.0, 3.0 * n), squeeze=False)
    titles = ["Input", "Generated", "Ground truth", "Roads: hit / missed / invented"]
    for r, idx in enumerate(order):
        src, fake, tgt = images[idx]
        tm, pm = road_mask(tgt), road_mask(fake)
        canvas = np.full((*tm.shape, 3), 245, dtype=np.uint8)
        canvas[tm & pm] = [40, 40, 40]
        canvas[tm & ~pm] = [211, 59, 59]
        canvas[~tm & pm] = [235, 104, 52]
        for c, img in enumerate([src, fake, tgt, canvas]):
            ax = axes[r][c]
            ax.imshow(img); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
            if r == 0:
                ax.set_title(titles[c], fontsize=11.5)
        axes[r][0].set_ylabel(f"IoU {rows[idx]['road_iou']:.3f}\n"
                              f"{STRATUM_NAMES[rows[idx]['stratum']]}",
                              fontsize=10, fontweight="bold",
                              color=STATUS["critical"])
    fig.suptitle("The four worst test tiles — where the model fails and how",
                 fontsize=13, fontweight="bold")
    from matplotlib.patches import Patch
    fig.legend(handles=[Patch(facecolor="#282828", label="road drawn correctly"),
                        Patch(facecolor="#d33b3b", label="road missed"),
                        Patch(facecolor="#eb6834", label="road invented")],
               loc="lower center", ncol=3, frameon=False, fontsize=10.5,
               bbox_to_anchor=(0.5, -0.004))
    fig.tight_layout(rect=(0, 0.035, 1, 0.97))
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--direction", default=config.DEFAULT_DIRECTION,
                    choices=config.DIRECTIONS)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    apply_style()
    print("=" * 72)
    print("10  ERROR ANALYSIS (held-out test split)")
    print("=" * 72)

    tag = args.tag
    if tag is None:
        f = config.RESULTS_DIR / f"09_test_eval_{args.direction}.json"
        if not f.exists():
            raise SystemExit("Run scripts/09_test_eval.py first (it selects the model).")
        tag = json.loads(f.read_text())["selection"]["tag"]
    print(f"\n  model: {tag}")

    mp = config.RESULTS_DIR / "split_manifest.json"
    manifest = SplitManifest.load(mp) if mp.exists() else build_splits(save_to=mp)
    paths = manifest.test
    n = len(paths) if args.limit is None else min(args.limit, len(paths))

    ckpt = torch.load(config.CHECKPOINT_DIR / f"{tag}_latest.pt",
                      map_location="cpu", weights_only=False)
    cfg = ckpt.get("config", {})
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    netG = build_generator(cfg.get("generator", "unet")).to(device)
    netG.load_state_dict(ckpt["netG"]); netG.eval()

    ds = MapsDataset(paths[:n], direction=cfg.get("direction", args.direction),
                     augment=False,
                     sat_interp=cfg.get("sat_interp", config.SATELLITE_INTERP),
                     map_interp=cfg.get("map_interp", config.MAP_INTERP))

    rows, images = [], []
    print(f"  scoring {n} test tiles on {device}...")
    with torch.no_grad():
        for i in range(len(ds)):
            item = ds[i]
            s = denormalize(item["src"])
            f = denormalize(netG(item["src"].unsqueeze(0).to(device)).squeeze(0))
            t = denormalize(item["tgt"])
            comp = composition(t)
            rows.append({
                "path": Path(item["path"]).name,
                "road_iou": road_iou(f, t),
                "road_recall": road_recall(f, t),
                "road_precision": road_precision(f, t),
                "ssim": ssim(f, t),
                "pixel_accuracy_d5": pixel_accuracy(f, t, 5),
                "pixel_accuracy_d20": pixel_accuracy(f, t, 20),
                "road_share_true": comp["road"],
                "road_share_pred": float(road_mask(f).mean()),
                "stratum": assign_stratum(comp),
                **{f"share_{k}": v for k, v in comp.items()},
            })
            images.append((s, f, t))
            if i and i % 50 == 0:
                print(f"    {i}/{n}")

    rec = (nanmean([r["road_recall"] for r in rows]))
    pre = (nanmean([r["road_precision"] for r in rows]))
    iou = (nanmean([r["road_iou"] for r in rows]))
    print(f"\n  road IoU {iou:.4f}   recall {rec:.4f}   precision {pre:.4f}")

    if np.isnan(rec) or np.isnan(pre):
        dominant = "undetermined (no road pixels found)"
    elif rec < pre - 0.05:
        dominant = ("RECALL-limited: the model omits real roads more than it "
                    "invents false ones")
    elif pre < rec - 0.05:
        dominant = ("PRECISION-limited: the model invents road pixels more "
                    "than it omits real ones")
    else:
        dominant = "balanced: omission and invention are comparable"
    print(f"  dominant failure mode: {dominant}")

    by_s: dict[int, list] = {}
    for r in rows:
        by_s.setdefault(r["stratum"], []).append(r)
    print(f"\n  {'scene type':18s} {'n':>4s} {'road IoU':>9s} {'recall':>8s} {'prec':>8s}")
    strata_summary = {}
    for s in sorted(by_s):
        g = by_s[s]
        si = (nanmean([r["road_iou"] for r in g]))
        sr = (nanmean([r["road_recall"] for r in g]))
        sp = (nanmean([r["road_precision"] for r in g]))
        print(f"  {STRATUM_NAMES[s]:18s} {len(g):4d} {si:9.4f} {sr:8.4f} {sp:8.4f}")
        strata_summary[STRATUM_NAMES[s]] = {"n": len(g), "road_iou": si,
                                            "road_recall": sr, "road_precision": sp}

    print("\n  figures...")
    fig_precision_recall(rows, config.FIGURE_DIR / "10_precision_recall.png")
    fig_by_stratum(rows, config.FIGURE_DIR / "10_by_stratum.png")
    r_density = fig_density(rows, config.FIGURE_DIR / "10_road_density.png")
    fig_worst(rows, images, config.FIGURE_DIR / "10_worst_cases.png",
              n=min(4, len(rows)))

    out = {
        "direction": args.direction, "tag": tag, "n_tiles": int(n),
        "overall": {"road_iou": iou, "road_recall": rec, "road_precision": pre},
        "dominant_failure_mode": dominant,
        "by_stratum": strata_summary,
        "road_density_correlation": r_density,
        "per_tile": rows,
    }
    p = config.RESULTS_DIR / f"10_error_analysis_{args.direction}.json"
    p.write_text(json.dumps(jsonable(out), indent=2))
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
