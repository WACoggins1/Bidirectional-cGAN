"""
The tolerance sweep: characterising the metric instead of just criticising it.

WHY THIS SCRIPT EXISTS
----------------------
The midterm said "the metric the literature reports is degenerate". That claim
was made at tolerance 20 and it does not survive contact with the source. The
survey cited in the midterm deck -- Aggarwal et al. (2024), arXiv:2407.13680 --
reports Pix2Pix at 42.09% pixel accuracy and describes its tolerance only as an
"error factor of 5": no formula, no statement of whether it applies per channel
or to the whole pixel, no colour scale. A blank tile scores ~79% under our
tolerance-20 implementation. Both numbers are called "pixel accuracy" and they
cannot be the same measurement.

So the honest finding is sharper than the midterm's, not weaker:

  Pixel accuracy on this dataset is a step function of an unspecified
  parameter. The map background (#f2f0ea) and the local-road colour (#fdfdfb)
  differ by at most 17 per channel. Below 17 the metric can tell a drawn road
  from blank background. At 17 and above it cannot, and a constant-colour
  image beats any model that actually draws. The literature does not state
  which side of 17 its numbers were computed on.

That is a reproducibility problem with a published benchmark, it is checkable
by anyone in a minute, and it explains the 42% / 79% gap without either number
being wrong.

WHAT IT PRODUCES
----------------
  11_tolerance_sweep.png   accuracy vs tolerance for model / blank / oracle,
                           with the critical threshold and both the literature
                           and midterm tolerances marked
  11_crossover.png         the gap between model and blank tile, showing the
                           sign flip
  11_tolerance_sweep.json  the curves, the crossover point, the verdict

Run:  python scripts/11_tolerance_sweep.py [--direction sat2map]
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import (RESAMPLE, MapsDataset, SplitManifest, build_splits,
                         denormalize, load_pair)
from src.metrics import BACKGROUND_RGB, ROAD_LOCAL_RGB, critical_tolerance
from src.models import build_generator
from src.viz_style import (INK, INK_MUTED, INK_SECONDARY, SERIES, STATUS,
                           apply_style, clean_axes, save)

import matplotlib.pyplot as plt

LITERATURE_DELTA = 5       # Aggarwal et al. "error factor of 5"
MIDTERM_DELTA = 20         # what config.PIXEL_ACC_TOLERANCE was set to
SWEEP = list(range(1, 41))


def accuracy_curve(pred: np.ndarray, tgt: np.ndarray) -> list[float]:
    """Pixel accuracy at every tolerance in SWEEP, computed in one pass."""
    d = np.abs(pred.astype(np.int16) - tgt.astype(np.int16)).max(axis=-1)
    return [float((d < t).mean()) for t in SWEEP]


def oracle_curve(tgt: np.ndarray) -> list[float]:
    out = []
    for t in SWEEP:
        accs = []
        for img in tgt:
            flat = img.reshape(-1, 3).astype(np.int32)
            q = flat >> 3
            codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
            top = np.argsort(-np.bincount(codes, minlength=32768))[:12]
            cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4
            accs.append(max(float((np.abs(flat - c).max(axis=1) < t).mean())
                            for c in cands.astype(np.int16)))
        out.append(float(np.mean(accs)))
    return out


def find_crossover(model: list[float], blank: list[float]) -> tuple[int | None, bool]:
    """
    Lowest tolerance at which the blank tile overtakes the model.

    A crossover only means something if the model LED first. An untrained or
    broken model sits at zero everywhere and ties the blank tile at delta=1,
    which a naive "first delta where blank >= model" scan reports as a
    crossover at 1 -- a real bug caught on degenerate test data. So this
    requires a strict lead at some smaller tolerance before it will call a
    sign change, and reports separately whether the model ever led at all.

    Returns (crossover_delta_or_None, model_ever_led).
    """
    gap = [m - b for m, b in zip(model, blank)]
    led = False
    for t, g in zip(SWEEP, gap):
        if g > 0:
            led = True
        elif led:
            return t, True
    return None, led


def fig_sweep(curves: dict, crit: int, cross: int | None, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(11.0, 6.0))

    # Shade the region where the metric cannot distinguish road from background.
    # The caption sits at the TOP of the band: the bottom of this axes is where
    # an undertrained model's curve lives, and the two collide there.
    ax.axvspan(crit, SWEEP[-1], color=STATUS["critical"], alpha=0.06, zorder=0)
    ax.annotate("metric cannot separate road from background",
                xy=(crit + 0.8, 98), fontsize=10, color=STATUS["critical"],
                fontweight="bold", va="top", ha="left")

    styles = [("model", SERIES[0], "-", 2.6, "Our model"),
              ("blank", STATUS["critical"], "-", 2.6, "Constant-colour tile (no model)"),
              ("oracle", INK_MUTED, ":", 1.8, "Per-tile oracle (uses ground truth)")]
    for key, color, ls, lw, label in styles:
        if key in curves:
            ax.plot(SWEEP, [v * 100 for v in curves[key]], ls, color=color,
                    linewidth=lw, label=label, zorder=3)

    ax.axvline(crit, color=STATUS["critical"], linestyle="--", linewidth=1.6, zorder=2)
    ax.annotate(f"δ = {crit}\nroad vs background\ndistance",
                xy=(crit, 46), xytext=(-8, 0), textcoords="offset points",
                ha="right", va="center", fontsize=10, fontweight="bold",
                color=STATUS["critical"])

    for d, label, color in ((LITERATURE_DELTA, "literature\n“error factor of 5”", SERIES[2]),
                            (MIDTERM_DELTA, "our midterm\nsetting", SERIES[3])):
        ax.axvline(d, color=color, linestyle="-.", linewidth=1.4, alpha=0.85, zorder=2)
        ax.annotate(label, xy=(d, 4), xytext=(4, 0), textcoords="offset points",
                    ha="left", va="bottom", fontsize=9.5, color=color,
                    fontweight="bold")

    if cross:
        y = curves["model"][SWEEP.index(cross)] * 100
        ax.plot([cross], [y], "o", markersize=11, markerfacecolor="none",
                markeredgecolor=INK, markeredgewidth=2, zorder=4)
        ax.annotate(f"blank tile overtakes the model at δ = {cross}",
                    xy=(cross, y), xytext=(20, -40), textcoords="offset points",
                    fontsize=10.5, fontweight="bold", color=INK,
                    arrowprops=dict(arrowstyle="->", color=INK, lw=1.4))

    ax.set_xlabel("Tolerance δ — a pixel counts correct when every channel is within δ")
    ax.set_ylabel("Pixel accuracy (%)")
    ax.set_title("Pixel accuracy against tolerance — model, blank tile, oracle")
    ax.set_xlim(1, SWEEP[-1]); ax.set_ylim(0, 100)
    ax.legend(loc="upper left", fontsize=10.5)
    clean_axes(ax); ax.grid(axis="x")
    fig.tight_layout()
    save(fig, out)


def fig_crossover(curves: dict, crit: int, out: Path) -> None:
    """The signed gap. Above zero the metric prefers the model."""
    gap = [(m - b) * 100 for m, b in zip(curves["model"], curves["blank"])]
    fig, ax = plt.subplots(figsize=(10.0, 4.8))
    colors = [SERIES[0] if g >= 0 else STATUS["critical"] for g in gap]
    ax.bar(SWEEP, gap, color=colors, width=0.78)
    ax.axhline(0, color=INK_SECONDARY, linewidth=1.2)
    ax.axvline(crit, color=STATUS["critical"], linestyle="--", linewidth=1.5)
    ax.annotate(f"δ = {crit}", xy=(crit, max(gap) if max(gap) > 0 else min(gap)),
                xytext=(5, 0), textcoords="offset points", fontsize=10,
                fontweight="bold", color=STATUS["critical"])
    ax.set_xlabel("Tolerance δ")
    ax.set_ylabel("Model − blank tile (percentage points)")
    ax.set_title("The same two images, ranked opposite ways by the same metric")
    clean_axes(ax); ax.grid(axis="x")
    ax.annotate("metric prefers the model", xy=(0.02, 0.93), xycoords="axes fraction",
                fontsize=10, color=SERIES[0], fontweight="bold")
    ax.annotate("metric prefers a blank tile", xy=(0.02, 0.06), xycoords="axes fraction",
                fontsize=10, color=STATUS["critical"], fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--direction", default=config.DEFAULT_DIRECTION,
                    choices=config.DIRECTIONS)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--split", default="test", choices=["val", "test"])
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    apply_style()
    print("=" * 72)
    print("11  TOLERANCE SWEEP")
    print("=" * 72)

    crit = critical_tolerance()
    print(f"\n  background {BACKGROUND_RGB}  road {ROAD_LOCAL_RGB}")
    print(f"  per-channel distance: "
          f"{[abs(a-b) for a, b in zip(BACKGROUND_RGB, ROAD_LOCAL_RGB)]}  -> max {crit}")
    print(f"  => any tolerance > {crit} scores blank background as correct road\n")

    mp = config.RESULTS_DIR / "split_manifest.json"
    manifest = SplitManifest.load(mp) if mp.exists() else build_splits(save_to=mp)
    paths = getattr(manifest, args.split)
    n = len(paths) if args.limit is None else min(args.limit, len(paths))

    # Reuse 09's selection so this script and the test report describe the same
    # model. Falls back to any checkpoint if 09 has not been run.
    tag = args.tag
    if tag is None:
        sel_file = config.RESULTS_DIR / f"09_test_eval_{args.direction}.json"
        if sel_file.exists():
            tag = json.loads(sel_file.read_text())["selection"]["tag"]
        else:
            found = sorted(config.CHECKPOINT_DIR.glob("*_latest.pt"))
            if not found:
                raise SystemExit("No checkpoints. Train a model first.")
            tag = found[0].name.replace("_latest.pt", "")
    print(f"  model: {tag}   split: {args.split} ({n} tiles)")

    ckpt = torch.load(config.CHECKPOINT_DIR / f"{tag}_latest.pt",
                      map_location="cpu", weights_only=False)
    cfg = ckpt.get("config", {})
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    netG = build_generator(cfg.get("generator", "unet")).to(device)
    netG.load_state_dict(ckpt["netG"]); netG.eval()

    ds = MapsDataset(paths[:n], direction=cfg.get("direction", args.direction),
                     augment=False,
                     sat_interp=cfg.get("sat_interp", config.SATELLITE_INTERP),
                     map_interp=cfg.get("map_interp", config.MAP_INTERP))
    preds, tgts = [], []
    with torch.no_grad():
        for i in range(len(ds)):
            item = ds[i]
            preds.append(denormalize(netG(item["src"].unsqueeze(0).to(device)).squeeze(0)))
            tgts.append(denormalize(item["tgt"]))
    preds, tgts = np.stack(preds), np.stack(tgts)

    # Constant colour fitted on TRAIN only, same as 06/09.
    train_imgs = []
    for p in manifest.train[:200]:
        sat, mpimg = load_pair(Path(p))
        img = mpimg if args.direction == "sat2map" else sat
        interp = config.MAP_INTERP if args.direction == "sat2map" else config.SATELLITE_INTERP
        train_imgs.append(np.asarray(
            img.resize((config.CROP_SIZE, config.CROP_SIZE), RESAMPLE[interp]),
            dtype=np.uint8))
    flat = np.stack(train_imgs).reshape(-1, 3)
    idx = np.random.default_rng(0).choice(len(flat), size=min(400_000, len(flat)),
                                          replace=False)
    sample = flat[idx].astype(np.int32)
    q = sample >> 3
    codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
    top = np.argsort(-np.bincount(codes, minlength=32768))[:48]
    cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4
    best, best_acc = None, -1.0
    for c in cands.astype(np.int16):
        acc = float((np.abs(sample - c).max(axis=1) < MIDTERM_DELTA).mean())
        if acc > best_acc:
            best, best_acc = c, acc
    const_pred = np.ascontiguousarray(np.broadcast_to(best.astype(np.uint8), tgts.shape))

    print("  computing curves...")
    curves = {"model": accuracy_curve(preds, tgts),
              "blank": accuracy_curve(const_pred, tgts),
              "oracle": oracle_curve(tgts)}
    cross, ever_led = find_crossover(curves["model"], curves["blank"])

    print(f"\n  {'delta':>6s} {'model':>9s} {'blank':>9s} {'gap':>9s}")
    for d in (1, 2, 5, 10, 15, 16, 17, 18, 20, 25, 30, 40):
        if d not in SWEEP:
            continue
        i = SWEEP.index(d)
        m, b = curves["model"][i] * 100, curves["blank"][i] * 100
        flag = ""
        if d == crit:
            flag = "  <- critical"
        elif d == LITERATURE_DELTA:
            flag = "  <- literature"
        elif d == MIDTERM_DELTA:
            flag = "  <- midterm setting"
        print(f"  {d:6d} {m:8.2f}% {b:8.2f}% {m-b:+8.2f}{flag}")

    if cross:
        print(f"\n  CROSSOVER at delta = {cross}: below it the metric prefers the")
        print(f"  model; at and above it the metric prefers a blank image.")
        verdict = (f"pixel accuracy inverts its ranking at delta={cross}; the "
                   f"literature does not specify which side its numbers sit on")
    elif ever_led:
        print("\n  No crossover in the swept range: the model beats the blank")
        print("  tile at every tolerance tested.")
        verdict = ("no crossover in 1..40; the model beats the blank tile at "
                   "every tolerance swept")
    else:
        print("\n  The model never leads the blank tile at any tolerance in the")
        print("  swept range. That is a statement about THIS CHECKPOINT, not")
        print("  about the metric -- an undertrained model loses everywhere.")
        print("  Re-run after a full-length training run before reporting this.")
        verdict = ("model never leads the blank tile at any swept tolerance; "
                   "checkpoint is undertrained, not a metric finding")

    out = {
        "direction": args.direction, "tag": tag, "split": args.split,
        "n_tiles": int(n),
        "background_rgb": list(BACKGROUND_RGB), "road_rgb": list(ROAD_LOCAL_RGB),
        "critical_tolerance": crit,
        "literature_delta": LITERATURE_DELTA, "midterm_delta": MIDTERM_DELTA,
        "literature_source": "Aggarwal et al. (2024), arXiv:2407.13680",
        "literature_tolerance_note": (
            "described only as an 'error factor of 5'; no formula, no "
            "per-channel statement, no colour scale"),
        "tolerances": SWEEP, "curves": curves, "crossover": cross,
        "verdict": verdict,
    }
    p = config.RESULTS_DIR / "11_tolerance_sweep.json"
    p.write_text(json.dumps(out, indent=2))

    print("\n  figures...")
    fig_sweep(curves, crit, cross, config.FIGURE_DIR / "11_tolerance_sweep.png")
    fig_crossover(curves, crit, config.FIGURE_DIR / "11_crossover.png")
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
