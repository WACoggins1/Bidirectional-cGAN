"""
Generate a small synthetic stand-in for the Maps dataset.

This exists so the pipeline can be exercised end-to-end without the real
download -- it was used to verify every script runs before handing the code
over. The synthetic tiles imitate the two properties that matter structurally:
a continuous-tone "satellite" half and a flat, small-palette "map" half with
thin bright road lines.

    python scripts/make_synthetic_data.py --out data/maps --n-train 40 --n-val 40

Delete the synthetic directory before using the real dataset.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image

MAP_PALETTE = {
    "background": (242, 239, 233),
    "building":   (222, 215, 205),
    "vegetation": (200, 224, 185),
    "water":      (170, 211, 223),
    "road":       (255, 255, 255),
}


def make_tile(rng: np.random.Generator, size: int = 600) -> Image.Image:
    map_arr = np.full((size, size, 3), MAP_PALETTE["background"], dtype=np.uint8)

    # Blobs of land use
    for name in ("vegetation", "water", "building", "building"):
        cy, cx = rng.integers(0, size, 2)
        ry, rx = rng.integers(size // 10, size // 3, 2)
        yy, xx = np.ogrid[:size, :size]
        blob = ((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2 <= 1
        map_arr[blob] = MAP_PALETTE[name]

    # Thin road grid -- the minority structure the project cares about
    for _ in range(rng.integers(3, 7)):
        y = rng.integers(0, size)
        w = int(rng.integers(3, 7))
        map_arr[max(0, y - w):y + w, :] = MAP_PALETTE["road"]
    for _ in range(rng.integers(3, 7)):
        x = rng.integers(0, size)
        w = int(rng.integers(3, 7))
        map_arr[:, max(0, x - w):x + w] = MAP_PALETTE["road"]

    # Satellite half: continuous tone, correlated with the map content
    base = map_arr.astype(np.float32)
    noise = rng.normal(0, 26, (size, size, 3))
    coarse = rng.normal(0, 30, (size // 20, size // 20, 3))
    coarse = np.array(Image.fromarray(
        np.clip(coarse + 128, 0, 255).astype(np.uint8)).resize((size, size), Image.BICUBIC),
        dtype=np.float32) - 128
    sat = np.clip(base * 0.55 + noise + coarse + 40, 0, 255).astype(np.uint8)

    out = np.concatenate([sat, map_arr], axis=1)      # [satellite | map]
    return Image.fromarray(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/maps")
    ap.add_argument("--n-train", type=int, default=40)
    ap.add_argument("--n-val", type=int, default=40)
    ap.add_argument("--size", type=int, default=600)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    root = Path(args.out)
    for split, n in (("train", args.n_train), ("val", args.n_val)):
        d = root / split
        d.mkdir(parents=True, exist_ok=True)
        for i in range(n):
            make_tile(rng, args.size).save(d / f"{i+1}.jpg", quality=92)
        print(f"  wrote {n} synthetic tiles -> {d}")


if __name__ == "__main__":
    main()
