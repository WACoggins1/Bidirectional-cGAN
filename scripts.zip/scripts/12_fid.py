"""
FID for the synthesis direction (map -> satellite).

Promised on the midterm status slide. The motivation is specific, not
box-ticking: map->satellite is SYNTHESIS, not abstraction. There is no single
correct satellite image for a given map tile -- the map says "houses here",
and any plausible arrangement of roofs satisfies it. Per-pixel metrics punish
a plausible-but-different arrangement exactly as hard as they punish noise,
so L1, PSNR and pixel accuracy are all the wrong instrument in this direction.

FID compares DISTRIBUTIONS instead of pairs: it embeds real and generated
images with an Inception network and measures the Frechet distance between
the two Gaussians fitted to those embeddings. A generator that produces
plausible-but-different imagery scores well; one that produces blurry mush
does not. Lower is better.

CAVEAT WORTH SAYING OUT LOUD. FID is biased by sample size and is not
comparable across papers with different sample counts or preprocessing. With
~550 test tiles the absolute number will sit well above the values quoted in
large-scale generative work, which use 50k samples. It is used here to RANK
our own variants and to compare against the trivial baselines, not to claim a
position against published FIDs.

FIRST RUN DOWNLOADS INCEPTION WEIGHTS (~90 MB) from download.pytorch.org.
That needs a working internet connection.

Run:  python scripts/12_fid.py [--direction map2sat] [--limit 300]
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import MapsDataset, SplitManifest, build_splits, denormalize
from src.models import build_generator
from src.viz_style import (INK_MUTED, SERIES, STATUS, apply_style, bar_labels,
                           clean_axes, save)

import matplotlib.pyplot as plt


def load_inception(device):
    """
    Pool3 features (2048-d) from torchvision's Inception v3.

    Standard FID uses the pool3 layer, so the classifier head is replaced with
    identity rather than removed, keeping the rest of the forward path intact.
    """
    try:
        from torchvision.models import Inception_V3_Weights, inception_v3
    except ImportError as e:                                # pragma: no cover
        raise SystemExit(
            "torchvision is required for FID.\n"
            "  pip install torchvision\n"
            f"  (import failed: {e})")
    try:
        net = inception_v3(weights=Inception_V3_Weights.IMAGENET1K_V1,
                           aux_logits=True)
    except Exception as e:
        raise SystemExit(
            "Could not obtain Inception weights. The first run downloads\n"
            "~90 MB from download.pytorch.org; this machine could not reach it.\n"
            f"  underlying error: {e}\n"
            "  Fix: run this script once on a machine with internet access,\n"
            "  or pre-populate the torch hub cache (~/.cache/torch/hub/checkpoints).")
    net.fc = torch.nn.Identity()
    net.eval()
    return net.to(device)


@torch.no_grad()
def features(net, imgs: np.ndarray, device, batch: int = 32) -> np.ndarray:
    """imgs: (N,H,W,3) uint8 -> (N,2048) float64."""
    mean = torch.tensor([0.485, 0.456, 0.406], device=device).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=device).view(1, 3, 1, 1)
    out = []
    for i in range(0, len(imgs), batch):
        chunk = imgs[i:i + batch]
        t = torch.from_numpy(chunk.transpose(0, 3, 1, 2)).float().to(device) / 255.0
        t = F.interpolate(t, size=(299, 299), mode="bilinear", align_corners=False)
        t = (t - mean) / std
        out.append(net(t).cpu().numpy())
    return np.concatenate(out).astype(np.float64)


def frechet_distance(a: np.ndarray, b: np.ndarray) -> float:
    """
    FID between two feature sets.

    The matrix square root of the covariance product needs scipy; a tiny
    imaginary component from numerical error is expected and discarded, but a
    large one means the computation is unreliable and that is worth failing on
    rather than silently reporting.
    """
    from scipy import linalg
    mu1, mu2 = a.mean(0), b.mean(0)
    s1 = np.cov(a, rowvar=False)
    s2 = np.cov(b, rowvar=False)
    diff = mu1 - mu2

    # scipy removed the `disp` keyword, and older versions return a
    # (matrix, error_estimate) tuple when it is passed. Handle both so this
    # does not depend on which scipy the environment happens to have.
    try:
        covmean = linalg.sqrtm(s1.dot(s2), disp=False)
    except TypeError:
        covmean = linalg.sqrtm(s1.dot(s2))
    if isinstance(covmean, tuple):
        covmean = covmean[0]
    if np.iscomplexobj(covmean):
        if not np.allclose(np.diagonal(covmean).imag, 0, atol=1e-3):
            raise ValueError("sqrtm returned a substantially complex result; "
                             "FID is unreliable for this sample")
        covmean = covmean.real
    return float(diff.dot(diff) + np.trace(s1) + np.trace(s2) - 2 * np.trace(covmean))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--direction", default="map2sat", choices=config.DIRECTIONS)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--split", default="test", choices=["val", "test"])
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    apply_style()
    print("=" * 72)
    print("12  FID — DISTRIBUTIONAL QUALITY FOR THE SYNTHESIS DIRECTION")
    print("=" * 72)

    tag = args.tag
    if tag is None:
        f = config.RESULTS_DIR / f"09_test_eval_{args.direction}.json"
        if f.exists():
            tag = json.loads(f.read_text())["selection"]["tag"]
        else:
            found = sorted(config.CHECKPOINT_DIR.glob("*_latest.pt"))
            cands = []
            for p in found:
                c = torch.load(p, map_location="cpu", weights_only=False)
                if c.get("config", {}).get("direction") == args.direction:
                    cands.append(p.name.replace("_latest.pt", ""))
            if not cands:
                raise SystemExit(
                    f"No {args.direction} checkpoint found.\n"
                    f"  python -m src.train --direction {args.direction} "
                    f"--epochs 200 --tag baseline_{args.direction}")
            tag = cands[0]
    print(f"\n  model: {tag}   direction: {args.direction}   split: {args.split}")

    mp = config.RESULTS_DIR / "split_manifest.json"
    manifest = SplitManifest.load(mp) if mp.exists() else build_splits(save_to=mp)
    paths = getattr(manifest, args.split)
    n = len(paths) if args.limit is None else min(args.limit, len(paths))

    ckpt = torch.load(config.CHECKPOINT_DIR / f"{tag}_latest.pt",
                      map_location="cpu", weights_only=False)
    cfg = ckpt.get("config", {})
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    netG = build_generator(cfg.get("generator", "unet")).to(device)
    netG.load_state_dict(ckpt["netG"]); netG.eval()

    ds = MapsDataset(paths[:n], direction=args.direction, augment=False,
                     sat_interp=cfg.get("sat_interp", config.SATELLITE_INTERP),
                     map_interp=cfg.get("map_interp", config.MAP_INTERP))
    real, fake, inp = [], [], []
    print(f"  generating {n} tiles...")
    with torch.no_grad():
        for i in range(len(ds)):
            item = ds[i]
            fake.append(denormalize(netG(item["src"].unsqueeze(0).to(device)).squeeze(0)))
            real.append(denormalize(item["tgt"]))
            inp.append(denormalize(item["src"]))
    real, fake, inp = np.stack(real), np.stack(fake), np.stack(inp)

    # Pool3 features are 2048-dimensional. With fewer samples than dimensions
    # the covariance estimate is rank-deficient, scipy emits a singular-matrix
    # warning from sqrtm, and the absolute FID is badly biased upward. The test
    # split (~548 tiles) is well inside that regime, so this is not an edge
    # case -- it is the normal operating condition here, and the real-vs-real
    # floor below is what makes the number interpretable anyway.
    if n < 2048:
        print(f"\n  NOTE: {n} samples against 2048 feature dimensions.")
        print( "  The covariance is rank-deficient, so the ABSOLUTE FID is")
        print( "  inflated and not comparable with published values. Compare")
        print( "  against the real-vs-real floor printed below, not against")
        print( "  numbers from papers. Expect a LinAlgWarning from sqrtm; it")
        print( "  is this, and it is expected.\n")

    print("  loading Inception (first run downloads ~90 MB)...")
    net = load_inception(device)

    print("  embedding real...");       f_real = features(net, real, device)
    print("  embedding generated...");  f_fake = features(net, fake, device)

    fid_model = frechet_distance(f_real, f_fake)

    # Two reference points so the number means something.
    mean_colour = real.reshape(-1, 3).mean(0).astype(np.uint8)
    const = np.ascontiguousarray(np.broadcast_to(mean_colour, real.shape))
    print("  embedding constant-colour baseline...")
    fid_const = frechet_distance(f_real, features(net, const, device))
    print("  embedding copy-input baseline...")
    fid_copy = frechet_distance(f_real, features(net, inp, device))

    # Split the real set in half and compare the halves: the floor imposed by
    # sample size alone. Anything near this is as good as the data allows.
    half = len(f_real) // 2
    fid_floor = (frechet_distance(f_real[:half], f_real[half:])
                 if half >= 16 else float("nan"))

    print(f"\n  {'source':28s} {'FID':>10s}")
    print(f"  {'Our model':28s} {fid_model:10.2f}")
    print(f"  {'Constant colour':28s} {fid_const:10.2f}")
    print(f"  {'Copy input (map tile)':28s} {fid_copy:10.2f}")
    if not np.isnan(fid_floor):
        print(f"  {'Real vs real (sample floor)':28s} {fid_floor:10.2f}")
        print(f"\n  The floor is what {half} real images score against another "
              f"{len(f_real)-half}\n  real images. It is the best any generator "
              f"could achieve at this sample size.")

    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    names = ["Our model", "Constant\ncolour", "Copy\ninput"]
    vals = [fid_model, fid_const, fid_copy]
    colors = [SERIES[0], STATUS["critical"], STATUS["critical"]]
    if not np.isnan(fid_floor):
        names.append("Real vs real\n(floor)"); vals.append(fid_floor)
        colors.append(STATUS["good"])
    bars = ax.bar(names, vals, color=colors, width=0.6)
    bar_labels(ax, bars, "{:.1f}", pad=4)
    ax.set_ylabel("FID  (lower is better)")
    ax.set_title(f"Distributional quality, {args.direction} — {n} test tiles")
    clean_axes(ax)
    ax.set_ylim(0, max(vals) * 1.25)
    ax.annotate("FID is sample-size biased; these rank our own variants,\n"
                "they are not comparable with published 50k-sample FIDs.",
                xy=(0.99, 0.88), xycoords="axes fraction", ha="right",
                fontsize=9, color=INK_MUTED)
    fig.tight_layout()
    save(fig, config.FIGURE_DIR / f"12_fid_{args.direction}.png")

    out = {"direction": args.direction, "tag": tag, "split": args.split,
           "n_tiles": int(n), "fid_model": fid_model,
           "fid_constant_colour": fid_const, "fid_copy_input": fid_copy,
           "fid_real_vs_real_floor": None if np.isnan(fid_floor) else fid_floor,
           "n_feature_dims": 2048,
           "rank_deficient": bool(n < 2048),
           "note": ("FID is biased by sample size and preprocessing; these "
                    "values rank our own variants only. With fewer samples "
                    "than the 2048 feature dimensions the covariance is "
                    "rank-deficient and the absolute value is inflated -- "
                    "compare against fid_real_vs_real_floor, not against "
                    "published FIDs.")}
    p = config.RESULTS_DIR / f"12_fid_{args.direction}.json"
    p.write_text(json.dumps(out, indent=2))
    print(f"\n  results -> {p}")


if __name__ == "__main__":
    main()
