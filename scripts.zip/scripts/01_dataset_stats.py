"""
Descriptive statistics for the Maps dataset.

Produces the dataset-understanding evidence (rubric 15%) and the numbers the
preprocessing argument later leans on:

  * integrity check -- file count, dimensions, corrupt files
  * a labelled sample grid so the satellite/map side assignment is verified
    visually rather than assumed
  * per-channel mean/std, computed on TRAIN ONLY
  * colour complexity: unique colours and Shannon entropy per domain, which is
    the measured basis for the claim that photo->map is an abstraction task
    and map->photo is a synthesis task
  * k-means palette of the map domain, with each cluster's pixel share -- this
    is where the road-pixel minority is quantified
  * composition strata used by the splitting strategy

Run:  python scripts/01_dataset_stats.py [--sample 300]
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import (PALETTE_ANCHORS, assign_strata, compute_composition_features,
                         list_pairs, load_pair)
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, apply_style,
                           bar_labels, clean_axes, save)

import matplotlib.pyplot as plt


def check_integrity(paths: list[Path], name: str) -> dict:
    """Verify every file opens and has the expected geometry."""
    sizes, corrupt, modes = Counter(), [], Counter()
    for p in paths:
        try:
            with Image.open(p) as im:
                sizes[im.size] += 1
                modes[im.mode] += 1
        except Exception as e:
            corrupt.append({"file": p.name, "error": str(e)})
    return {
        "split": name,
        "n_files": len(paths),
        "sizes": {f"{w}x{h}": c for (w, h), c in sizes.items()},
        "modes": dict(modes),
        "n_corrupt": len(corrupt),
        "corrupt": corrupt[:10],
        "expected_size": f"{config.RAW_WIDTH}x{config.RAW_HEIGHT}",
        "all_expected_size": (len(sizes) == 1
                              and next(iter(sizes)) == (config.RAW_WIDTH, config.RAW_HEIGHT)),
    }


def channel_stats(paths: list[Path], sample: int, seed: int = 0) -> dict:
    """
    Per-channel mean/std for each domain, in [0,1].

    Computed on the training split only. Reported alongside the fixed 0.5/0.5
    normalisation actually used, so the deck can show the gap explicitly
    rather than implying the constants were fitted.
    """
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(paths), size=min(sample, len(paths)), replace=False)

    acc = {"satellite": [], "map": []}
    for i in idx:
        sat, mp = load_pair(paths[i])
        for key, img in (("satellite", sat), ("map", mp)):
            a = np.asarray(img.resize((64, 64), Image.BILINEAR), dtype=np.float32) / 255.0
            acc[key].append(a.reshape(-1, 3))

    out = {}
    for key, chunks in acc.items():
        allpx = np.concatenate(chunks, axis=0)
        out[key] = {
            "mean": allpx.mean(axis=0).round(4).tolist(),
            "std": allpx.std(axis=0).round(4).tolist(),
        }
    out["n_sampled"] = int(len(idx))
    out["normalization_used"] = {"mean": [config.NORM_MEAN] * 3, "std": [config.NORM_STD] * 3}
    return out


def colour_complexity(paths: list[Path], sample: int, seed: int = 0) -> dict:
    """
    Unique-colour count and Shannon entropy per domain.

    The asymmetry here is the quantitative backbone of the model-selection
    argument: the map domain is a small discrete palette, the satellite domain
    is continuous photography.
    """
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(paths), size=min(sample, len(paths)), replace=False)

    stats = {"satellite": {"unique": [], "entropy": []},
             "map": {"unique": [], "entropy": []}}

    for i in idx:
        sat, mp = load_pair(paths[i])
        for key, img in (("satellite", sat), ("map", mp)):
            a = np.asarray(img, dtype=np.uint8).reshape(-1, 3)
            # Quantise to 5 bits/channel so "unique colours" measures palette
            # size rather than JPEG noise.
            q = (a >> 3).astype(np.int32)
            codes = q[:, 0] * 1024 + q[:, 1] * 32 + q[:, 2]
            counts = np.bincount(codes, minlength=32768).astype(np.float64)
            p = counts[counts > 0] / counts.sum()
            stats[key]["unique"].append(int((counts > 0).sum()))
            stats[key]["entropy"].append(float(-(p * np.log2(p)).sum()))

    # Raw unique-colour COUNT is a trap on this data: satellite tiles are dark
    # and low-saturation so they collapse into few bins, while map tiles add
    # anti-aliased edges, labels and icons on top of their flat fills. The
    # count can therefore rank the map ABOVE the satellite, which inverts the
    # real relationship. Effective palette size -- 2^entropy, the perplexity
    # of the colour distribution -- weights by how much area each colour
    # actually covers, and measures what we mean by "palette".
    return {
        key: {
            "mean_unique_colors": float(np.mean(v["unique"])),
            "std_unique_colors": float(np.std(v["unique"])),
            "mean_entropy_bits": float(np.mean(v["entropy"])),
            "std_entropy_bits": float(np.std(v["entropy"])),
            "effective_colors": float(np.mean([2 ** e for e in v["entropy"]])),
            "effective_colors_std": float(np.std([2 ** e for e in v["entropy"]])),
        }
        for key, v in stats.items()
    } | {"n_sampled": int(len(idx)), "quantization": "5 bits/channel (32768 bins)",
         "headline_metric": "effective_colors (2^entropy)"}


def map_palette(paths: list[Path], sample: int, k: int = 8, seed: int = 0) -> dict:
    """
    k-means palette of the map domain with each cluster's pixel share.

    The smallest bright cluster is the road network. Its share is the
    class-imbalance number quoted in the splitting and risk sections.
    """
    try:
        from sklearn.cluster import KMeans
    except ImportError:
        return {"error": "scikit-learn not installed"}

    rng = np.random.default_rng(seed)
    idx = rng.choice(len(paths), size=min(sample, len(paths)), replace=False)

    px = []
    for i in idx:
        _, mp = load_pair(paths[i])
        a = np.asarray(mp.resize((64, 64), Image.NEAREST), dtype=np.float32).reshape(-1, 3)
        px.append(a[rng.choice(len(a), size=400, replace=False)])
    px = np.concatenate(px, axis=0)

    km = KMeans(n_clusters=k, random_state=seed, n_init=10).fit(px)
    labels, centers = km.labels_, km.cluster_centers_
    shares = np.bincount(labels, minlength=k) / len(labels)

    order = np.argsort(-shares)
    clusters = []
    for rank, c in enumerate(order):
        rgb = centers[c]
        r, g, b = (float(v) for v in rgb)
        mx, mn = max(r, g, b), min(r, g, b)
        # Two road classes here, and they need telling apart. Local streets
        # are near-white and desaturated; arterials and highways are
        # saturated warm yellows/oranges. Calling those "area fill" labels a
        # road as background.
        warm = (r > g > b) and (mx - mn) > 40 and mx > 180
        if mx >= 246 and (mx - mn) <= 18:
            kind = "road: local"
        elif warm:
            kind = "road: arterial"
        else:
            kind = "area fill"
        clusters.append({
            "rank": rank,
            "rgb": [round(float(v), 1) for v in rgb],
            "hex": "#{:02x}{:02x}{:02x}".format(*np.clip(rgb, 0, 255).astype(int)),
            "pixel_share": float(shares[c]),
            "kind": kind,
        })

    local = sum(c["pixel_share"] for c in clusters if c["kind"] == "road: local")
    arterial = sum(c["pixel_share"] for c in clusters if c["kind"] == "road: arterial")
    return {"k": k, "n_pixels": int(len(px)), "clusters": clusters,
            # road_like_share stays the LOCAL class: that is the thin structure
            # the resize destroys, and the class road_mask() tracks. Arterials
            # are wide and survive, so they are reported separately rather than
            # folded in, which would dilute the finding.
            "arterial_share": float(arterial),
            "all_road_share": float(local + arterial),
            "road_like_share": float(local)}


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
def fig_sample_grid(paths: list[Path], out: Path, n: int = 4) -> None:
    """
    Labelled pairs -- confirms SATELLITE_SIDE is set correctly.

    Laid out two pairs per row so the figure comes out wide rather than tall;
    a tall figure shrinks to illegibility in a slide's side column.
    """
    rows = (n + 1) // 2
    fig, axes = plt.subplots(rows, 4, figsize=(11.0, 2.9 * rows), squeeze=False)
    step = max(1, len(paths) // max(1, n))
    for i in range(n):
        sat, mp = load_pair(paths[i * step])
        r, c0 = divmod(i, 2)
        for k, (img, title) in enumerate(((sat, "Satellite (input)"),
                                          (mp, "Map (target)"))):
            ax = axes[r][c0 * 2 + k]
            ax.imshow(img)
            ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
            if r == 0:
                ax.set_title(title, fontsize=12)
    for j in range(n, rows * 2):                       # blank any unused cell
        r, c0 = divmod(j, 2)
        for k in range(2):
            axes[r][c0 * 2 + k].axis("off")
    fig.suptitle("Paired samples — verify side assignment", fontsize=13,
                 fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_colour_complexity(cc: dict, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
    domains = ["satellite", "map"]
    labels = ["Satellite", "Map"]

    for ax, key, std_key, title, fmt in (
        (axes[0], "effective_colors", "effective_colors_std",
         "Effective palette size (2^entropy)", "{:.0f}"),
        (axes[1], "mean_entropy_bits", "std_entropy_bits",
         "Colour entropy (bits)", "{:.2f}"),
    ):
        vals = [cc[d][key] for d in domains]
        errs = [cc[d][std_key] for d in domains]
        bars = ax.bar(labels, vals, color=[SERIES[0], SERIES[1]], width=0.55)
        ax.errorbar(labels, vals, yerr=errs, fmt="none", ecolor=INK_MUTED,
                    capsize=4, linewidth=1.2)
        ax.set_title(title)
        clean_axes(ax)
        bar_labels(ax, bars, fmt, pad=6)
        ax.set_ylim(0, max(v + e for v, e in zip(vals, errs)) * 1.22)

    ratio = cc["satellite"]["effective_colors"] / max(1e-9, cc["map"]["effective_colors"])
    fig.suptitle(f"The two domains are not symmetric — a satellite tile draws on "
                 f"{ratio:.1f}× the effective palette of a map tile",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_palette(pal: dict, out: Path) -> None:
    if "error" in pal:
        return
    clusters = pal["clusters"]
    fig, ax = plt.subplots(figsize=(9, 3.6))
    xs = range(len(clusters))
    shares = [c["pixel_share"] * 100 for c in clusters]
    bars = ax.bar(xs, shares, color=[c["hex"] for c in clusters],
                  edgecolor=INK_MUTED, linewidth=0.8, width=0.7)
    ax.set_xticks(list(xs))
    ax.set_xticklabels([f"{c['hex']}\n{c['kind']}" for c in clusters], fontsize=8)
    ax.set_ylabel("Share of map pixels (%)")
    ax.set_title(f"Map palette is dominated by flat area fill — the local-road "
                 f"class is {pal['road_like_share']*100:.1f}% of pixels, "
                 f"arterials {pal.get('arterial_share', 0)*100:.1f}%")
    clean_axes(ax)
    bar_labels(ax, bars, "{:.1f}%", pad=4)
    ax.set_ylim(0, max(shares) * 1.2)
    fig.tight_layout()
    save(fig, out)


def fig_strata(feats: np.ndarray, strata: np.ndarray, names: list[str], out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))

    counts = np.bincount(strata)
    bars = axes[0].bar(range(len(counts)), counts, color=SERIES[0], width=0.6)
    axes[0].set_xticks(range(len(counts)))
    axes[0].set_xticklabels([f"S{i}" for i in range(len(counts))])
    axes[0].set_ylabel("Tiles")
    axes[0].set_title("Composition strata")
    clean_axes(axes[0])
    bar_labels(axes[0], bars, "{:.0f}", pad=3)
    axes[0].set_ylim(0, counts.max() * 1.18)

    # Mean composition per stratum -- shows what each stratum actually is.
    ax = axes[1]
    width = 0.8 / len(names)
    for j, nm in enumerate(names):
        means = [feats[strata == s, j].mean() * 100 for s in range(len(counts))]
        ax.bar([s + j * width - 0.4 for s in range(len(counts))], means,
               width=width * 0.92, label=nm, color=SERIES[j % len(SERIES)])
    ax.set_xticks(range(len(counts)))
    ax.set_xticklabels([f"S{i}" for i in range(len(counts))])
    ax.set_ylabel("Mean share (%)")
    ax.set_title("What each stratum contains")
    ax.legend(ncol=3, fontsize=8)
    clean_axes(ax)

    fig.suptitle("Stratification variable: scene composition (no class labels exist)",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=300,
                    help="tiles sampled for the pixel-level statistics")
    ap.add_argument("--palette-k", type=int, default=8)
    args = ap.parse_args()

    apply_style()
    print("=" * 70)
    print("01  DATASET STATISTICS")
    print("=" * 70)

    train_paths = list_pairs(config.DATA_ROOT / "train")
    val_paths = list_pairs(config.DATA_ROOT / "val")
    print(f"  train: {len(train_paths)} files")
    print(f"  val:   {len(val_paths)} files")

    results = {"integrity": [check_integrity(train_paths, "train"),
                             check_integrity(val_paths, "provided_val")]}
    for r in results["integrity"]:
        flag = "OK" if r["all_expected_size"] and r["n_corrupt"] == 0 else "CHECK"
        print(f"  [{flag}] {r['split']}: {r['sizes']} modes={r['modes']} "
              f"corrupt={r['n_corrupt']}")

    print("\n  channel statistics (train only)...")
    results["channel_stats"] = channel_stats(train_paths, args.sample)
    for d in ("satellite", "map"):
        s = results["channel_stats"][d]
        print(f"    {d:10s} mean={s['mean']} std={s['std']}")

    print("\n  colour complexity...")
    results["colour_complexity"] = cc = colour_complexity(train_paths, args.sample)
    for d in ("satellite", "map"):
        print(f"    {d:10s} effective palette={cc[d]['effective_colors']:6.1f} "
              f"colours  (entropy {cc[d]['mean_entropy_bits']:.2f} bits, "
              f"raw unique {cc[d]['mean_unique_colors']:.0f})")

    print("\n  map palette (k-means)...")
    results["map_palette"] = pal = map_palette(train_paths, min(args.sample, 200),
                                               k=args.palette_k)
    if "error" not in pal:
        print(f"    local-road share: {pal['road_like_share']*100:.1f}%  "
              f"(arterials {pal.get('arterial_share', 0)*100:.1f}%)")

    print("\n  composition strata...")
    feats, names = compute_composition_features(val_paths, progress=True)
    strata = assign_strata(feats)
    results["strata"] = {
        "n_strata": int(len(np.unique(strata))),
        "feature_names": names,
        "counts": np.bincount(strata).tolist(),
        "mean_composition_per_stratum": {
            f"S{s}": {n: float(feats[strata == s, j].mean()) for j, n in enumerate(names)}
            for s in range(len(np.bincount(strata)))
        },
    }
    print(f"    counts: {results['strata']['counts']}")

    print("\n  figures...")
    fig_sample_grid(train_paths, config.FIGURE_DIR / "01_sample_grid.png")
    fig_colour_complexity(cc, config.FIGURE_DIR / "01_colour_complexity.png")
    fig_palette(pal, config.FIGURE_DIR / "01_map_palette.png")
    fig_strata(feats, strata, names, config.FIGURE_DIR / "01_strata.png")

    out = config.RESULTS_DIR / "01_dataset_stats.json"
    out.write_text(json.dumps(results, indent=2))
    print(f"\n  results -> {out}")
    print("\n  NEXT: open outputs/figures/01_sample_grid.png and confirm the left")
    print("        panel is satellite imagery. If not, flip config.SATELLITE_SIDE.")


if __name__ == "__main__":
    main()
