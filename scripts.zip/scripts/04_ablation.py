"""
Small-scale ablations and the architecture cost profile.

Two phases:

  PHASE A -- cost profile (seconds, no training).
    Parameter count, peak VRAM, and forward+backward throughput for every
    candidate generator and discriminator, measured on the actual GPU. This
    is the "complexity versus dataset size and hardware budget" evidence the
    model-selection rubric asks for, and it is cheap enough to always run.

  PHASE B -- short comparative training runs.
    Every run is identical except for the one variable under test, so each
    row is attributable. Covers three rubric areas at once:
      preprocessing  -- augmentation on/off; map resize filter
      model choice   -- U-Net vs no-skip vs ResNet; discriminator field size
      loss design    -- lambda_L1 sweep, including the pure-adversarial case

Runs are short by design: this establishes ordering between candidates, not
final numbers. Results append incrementally, so an interrupted sweep keeps
whatever finished, and --skip-done resumes.

Run:
    python scripts/04_ablation.py --profile-only        # ~1 minute
    python scripts/04_ablation.py                       # default sweep
    python scripts/04_ablation.py --epochs 25 --limit-train 1096   # fuller
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

import config

# Piping stdout (a redirect, or PowerShell's Tee-Object) flips Python from
# line-buffered to block-buffered, so a long run looks frozen for minutes
# while output sits in an 8KB buffer. Force line buffering so progress is
# visible regardless of how this is invoked.
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except (AttributeError, ValueError):        # pre-3.7, or a replaced stream
    pass
from src.models import (DISCRIMINATORS, GENERATORS, build_discriminator,
                        build_generator, count_parameters, receptive_field)
from src.train import build_parser as train_parser
from src.train import train
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS, apply_style,
                           bar_labels, clean_axes, save)

import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Phase A -- cost profile
# ---------------------------------------------------------------------------
def profile_module(net, sample_input, steps: int = 6, is_disc: bool = False) -> dict:
    """Peak memory and throughput for one forward+backward step."""
    device = sample_input.device
    net = net.to(device).train()
    opt = torch.optim.Adam(net.parameters(), lr=1e-4)

    if device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()

    # warmup
    for _ in range(2):
        out = net(sample_input)
        loss = out.mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()

    if device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.time()
    for _ in range(steps):
        out = net(sample_input)
        loss = out.mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
    if device.type == "cuda":
        torch.cuda.synchronize()
    elapsed = time.time() - t0

    peak = (torch.cuda.max_memory_allocated() / 1e9) if device.type == "cuda" else float("nan")
    bs = sample_input.shape[0]
    return {
        "params": count_parameters(net),
        "params_m": round(count_parameters(net) / 1e6, 2),
        "peak_mem_gb": round(peak, 3),
        "sec_per_step": round(elapsed / steps, 4),
        "imgs_per_sec": round(bs * steps / elapsed, 1),
        "output_shape": list(out.shape),
    }


def phase_a(batch_size: int, crop: int) -> dict:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"  device: {device}")
    if device.type == "cuda":
        props = torch.cuda.get_device_properties(0)
        print(f"  gpu:    {props.name}  {props.total_memory/1e9:.1f} GB")

    out = {
        "device": torch.cuda.get_device_name(0) if device.type == "cuda" else "cpu",
        "total_vram_gb": round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1)
                          if device.type == "cuda" else None,
        "batch_size": batch_size,
        "crop_size": crop,
        "generators": {},
        "discriminators": {},
    }

    x = torch.randn(batch_size, 3, crop, crop, device=device)
    print("\n  generators:")
    for name in GENERATORS:
        try:
            r = profile_module(build_generator(name), x)
            out["generators"][name] = r
            print(f"    {name:13s} {r['params_m']:6.2f}M  {r['peak_mem_gb']:5.2f} GB  "
                  f"{r['imgs_per_sec']:6.1f} img/s")
        except RuntimeError as e:                       # OOM on smaller cards
            out["generators"][name] = {"error": str(e)[:200]}
            print(f"    {name:13s} FAILED: {str(e)[:80]}")
        if device.type == "cuda":
            torch.cuda.empty_cache()

    xy = torch.randn(batch_size, 6, crop, crop, device=device)
    print("\n  discriminators:")
    for name in DISCRIMINATORS:
        try:
            r = profile_module(build_discriminator(name), xy, is_disc=True)
            r["receptive_field"] = receptive_field(name)
            out["discriminators"][name] = r
            print(f"    {name:13s} {r['params_m']:6.2f}M  {r['peak_mem_gb']:5.2f} GB  "
                  f"rf={r['receptive_field']:3d}  out={r['output_shape'][-2:]}")
        except RuntimeError as e:
            out["discriminators"][name] = {"error": str(e)[:200]}
            print(f"    {name:13s} FAILED: {str(e)[:80]}")
        if device.type == "cuda":
            torch.cuda.empty_cache()

    return out


# ---------------------------------------------------------------------------
# Phase B -- ablation sweep
# ---------------------------------------------------------------------------
def ablation_grid() -> list[dict]:
    """
    One variable changes per row relative to the baseline.
    `rubric` tags which section each row supplies evidence for.
    """
    return [
        {"tag": "A0_baseline", "label": "Baseline (U-Net + PatchGAN-70)",
         "rubric": "baseline", "overrides": {}},

        {"tag": "A1_noaug", "label": "No augmentation",
         "rubric": "preprocessing", "overrides": {"no_augment": True}},

        {"tag": "A2_bilinear_map", "label": "Map resized bilinear (not nearest)",
         "rubric": "preprocessing", "overrides": {"map_interp": "bilinear"}},

        {"tag": "B1_noskip", "label": "U-Net without skip connections",
         "rubric": "architecture", "overrides": {"generator": "unet_noskip"}},

        {"tag": "B2_resnet9", "label": "ResNet-9 generator",
         "rubric": "architecture", "overrides": {"generator": "resnet9"}},

        {"tag": "C1_pixelgan", "label": "PixelGAN discriminator (1×1)",
         "rubric": "architecture", "overrides": {"discriminator": "pixel"}},

        {"tag": "C2_imagegan", "label": "ImageGAN discriminator (286×286)",
         "rubric": "architecture", "overrides": {"discriminator": "image"}},

        {"tag": "D1_l1_only", "label": "L1 only (λ=100, no adversarial)",
         "rubric": "loss", "overrides": {"lambda_l1": 100.0, "gan_weight": 0.0}},

        {"tag": "D2_gan_only", "label": "Adversarial only (λ=0)",
         "rubric": "loss", "overrides": {"lambda_l1": 0.0}},

        {"tag": "D3_lambda10", "label": "λ_L1 = 10",
         "rubric": "loss", "overrides": {"lambda_l1": 10.0}},
    ]


def run_one(spec: dict, base_args: argparse.Namespace) -> dict:
    """Run a single ablation config and return its summary row."""
    args = argparse.Namespace(**vars(base_args))
    args.tag = spec["tag"]

    for k, v in spec["overrides"].items():
        setattr(args, k, v)

    print(f"\n  --- {spec['tag']}: {spec['label']} ---")
    hist = train(args)

    evals = [r["val"] for r in hist["epochs"] if "val" in r]
    final_val = evals[-1] if evals else {}

    # One epoch's score is too noisy to rank on -- within a single baseline run
    # pixel accuracy swings by more than the effects we are trying to measure.
    # Average the last few evaluations instead, and keep the best and the
    # spread so the write-up can state how shaky a given row is.
    tail = evals[-3:] if len(evals) >= 3 else evals
    keys = set().union(*(e.keys() for e in tail)) if tail else set()
    stable_val = {k: float(np.mean([e[k] for e in tail if k in e])) for k in keys}
    spread = {k: float(np.std([e[k] for e in tail if k in e])) for k in keys}
    best_val = (max(evals, key=lambda e: e.get("pixel_accuracy", -1))
                if evals else {})

    return {
        "tag": spec["tag"],
        "label": spec["label"],
        "rubric": spec["rubric"],
        "overrides": spec["overrides"],
        "final_val": final_val,
        "stable_val": stable_val,
        "stable_spread": spread,
        "best_val": best_val,
        "n_evals": len(evals),
        "total_seconds": hist.get("total_seconds"),
        "peak_gpu_mem_gb": hist.get("peak_gpu_mem_gb"),
        "generator_params": hist["config"]["generator_params"],
        "discriminator_params": hist["config"]["discriminator_params"],
    }


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
def fig_cost_profile(prof: dict, out: Path) -> None:
    gens = [(k, v) for k, v in prof["generators"].items() if "error" not in v]
    if not gens:
        return
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.7))
    names = [k for k, _ in gens]

    for ax, key, title, fmt in (
        (axes[0], "params_m", "Parameters (M)", "{:.1f}"),
        (axes[1], "peak_mem_gb", "Peak VRAM (GB)", "{:.2f}"),
        (axes[2], "imgs_per_sec", "Throughput (img/s)", "{:.0f}"),
    ):
        vals = [v.get(key, float("nan")) for _, v in gens]
        # VRAM is unavailable off-GPU; show the panel as unmeasured rather
        # than crashing the whole figure.
        if not np.isfinite(vals).any():
            ax.text(0.5, 0.5, f"{title}\nnot measured\n(CPU run)", ha="center",
                    va="center", transform=ax.transAxes, fontsize=11,
                    color=INK_MUTED)
            ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
            for s in ax.spines.values():
                s.set_visible(False)
            continue
        vals = [0.0 if not np.isfinite(v) else v for v in vals]
        colors = [STATUS["good"] if n == "unet" else SERIES[0] for n in names]
        bars = ax.bar(names, vals, color=colors, width=0.6)
        ax.set_title(title)
        clean_axes(ax); bar_labels(ax, bars, fmt, pad=4)
        ax.set_ylim(0, max(max(vals) * 1.25, 1e-6))
        ax.tick_params(axis="x", rotation=12)

    if prof.get("total_vram_gb") and np.isfinite(
            [v.get("peak_mem_gb", float("nan")) for _, v in gens]).any():
        axes[1].axhline(prof["total_vram_gb"], color=STATUS["critical"],
                        linestyle="--", linewidth=1.6)
        axes[1].annotate(f"card limit {prof['total_vram_gb']:.0f} GB",
                         (len(names) - 0.5, prof["total_vram_gb"]),
                         xytext=(0, 4), textcoords="offset points", ha="right",
                         fontsize=9, color=STATUS["critical"], fontweight="bold")
        axes[1].set_ylim(0, prof["total_vram_gb"] * 1.15)

    fig.suptitle(f"Generator cost on {prof['device']} "
                 f"(batch {prof['batch_size']} @ {prof['crop_size']}px)",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def fig_ablation(rows: list[dict], out: Path, metric: str = "pixel_accuracy") -> None:
    rows = [r for r in rows if metric in (r.get("stable_val") or {})]
    if not rows:
        print(f"    (no rows carry '{metric}' -- skipping ablation figure)")
        return
    rows = sorted(rows, key=lambda r: r["stable_val"][metric])

    labels = [r["label"] for r in rows]
    vals = [r["stable_val"][metric] * 100 for r in rows]
    colors = [STATUS["good"] if r["tag"].startswith("A0") else SERIES[0] for r in rows]

    fig, ax = plt.subplots(figsize=(10, 0.52 * len(rows) + 2.0))
    bars = ax.barh(labels, vals, color=colors, height=0.62)
    ax.set_xlabel(f"{metric.replace('_', ' ').title()} (%)")
    ax.set_title("Ablation — one variable changed per row, short runs")
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.grid(axis="x"); ax.grid(axis="y", visible=False)
    for b, v in zip(bars, vals):
        ax.annotate(f"{v:.1f}%", (v, b.get_y() + b.get_height() / 2),
                    xytext=(5, 0), textcoords="offset points", va="center",
                    fontsize=10, color=INK_SECONDARY)
    ax.set_xlim(0, max(max(vals) * 1.16, 1.0))      # guard the all-zero case

    base = next((r for r in rows if r["tag"].startswith("A0")), None)
    if base:
        ax.axvline(base["stable_val"][metric] * 100, color=STATUS["good"],
                   linestyle="--", linewidth=1.5, zorder=0)
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile-only", action="store_true",
                    help="cost profile only, no training")
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--limit-train", type=int, default=600)
    ap.add_argument("--limit-val", type=int, default=120)
    ap.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    ap.add_argument("--direction", default=config.DEFAULT_DIRECTION, choices=config.DIRECTIONS)
    ap.add_argument("--only", nargs="*", default=None, help="run only these tags")
    ap.add_argument("--skip-done", action="store_true",
                    help="skip configs already present in the results file")
    ap.add_argument("--replicates", type=int, default=3,
                    help="extra baseline runs at different seeds, to measure "
                         "run-to-run noise. Without this there is no way to "
                         "tell a real effect from variance. 0 disables.")
    ap.add_argument("--workers", type=int, default=config.NUM_WORKERS)
    args = ap.parse_args()

    apply_style()
    print("=" * 70)
    print("04  ABLATIONS & COST PROFILE")
    print("=" * 70)

    print("\nPHASE A -- cost profile")
    prof = phase_a(args.batch_size, config.CROP_SIZE)
    (config.RESULTS_DIR / "04_cost_profile.json").write_text(json.dumps(prof, indent=2))
    fig_cost_profile(prof, config.FIGURE_DIR / "04_cost_profile.png")

    if args.profile_only:
        print("\n  --profile-only set; stopping before training runs.")
        return

    print("\nPHASE B -- ablation sweep")
    results_path = config.RESULTS_DIR / "04_ablations.json"
    rows = json.loads(results_path.read_text()) if results_path.exists() else []
    done = {r["tag"] for r in rows}

    base = train_parser().parse_args([])
    base.epochs = args.epochs
    base.epochs_decay = 0
    base.batch_size = args.batch_size
    base.limit_train = args.limit_train
    base.limit_val = args.limit_val
    base.direction = args.direction
    base.workers = args.workers
    base.eval_every = max(1, args.epochs // 6)   # ~6 evals per run
    base.save_every = 10_000            # ablation checkpoints are not needed

    grid = ablation_grid()
    if args.only:
        grid = [g for g in grid if g["tag"] in args.only]

    est = len(grid) * args.epochs * args.limit_train / max(1, args.batch_size)
    print(f"  {len(grid)} configs x {args.epochs} epochs on {args.limit_train} images")
    print(f"  (~{est:.0f} total iterations -- start with --profile-only to sanity check)\n")

    for spec in grid:
        if args.skip_done and spec["tag"] in done:
            print(f"  skip {spec['tag']} (already done)")
            continue
        try:
            row = run_one(spec, base)
            rows = [r for r in rows if r["tag"] != row["tag"]] + [row]
            results_path.write_text(json.dumps(rows, indent=2))   # save as we go
        except Exception as e:
            print(f"  !! {spec['tag']} failed: {e}")
            rows = [r for r in rows if r["tag"] != spec["tag"]] + [
                {"tag": spec["tag"], "label": spec["label"],
                 "rubric": spec["rubric"], "error": str(e)[:300], "final_val": {}}]
            results_path.write_text(json.dumps(rows, indent=2))

    # --- noise floor -------------------------------------------------------
    noise = None
    if args.replicates and args.replicates > 1:
        print(f"\n  measuring noise floor: baseline x {args.replicates} seeds")
        # The baseline already IS one sample at the default seed, so start the
        # replicates at a different seed and fold A0's own score in -- one
        # fewer run for the same estimate.
        accs = []
        base_row = next((x for x in rows if x["tag"] == "A0_baseline"
                         and x.get("stable_val")), None)
        if base_row:
            accs.append(base_row["stable_val"]["pixel_accuracy"])
        for r in range(1, args.replicates):
            tag = f"N{r}_seed{1337 + r * 101}"
            existing = next((x for x in rows if x["tag"] == tag), None)
            if args.skip_done and existing:
                print(f"    skip {tag} (already done)")
                accs.append(existing["stable_val"]["pixel_accuracy"])
                continue
            rep = dict(base.__dict__)
            rep_args = argparse.Namespace(**rep)
            rep_args.seed = 1337 + r * 101
            row = run_one({"tag": tag, "label": f"Baseline, seed {rep_args.seed}",
                           "rubric": "noise", "overrides": {}}, rep_args)
            rows = [x for x in rows if x["tag"] != tag] + [row]
            results_path.write_text(json.dumps(rows, indent=2))
            accs.append(row["stable_val"].get("pixel_accuracy", float("nan")))

        accs = [a for a in accs if a == a]
        if len(accs) > 1:
            noise = {"seeds": args.replicates,
                     "pixel_accuracy_values": accs,
                     "std": float(np.std(accs)),
                     "range": float(max(accs) - min(accs))}
            print(f"    seeds gave: " + ", ".join(f"{a*100:.2f}%" for a in accs))
            print(f"    std {noise['std']*100:.2f} pts, "
                  f"range {noise['range']*100:.2f} pts")
            print(f"    -> treat gaps under ~{noise['range']*100:.1f} points as noise")
            (config.RESULTS_DIR / "04_noise_floor.json").write_text(
                json.dumps(noise, indent=2))

    print("\n  summary:")
    base_pa = next((r["stable_val"].get("pixel_accuracy") for r in rows
                    if r["tag"] == "A0_baseline" and r.get("stable_val")), None)
    for r in sorted(rows, key=lambda r: -(r.get("stable_val") or {}).get("pixel_accuracy", -1)):
        pa = (r.get("stable_val") or {}).get("pixel_accuracy")
        # `is None`, not truthiness -- a real 0.0 is a result, not a failure.
        status = "FAILED" if pa is None else f"pixel_acc={pa*100:.2f}%"
        if pa is not None and base_pa is not None and noise:
            delta = (pa - base_pa) * 100
            status += (f"  ({delta:+.2f} vs baseline"
                       + ("" if abs(delta) > noise["range"] * 100
                          else ", WITHIN NOISE") + ")")
        if "error" in r:
            status = f"ERROR: {r['error'][:50]}"
        print(f"    {r['tag']:18s} {r['label']:42s} {status}")

    fig_ablation(rows, config.FIGURE_DIR / "04_ablation.png")
    print(f"\n  results -> {results_path}")


if __name__ == "__main__":
    main()
