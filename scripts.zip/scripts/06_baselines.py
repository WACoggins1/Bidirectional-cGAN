"""
Trivial baselines -- the floor every reported score has to clear.

Motivation, discovered the hard way. Map tiles are ~80% flat area fill, and
the pixel-accuracy protocol counts a pixel correct when all three channels are
within +/-20. Those two facts together mean a model that emits ONE constant
colour over the whole tile already scores around 60-65%. A headline accuracy
of 72% sounds strong and is, in fact, eight points above doing nothing.

So this script measures the floor instead of assuming it:

  constant-colour   the single RGB value that maximises pixel accuracy on the
                    TRAINING split, then scored on val/test. This is the
                    "predict background everywhere" strategy.
  copy-input        return the satellite tile unchanged. Sanity check: should
                    score near zero and confirms the metric is not degenerate.
  per-tile-oracle   the best constant colour chosen per tile with the ground
                    truth in hand. Not achievable, but it bounds how much of
                    the score is reachable without modelling structure at all.

Report your model against these, not against nothing.

Run:  python scripts/06_baselines.py [--split val] [--limit 200]
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.dataset import RESAMPLE, SplitManifest, build_splits, load_pair
from src.metrics import evaluate_batch, pixel_accuracy, road_recall
from src.viz_style import (INK_MUTED, INK_SECONDARY, SERIES, STATUS, apply_style,
                           bar_labels, clean_axes, save)

import matplotlib.pyplot as plt


def load_maps(paths: list[str], limit: int | None) -> np.ndarray:
    """Map halves at training resolution, as a uint8 (N, H, W, 3) array."""
    paths = paths[:limit] if limit else paths
    out = []
    for i, p in enumerate(paths):
        if i and i % 100 == 0:
            print(f"    {i}/{len(paths)}")
        _, mp = load_pair(Path(p))
        mp = mp.resize((config.CROP_SIZE, config.CROP_SIZE),
                       RESAMPLE[config.MAP_INTERP])
        out.append(np.asarray(mp, dtype=np.uint8))
    return np.stack(out)


def load_sats(paths: list[str], limit: int | None) -> np.ndarray:
    paths = paths[:limit] if limit else paths
    out = []
    for p in paths:
        sat, _ = load_pair(Path(p))
        sat = sat.resize((config.CROP_SIZE, config.CROP_SIZE),
                         RESAMPLE[config.SATELLITE_INTERP])
        out.append(np.asarray(sat, dtype=np.uint8))
    return np.stack(out)


def best_constant_colour(maps: np.ndarray, n_candidates: int = 48,
                         seed: int = 0) -> tuple[np.ndarray, float]:
    """
    The constant RGB that maximises pixel accuracy on this set.

    Candidates come from the actual colours present -- quantised and ranked by
    frequency -- rather than a grid search, because the winner is always one of
    the dominant fills.
    """
    flat = maps.reshape(-1, 3)
    idx = np.random.default_rng(seed).choice(len(flat),
                                             size=min(400_000, len(flat)),
                                             replace=False)
    sample = flat[idx].astype(np.int32)

    q = sample >> 3
    codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
    counts = np.bincount(codes, minlength=32768)
    top = np.argsort(-counts)[:n_candidates]
    cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4

    best, best_acc = None, -1.0
    for c in cands.astype(np.int16):
        acc = float((np.abs(sample - c).max(axis=1) < config.PIXEL_ACC_TOLERANCE).mean())
        if acc > best_acc:
            best, best_acc = c, acc
    return best.astype(np.uint8), best_acc


def per_tile_oracle(maps: np.ndarray) -> float:
    """Upper bound for constant-per-tile prediction, with ground truth known."""
    accs = []
    for m in maps:
        flat = m.reshape(-1, 3).astype(np.int32)
        q = flat >> 3
        codes = (q[:, 0] * 32 + q[:, 1]) * 32 + q[:, 2]
        top = np.argsort(-np.bincount(codes, minlength=32768))[:12]
        cands = np.stack([top // 1024, (top // 32) % 32, top % 32], axis=1) * 8 + 4
        accs.append(max(
            float((np.abs(flat - c).max(axis=1) < config.PIXEL_ACC_TOLERANCE).mean())
            for c in cands.astype(np.int16)))
    return float(np.mean(accs))


def fig_baselines(rows: list[dict], out: Path) -> None:
    fig, ax = plt.subplots(figsize=(9.5, 4.0))
    names = [r["name"] for r in rows]
    vals = [r["pixel_accuracy"] * 100 for r in rows]
    colors = [STATUS["critical"] if r.get("trivial") else SERIES[0] for r in rows]

    bars = ax.bar(names, vals, color=colors, width=0.6)
    ax.set_ylabel("Pixel accuracy (%)")
    ax.set_title("Every score needs a floor — a constant colour already clears 60%")
    clean_axes(ax)
    bar_labels(ax, bars, "{:.1f}%", pad=4)
    ax.set_ylim(0, max(vals) * 1.25)
    ax.tick_params(axis="x", rotation=12)

    floor = max((r["pixel_accuracy"] for r in rows if r.get("trivial")), default=None)
    if floor:
        ax.axhline(floor * 100, color=STATUS["critical"], linestyle="--", linewidth=1.6)
        ax.annotate("trivial floor", (len(rows) - 0.5, floor * 100),
                    xytext=(0, 5), textcoords="offset points", ha="right",
                    fontsize=10, color=STATUS["critical"], fontweight="bold")
    fig.tight_layout()
    save(fig, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="val", choices=["val", "test"])
    ap.add_argument("--limit", type=int, default=200)
    args = ap.parse_args()

    apply_style()
    print("=" * 70)
    print("06  TRIVIAL BASELINES")
    print("=" * 70)

    mp_path = config.RESULTS_DIR / "split_manifest.json"
    manifest = (SplitManifest.load(mp_path) if mp_path.exists()
                else build_splits(save_to=mp_path))

    print(f"\n  loading train maps (to fit the constant)...")
    train_maps = load_maps(manifest.train, min(args.limit, 200))
    const, fit_acc = best_constant_colour(train_maps)
    print(f"    best constant = RGB{tuple(int(v) for v in const)} "
          f"(#{''.join(f'{v:02x}' for v in const)}), {fit_acc*100:.1f}% on train")

    print(f"\n  loading {args.split} maps...")
    eval_maps = load_maps(getattr(manifest, args.split), args.limit)
    eval_sats = load_sats(getattr(manifest, args.split), args.limit)

    rows = []

    # 1. constant colour, fitted on TRAIN only
    pred = np.broadcast_to(const, eval_maps.shape)
    m = evaluate_batch(np.ascontiguousarray(pred), eval_maps)
    rows.append({"name": "Constant colour", "trivial": True,
                 "colour": f"#{''.join(f'{v:02x}' for v in const)}", **m})

    # 2. copy the input through unchanged
    m = evaluate_batch(eval_sats, eval_maps)
    rows.append({"name": "Copy input", "trivial": True, **m})

    # 3. unreachable per-tile oracle
    rows.append({"name": "Per-tile oracle", "trivial": True,
                 "pixel_accuracy": per_tile_oracle(eval_maps),
                 "note": "not achievable -- uses ground truth"})

    print(f"\n  {'baseline':20s} {'pixel acc':>10s} {'ssim':>7s} {'road recall':>12s}")
    for r in rows:
        print(f"  {r['name']:20s} {r['pixel_accuracy']*100:9.1f}% "
              f"{r.get('ssim', float('nan')):7.3f} "
              f"{r.get('road_recall', float('nan')):11.3f}")

    floor = max(r["pixel_accuracy"] for r in rows
                if r.get("trivial") and r["name"] != "Per-tile oracle")
    print(f"\n  FLOOR: {floor*100:.1f}% pixel accuracy is reachable with no model "
          f"at all.")
    print(f"  Report your model's margin OVER this, not the raw number.")
    print(f"  Note road recall for the constant baseline: a flat fill draws no")
    print(f"  roads, so that column is the honest measure of learning here.")

    out = {"split": args.split, "n_tiles": int(len(eval_maps)),
           "constant_colour": f"#{''.join(f'{v:02x}' for v in const)}",
           "trivial_floor_pixel_accuracy": float(floor),
           "baselines": rows}
    (config.RESULTS_DIR / "06_baselines.json").write_text(json.dumps(out, indent=2))
    fig_baselines(rows, config.FIGURE_DIR / "06_baselines.png")
    print(f"\n  results -> {config.RESULTS_DIR / '06_baselines.json'}")


if __name__ == "__main__":
    main()
