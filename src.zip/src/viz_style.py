"""
Shared matplotlib styling so every figure in the deck reads as one system.

Colours come from a categorical palette validated for colour-vision
deficiency. Charts here use at most three series, which is the range that
clears the all-pairs separation floor.
"""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")                     # headless: no display needed
import matplotlib.pyplot as plt

# Categorical slots, in fixed order -- never cycled, never reordered.
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100",
          "#e87ba4", "#008300", "#4a3aa7", "#e34948"]

INK = "#1a1a1a" #darkest text/marker color
SURFACE = "#fcfcfb"
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
GRIDLINE = "#e1e0d9"
BASELINE = "#c3c2b7"


STATUS = {"good": "#0ca30c", "warn": "#e8590c", "warning": "#fab219",
          "serious": "#ec835a", "critical": "#d03b3b"}

# Sequential blue ramp, light -> dark.
SEQUENTIAL = ["#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec",
              "#5598e7", "#3987e5", "#2a78d6", "#256abf", "#1c5cab"]


def apply_style() -> None:
    """Install the house style. Call once at the top of each script."""
    plt.rcParams.update({
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.edgecolor": BASELINE,
        "axes.labelcolor": INK_SECONDARY,
        "axes.titlecolor": INK_PRIMARY,
        "axes.titleweight": "bold",
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "axes.grid": True,
        "axes.axisbelow": True,
        "grid.color": GRIDLINE,
        "grid.linewidth": 0.8,
        "xtick.color": INK_MUTED,
        "ytick.color": INK_MUTED,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "text.color": INK_PRIMARY,
        "legend.frameon": False,
        "legend.fontsize": 10,
        "lines.linewidth": 2.0,
        "lines.markersize": 8,
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans"],
        "figure.dpi": 130,
        "savefig.dpi": 200,
        "savefig.bbox": "tight",
    })


def clean_axes(ax, keep_left: bool = True) -> None:
    """Drop chartjunk: top/right spines off, horizontal grid only."""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(keep_left)
    ax.grid(axis="y")
    ax.grid(axis="x", visible=False)


def bar_labels(ax, bars, fmt: str = "{:.1f}", pad: float = 3.0) -> None:
    """Direct value labels above bars -- so the axis is a reference, not a lookup."""
    for b in bars:
        h = b.get_height()
        ax.annotate(fmt.format(h), (b.get_x() + b.get_width() / 2, h),
                    ha="center", va="bottom", fontsize=10,
                    color=INK_SECONDARY, xytext=(0, pad), textcoords="offset points")


def save(fig, path, close: bool = True) -> None:
    fig.savefig(path)
    if close:
        plt.close(fig)
    print(f"    figure -> {path}")
