"""
Evaluation metrics.

pixel_accuracy() implements the protocol used throughout the satellite-to-map
literature: a generated pixel counts as correct when its absolute difference
from ground truth is below a tolerance in ALL three channels. It is the metric
our baseline table is quoted in, so it has to match.

road_recall() is ours. Overall pixel accuracy is dominated by flat background,
which hides the failure mode every paper in this area reports -- thin road
lines being dropped. Reporting road pixels separately keeps that visible.
"""
from __future__ import annotations

import numpy as np

try:
    from skimage.metrics import structural_similarity as _ssim
    _HAVE_SKIMAGE = True
except ImportError:                                            # pragma: no cover
    _HAVE_SKIMAGE = False


def pixel_accuracy(pred: np.ndarray, target: np.ndarray, tolerance: int = 20) -> float:
    """
    Fraction of pixels whose max per-channel absolute error is below tolerance.

    Args:
        pred, target: uint8 arrays, (H, W, 3) or (N, H, W, 3).
    """
    pred = pred.astype(np.int16)
    target = target.astype(np.int16)
    diff = np.abs(pred - target).max(axis=-1)
    return float((diff < tolerance).mean())


def psnr(pred: np.ndarray, target: np.ndarray, data_range: int = 255) -> float:
    mse = np.mean((pred.astype(np.float64) - target.astype(np.float64)) ** 2)
    if mse == 0:
        return float("inf")
    return float(10.0 * np.log10((data_range ** 2) / mse))


def ssim(pred: np.ndarray, target: np.ndarray) -> float:
    """Mean SSIM over the batch. Requires scikit-image."""
    if not _HAVE_SKIMAGE:
        raise ImportError("scikit-image is required for SSIM (pip install scikit-image)")
    if pred.ndim == 4:
        return float(np.mean([ssim(p, t) for p, t in zip(pred, target)]))
    return float(_ssim(target, pred, channel_axis=-1, data_range=255))


def l1_error(pred: np.ndarray, target: np.ndarray) -> float:
    """Mean absolute error in [0,1] units."""
    return float(np.abs(pred.astype(np.float64) - target.astype(np.float64)).mean() / 255.0)


def road_mask(map_img: np.ndarray, lightness_threshold: int = 246,
              saturation_threshold: int = 18) -> np.ndarray:
    """
    Approximate road mask for a Google-Maps-style tile.

    Roads render as near-white, low-saturation ribbons; background is a
    slightly darker beige. Bright AND desaturated isolates them well enough
    for a diagnostic. Returns a bool (H, W) array.
    """
    arr = map_img.astype(np.int16)
    mx = arr.max(axis=-1)
    mn = arr.min(axis=-1)
    return (mx >= lightness_threshold) & ((mx - mn) <= saturation_threshold)


def road_recall(pred: np.ndarray, target: np.ndarray, tolerance: int = 20) -> float:
    """
    Fraction of true road pixels the prediction also renders as road.

    This compares road MASKS, not pixel values, and that is deliberate. On
    this dataset the background fill (#f2f0ea) and the local-road colour
    (#fdfdfb) differ by at most 17 per channel -- inside the +/-20 tolerance
    the pixel-accuracy protocol uses. A value-based road metric therefore
    scores a blank beige rectangle as drawing every road perfectly, which is
    exactly what a first version of this function did. Classifying both sides
    and intersecting the masks is immune to that collapse.

    `tolerance` is accepted for call-signature compatibility and unused.
    """
    if pred.ndim == 4:
        vals = [road_recall(p, t) for p, t in zip(pred, target)]
        vals = [v for v in vals if not np.isnan(v)]
        return float(np.mean(vals)) if vals else float("nan")

    true_mask = road_mask(target)
    if true_mask.sum() == 0:
        return float("nan")
    return float((road_mask(pred) & true_mask).sum() / true_mask.sum())


def road_iou(pred: np.ndarray, target: np.ndarray) -> float:
    """
    Intersection-over-union of the road masks.

    Recall alone is gameable -- painting the whole tile road-white scores 1.0.
    IoU penalises that, so report both.
    """
    if pred.ndim == 4:
        vals = [road_iou(p, t) for p, t in zip(pred, target)]
        vals = [v for v in vals if not np.isnan(v)]
        return float(np.mean(vals)) if vals else float("nan")

    a, b = road_mask(pred), road_mask(target)
    union = (a | b).sum()
    if union == 0:
        return float("nan")
    return float((a & b).sum() / union)


def evaluate_batch(pred: np.ndarray, target: np.ndarray, tolerance: int = 20) -> dict:
    """All metrics for one batch of uint8 images. Returns a plain dict."""
    out = {
        "pixel_accuracy": pixel_accuracy(pred, target, tolerance),
        "psnr": psnr(pred, target),
        "l1": l1_error(pred, target),
    }
    if _HAVE_SKIMAGE:
        out["ssim"] = ssim(pred, target)
    rr = road_recall(pred, target)
    if not np.isnan(rr):
        out["road_recall"] = rr
    ri = road_iou(pred, target)
    if not np.isnan(ri):
        out["road_iou"] = ri
    return out


def aggregate(dicts: list[dict]) -> dict:
    """Mean of a list of metric dicts, skipping NaNs."""
    if not dicts:
        return {}
    keys = set().union(*(d.keys() for d in dicts))
    out = {}
    for k in sorted(keys):
        vals = [d[k] for d in dicts if k in d and not np.isnan(d[k]) and np.isfinite(d[k])]
        if vals:
            out[k] = float(np.mean(vals))
    return out

# The exact palette entries the degeneracy argument turns on. Measured from
# the dataset in scripts/01_dataset_stats.py, hard-coded here so the critical
# threshold can be computed without re-reading the data.
BACKGROUND_RGB = (242, 240, 234)      # #f2f0ea
ROAD_LOCAL_RGB = (253, 253, 251)      # #fdfdfb


def critical_tolerance() -> int:
    """
    The tolerance at which pixel accuracy stops being able to see roads.

    A pixel is scored correct when every channel is within `tolerance`. Road
    and background differ by this much at most, so any tolerance strictly
    greater than this value classifies a blank background as a correct road.
    """
    return int(max(abs(a - b) for a, b in zip(BACKGROUND_RGB, ROAD_LOCAL_RGB)))


def road_precision(pred, target) -> float:
    """
    Of the pixels drawn as road, the fraction that really are road.

    The other half of road_recall. Recall alone is gamed by painting the whole
    tile road-coloured; precision alone is gamed by drawing almost nothing.
    Reporting both is what makes the error analysis say which failure you have.
    """
    if pred.ndim == 4:
        vals = [road_precision(p, t) for p, t in zip(pred, target)]
        vals = [v for v in vals if not np.isnan(v)]
        return float(np.mean(vals)) if vals else float("nan")
    a, b = road_mask(pred), road_mask(target)
    if a.sum() == 0:
        return float("nan")
    return float((a & b).sum() / a.sum())