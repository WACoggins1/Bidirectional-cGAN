"""
pix2pix training loop.

Usage:
    python -m src.train --direction sat2map --epochs 200
    python -m src.train --generator unet_noskip --epochs 20 --tag noskip

Everything the deck needs is written to outputs/results/<tag>_history.json:
per-epoch losses, per-epoch validation metrics, wall-clock timing, and peak
GPU memory. Nothing in the deck has to be typed in by hand.
"""
from __future__ import annotations
import os as _os
# Windows conda+pip mixes two OpenMP runtimes (conda's libomp.dll and the
# libiomp5md.dll bundled with pip's torch) and Intel's aborts on the second.
# This must be set BEFORE torch or sklearn load, so it sits here rather than
# in config.py. Threads are pinned to 1 alongside it: the crash workaround
# alone leaves two thread pools contending, which is what the "may silently
# produce incorrect results" warning is about.
_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")


import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

import config

# Piping stdout (a redirect, or PowerShell's Tee-Object) flips Python from
# line-buffered to block-buffered, so a long run looks frozen for minutes
# while output sits in an 8KB buffer. Force line buffering so progress is
# visible regardless of how this is invoked.
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except (AttributeError, ValueError):        # pre-3.7, or a replaced stream
    pass
from src.dataset import MapsDataset, SplitManifest, build_splits, denormalize
from src.metrics import aggregate, evaluate_batch
from src.models import GANLoss, build_discriminator, build_generator, count_parameters


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_or_build_manifest(path: Path) -> SplitManifest:
    if path.exists():
        return SplitManifest.load(path)
    print("Split manifest not found -- building it now.")
    return build_splits(save_to=path)


@torch.no_grad()
def evaluate(netG, loader, device, max_batches: int | None = None) -> dict:
    netG.eval()
    per_batch = []
    for i, batch in enumerate(loader):
        if max_batches is not None and i >= max_batches:
            break
        src = batch["src"].to(device, non_blocking=True)
        fake = netG(src)
        per_batch.append(evaluate_batch(denormalize(fake), denormalize(batch["tgt"])))
    netG.train()
    return aggregate(per_batch)


def lambda_rule(epoch: int, n_epochs: int, n_epochs_decay: int) -> float:
    """Constant LR for n_epochs, then linear decay to zero."""
    if epoch < n_epochs:
        return 1.0
    return max(0.0, 1.0 - (epoch - n_epochs) / max(1, n_epochs_decay))


def train(args) -> dict:
    device = get_device()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    manifest = load_or_build_manifest(config.RESULTS_DIR / "split_manifest.json")

    train_paths = manifest.train[:args.limit_train] if args.limit_train else manifest.train
    val_paths = manifest.val[:args.limit_val] if args.limit_val else manifest.val

    # Interpolation is overridable so the ablation can measure the downstream
    # cost of a resize filter, not just its static palette drift.
    interp = {"sat_interp": args.sat_interp, "map_interp": args.map_interp}

    train_ds = MapsDataset(train_paths, direction=args.direction,
                           augment=not args.no_augment, seed=args.seed, **interp)
    val_ds = MapsDataset(val_paths, direction=args.direction, augment=False, **interp)

    # Seed the shuffle independently of model init: otherwise a bigger
    # generator consumes more of the global RNG stream and every config sees
    # its data in a different order, confounding the comparison.
    loader_gen = torch.Generator()
    loader_gen.manual_seed(args.seed)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.workers, pin_memory=(device.type == "cuda"),
                              drop_last=True, generator=loader_gen)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.workers, pin_memory=(device.type == "cuda"))

    netG = build_generator(args.generator).to(device)
    netD = build_discriminator(args.discriminator, input_nc=6).to(device)

    criterionGAN = GANLoss().to(device)
    criterionL1 = torch.nn.L1Loss()

    optG = torch.optim.Adam(netG.parameters(), lr=args.lr, betas=(config.BETA1, config.BETA2))
    optD = torch.optim.Adam(netD.parameters(), lr=args.lr, betas=(config.BETA1, config.BETA2))

    schedG = torch.optim.lr_scheduler.LambdaLR(
        optG, lambda e: lambda_rule(e, args.epochs, args.epochs_decay))
    schedD = torch.optim.lr_scheduler.LambdaLR(
        optD, lambda e: lambda_rule(e, args.epochs, args.epochs_decay))

    use_amp = args.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    tag = args.tag or f"{args.direction}_{args.generator}_{args.discriminator}"
    history = {
        "tag": tag,
        "config": {
            "direction": args.direction, "generator": args.generator,
            "discriminator": args.discriminator, "lambda_l1": args.lambda_l1,
            "gan_weight": args.gan_weight,
            "batch_size": args.batch_size, "lr": args.lr, "epochs": args.epochs,
            "augment": not args.no_augment, "amp": use_amp, "seed": args.seed,
            "crop_size": config.CROP_SIZE,
            "sat_interp": args.sat_interp, "map_interp": args.map_interp,
            "n_train": len(train_ds), "n_val": len(val_ds),
            "generator_params": count_parameters(netG),
            "discriminator_params": count_parameters(netD),
            "device": torch.cuda.get_device_name(0) if device.type == "cuda" else "cpu",
        },
        "epochs": [],
    }

    total_epochs = args.epochs + args.epochs_decay
    print(f"[{tag}] G={args.generator} ({count_parameters(netG)/1e6:.1f}M)  "
          f"D={args.discriminator} ({count_parameters(netD)/1e6:.1f}M)  "
          f"train={len(train_ds)} val={len(val_ds)} device={device}")
    # --epochs is only the constant-LR phase; --epochs-decay adds a linear
    # decay tail on top and defaults to 100. Stating the total up front stops
    # "--epochs 12" quietly becoming a 112-epoch run.
    print(f"[{tag}] {total_epochs} epochs total = {args.epochs} at constant LR "
          f"+ {args.epochs_decay} decaying"
          + ("   (pass --epochs-decay 0 for a short run)"
             if args.epochs_decay > args.epochs else ""))

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    run_start = time.time()
    for epoch in range(args.epochs + args.epochs_decay):
        epoch_start = time.time()
        sums = {"G_GAN": 0.0, "G_L1": 0.0, "D_real": 0.0, "D_fake": 0.0}
        n_batches = 0

        for batch in train_loader:
            src = batch["src"].to(device, non_blocking=True)
            tgt = batch["tgt"].to(device, non_blocking=True)

            use_gan = args.gan_weight > 0

            with torch.amp.autocast("cuda", enabled=use_amp):
                fake = netG(src)

                if use_gan:
                    # ---- Discriminator ----
                    # detach so generator grads do not flow through D's update
                    pred_fake = netD(torch.cat([src, fake.detach()], dim=1))
                    loss_D_fake = criterionGAN(pred_fake, False)
                    pred_real = netD(torch.cat([src, tgt], dim=1))
                    loss_D_real = criterionGAN(pred_real, True)
                    loss_D = (loss_D_fake + loss_D_real) * 0.5

            if use_gan:
                optD.zero_grad(set_to_none=True)
                scaler.scale(loss_D).backward()
                scaler.step(optD)
            else:
                # L1-only control: D is never trained, so its losses are
                # reported as zero rather than left stale from a prior step.
                loss_D_fake = loss_D_real = torch.zeros((), device=device)

            with torch.amp.autocast("cuda", enabled=use_amp):
                # ---- Generator ----
                if use_gan:
                    pred_fake = netD(torch.cat([src, fake], dim=1))
                    loss_G_GAN = criterionGAN(pred_fake, True) * args.gan_weight
                else:
                    loss_G_GAN = torch.zeros((), device=device)
                loss_G_L1 = criterionL1(fake, tgt) * args.lambda_l1
                loss_G = loss_G_GAN + loss_G_L1

            optG.zero_grad(set_to_none=True)
            scaler.scale(loss_G).backward()
            scaler.step(optG)
            scaler.update()

            sums["G_GAN"] += loss_G_GAN.item()
            sums["G_L1"] += loss_G_L1.item()
            sums["D_real"] += loss_D_real.item()
            sums["D_fake"] += loss_D_fake.item()
            n_batches += 1

        schedG.step()
        schedD.step()

        losses = {k: v / max(1, n_batches) for k, v in sums.items()}
        record = {
            "epoch": epoch + 1,
            "losses": losses,
            "seconds": time.time() - epoch_start,
            "lr": optG.param_groups[0]["lr"],
        }

        if (epoch + 1) % args.eval_every == 0 or epoch == 0:
            record["val"] = evaluate(netG, val_loader, device, args.eval_batches)
            msg = "  ".join(f"{k}={v:.4f}" for k, v in record["val"].items())
            print(f"  epoch {epoch+1:3d}  G_L1={losses['G_L1']:.3f} "
                  f"D={losses['D_real']+losses['D_fake']:.3f}  {msg}  "
                  f"({record['seconds']:.0f}s)")
        else:
            print(f"  epoch {epoch+1:3d}  G_L1={losses['G_L1']:.3f} "
                  f"D={losses['D_real']+losses['D_fake']:.3f}  ({record['seconds']:.0f}s)")

        history["epochs"].append(record)

        if (epoch + 1) % args.save_every == 0 or epoch == args.epochs + args.epochs_decay - 1:
            torch.save({"epoch": epoch + 1,
                        "netG": netG.state_dict(),
                        "netD": netD.state_dict(),
                        "config": history["config"]},
                       config.CHECKPOINT_DIR / f"{tag}_latest.pt")

    history["total_seconds"] = time.time() - run_start
    if device.type == "cuda":
        history["peak_gpu_mem_gb"] = torch.cuda.max_memory_allocated() / 1e9

    out = config.RESULTS_DIR / f"{tag}_history.json"
    out.write_text(json.dumps(history, indent=2))
    print(f"[{tag}] done in {history['total_seconds']/60:.1f} min -> {out}")
    return history


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Train pix2pix on the Maps dataset")
    p.add_argument("--direction", default=config.DEFAULT_DIRECTION, choices=config.DIRECTIONS)
    p.add_argument("--generator", default="unet")
    p.add_argument("--discriminator", default="patch70")
    p.add_argument("--epochs", type=int, default=config.N_EPOCHS)
    p.add_argument("--epochs-decay", type=int, default=config.N_EPOCHS_DECAY,
                   help="extra epochs with the LR decaying linearly to zero, "
                        "ON TOP of --epochs. Defaults to %(default)s, so a "
                        "short run wants --epochs-decay 0.")
    p.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    p.add_argument("--lr", type=float, default=config.LR)
    p.add_argument("--lambda-l1", type=float, default=config.LAMBDA_L1)
    p.add_argument("--gan-weight", type=float, default=1.0,
                   help="weight on the adversarial term; 0 trains L1-only and "
                        "skips the discriminator update entirely")
    p.add_argument("--workers", type=int, default=config.NUM_WORKERS)
    p.add_argument("--no-augment", action="store_true", help="disable random jitter + flip")
    p.add_argument("--sat-interp", default=config.SATELLITE_INTERP,
                   choices=["nearest", "bilinear", "bicubic", "lanczos"])
    p.add_argument("--map-interp", default=config.MAP_INTERP,
                   choices=["nearest", "bilinear", "bicubic", "lanczos"])
    p.add_argument("--amp", action="store_true", default=config.USE_AMP)
    p.add_argument("--no-amp", dest="amp", action="store_false")
    p.add_argument("--seed", type=int, default=config.SPLIT_SEED)
    p.add_argument("--tag", default=None, help="name for output files")
    p.add_argument("--eval-every", type=int, default=5)
    p.add_argument("--eval-batches", type=int, default=None,
                   help="cap validation batches (useful for quick ablations)")
    p.add_argument("--save-every", type=int, default=config.SAVE_EVERY)
    p.add_argument("--limit-train", type=int, default=None, help="debug: cap training files")
    p.add_argument("--limit-val", type=int, default=None, help="debug: cap validation files")
    return p


if __name__ == "__main__":
    train(build_parser().parse_args())
