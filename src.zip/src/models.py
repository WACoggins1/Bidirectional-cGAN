"""
Generator and discriminator architectures, plus the candidates we compare
against for the model-selection section of the midterm.

Every architecture here is switchable from the command line so the comparison
in the deck comes from measured runs rather than assertion:

  Generators
    unet          U-Net with skip connections            (the selection)
    unet_noskip   identical capacity, skips removed      (isolates skips)
    resnet9       CycleGAN-style ResNet generator        (heavier alternative)

  Discriminators
    pixel         1x1 receptive field  (PixelGAN)
    patch70       70x70 receptive field (PatchGAN, default)
    image         286x286, whole-image (ImageGAN)
"""
from __future__ import annotations

import functools

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Initialisation -- Isola et al. use N(0, 0.02)
# ---------------------------------------------------------------------------
def init_weights(net: nn.Module, gain: float = 0.02) -> nn.Module:
    def fn(m):
        name = m.__class__.__name__
        if hasattr(m, "weight") and ("Conv" in name or "Linear" in name):
            nn.init.normal_(m.weight.data, 0.0, gain)
            if getattr(m, "bias", None) is not None:
                nn.init.constant_(m.bias.data, 0.0)
        elif "BatchNorm2d" in name:
            nn.init.normal_(m.weight.data, 1.0, gain)
            nn.init.constant_(m.bias.data, 0.0)
    net.apply(fn)
    return net


# ---------------------------------------------------------------------------
# U-Net generator
# ---------------------------------------------------------------------------
class UnetSkipBlock(nn.Module):
    """
    One nested level of the U-Net.

    `use_skip=False` keeps the exact same conv stack but returns only the
    decoder output, so the no-skip ablation differs from the baseline in
    connectivity alone and not in parameter count of the conv layers.
    """

    def __init__(self, outer_nc: int, inner_nc: int, input_nc: int | None = None,
                 submodule: nn.Module | None = None, outermost: bool = False,
                 innermost: bool = False, norm_layer=nn.BatchNorm2d,
                 use_dropout: bool = False, use_skip: bool = True):
        super().__init__()
        self.outermost = outermost
        self.use_skip = use_skip and not outermost
        use_bias = norm_layer == nn.InstanceNorm2d
        if input_nc is None:
            input_nc = outer_nc

        downconv = nn.Conv2d(input_nc, inner_nc, 4, stride=2, padding=1, bias=use_bias)
        downrelu = nn.LeakyReLU(0.2, True)
        downnorm = norm_layer(inner_nc)
        uprelu = nn.ReLU(True)
        upnorm = norm_layer(outer_nc)

        if outermost:
            # Decoder input doubles only when the submodule passes skips up.
            up_in = inner_nc * 2 if (submodule is not None and getattr(submodule, "use_skip", False)) else inner_nc
            upconv = nn.ConvTranspose2d(up_in, outer_nc, 4, stride=2, padding=1)
            down = [downconv]
            up = [uprelu, upconv, nn.Tanh()]
            model = down + ([submodule] if submodule else []) + up
        elif innermost:
            upconv = nn.ConvTranspose2d(inner_nc, outer_nc, 4, stride=2, padding=1, bias=use_bias)
            down = [downrelu, downconv]
            up = [uprelu, upconv, upnorm]
            model = down + up
        else:
            up_in = inner_nc * 2 if getattr(submodule, "use_skip", False) else inner_nc
            upconv = nn.ConvTranspose2d(up_in, outer_nc, 4, stride=2, padding=1, bias=use_bias)
            down = [downrelu, downconv, downnorm]
            up = [uprelu, upconv, upnorm]
            model = down + [submodule] + up + ([nn.Dropout(0.5)] if use_dropout else [])

        self.model = nn.Sequential(*model)

    def forward(self, x):
        out = self.model(x)
        if self.outermost:
            return out
        if self.use_skip:
            return torch.cat([x, out], dim=1)
        return out


class UnetGenerator(nn.Module):
    """
    Standard 8-down/8-up U-Net for 256x256 input (Isola et al., 2017).

    use_skip=False yields the encoder-decoder ablation: same depth and width,
    no skip connections, so any quality gap is attributable to the skips.
    """

    def __init__(self, input_nc: int = 3, output_nc: int = 3, num_downs: int = 8,
                 ngf: int = 64, norm_layer=nn.BatchNorm2d, use_dropout: bool = True,
                 use_skip: bool = True):
        super().__init__()
        block = UnetSkipBlock(ngf * 8, ngf * 8, submodule=None, innermost=True,
                              norm_layer=norm_layer, use_skip=use_skip)
        for _ in range(num_downs - 5):
            block = UnetSkipBlock(ngf * 8, ngf * 8, submodule=block,
                                  norm_layer=norm_layer, use_dropout=use_dropout,
                                  use_skip=use_skip)
        for mult in (4, 2, 1):
            block = UnetSkipBlock(ngf * mult, ngf * mult * 2, submodule=block,
                                  norm_layer=norm_layer, use_skip=use_skip)
        self.model = UnetSkipBlock(output_nc, ngf, input_nc=input_nc, submodule=block,
                                   outermost=True, norm_layer=norm_layer)

    def forward(self, x):
        return self.model(x)


# ---------------------------------------------------------------------------
# ResNet generator (CycleGAN-style) -- heavier alternative candidate
# ---------------------------------------------------------------------------
class ResnetBlock(nn.Module):
    def __init__(self, dim: int, norm_layer, use_bias: bool):
        super().__init__()
        self.block = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(dim, dim, 3, bias=use_bias), norm_layer(dim), nn.ReLU(True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(dim, dim, 3, bias=use_bias), norm_layer(dim),
        )

    def forward(self, x):
        return x + self.block(x)


class ResnetGenerator(nn.Module):
    def __init__(self, input_nc: int = 3, output_nc: int = 3, ngf: int = 64,
                 n_blocks: int = 9, norm_layer=nn.BatchNorm2d):
        super().__init__()
        use_bias = norm_layer == nn.InstanceNorm2d
        layers = [nn.ReflectionPad2d(3),
                  nn.Conv2d(input_nc, ngf, 7, bias=use_bias), norm_layer(ngf), nn.ReLU(True)]
        for i in range(2):                       # downsample
            mult = 2 ** i
            layers += [nn.Conv2d(ngf * mult, ngf * mult * 2, 3, stride=2, padding=1, bias=use_bias),
                       norm_layer(ngf * mult * 2), nn.ReLU(True)]
        for _ in range(n_blocks):
            layers += [ResnetBlock(ngf * 4, norm_layer, use_bias)]
        for i in range(2):                       # upsample
            mult = 2 ** (2 - i)                  # 4 -> 2: 256->128, 128->64
            layers += [nn.ConvTranspose2d(ngf * mult, ngf * mult // 2, 3, stride=2,
                                          padding=1, output_padding=1, bias=use_bias),
                       norm_layer(ngf * mult // 2), nn.ReLU(True)]
        layers += [nn.ReflectionPad2d(3), nn.Conv2d(ngf, output_nc, 7), nn.Tanh()]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


# ---------------------------------------------------------------------------
# Discriminators
# ---------------------------------------------------------------------------
class NLayerDiscriminator(nn.Module):
    """
    PatchGAN. n_layers controls the receptive field:
        n_layers=0 -> 1x1    (PixelGAN)
        n_layers=3 -> 70x70  (default PatchGAN)
        n_layers=5 -> 286x286 (effectively whole-image)
    """

    def __init__(self, input_nc: int = 6, ndf: int = 64, n_layers: int = 3,
                 norm_layer=nn.BatchNorm2d):
        super().__init__()
        use_bias = norm_layer == nn.InstanceNorm2d

        if n_layers == 0:                               # PixelGAN
            self.model = nn.Sequential(
                nn.Conv2d(input_nc, ndf, 1), nn.LeakyReLU(0.2, True),
                nn.Conv2d(ndf, ndf * 2, 1, bias=use_bias), norm_layer(ndf * 2),
                nn.LeakyReLU(0.2, True),
                nn.Conv2d(ndf * 2, 1, 1),
            )
            return

        layers = [nn.Conv2d(input_nc, ndf, 4, stride=2, padding=1), nn.LeakyReLU(0.2, True)]
        mult = 1
        for n in range(1, n_layers):
            prev, mult = mult, min(2 ** n, 8)
            layers += [nn.Conv2d(ndf * prev, ndf * mult, 4, stride=2, padding=1, bias=use_bias),
                       norm_layer(ndf * mult), nn.LeakyReLU(0.2, True)]
        prev, mult = mult, min(2 ** n_layers, 8)
        layers += [nn.Conv2d(ndf * prev, ndf * mult, 4, stride=1, padding=1, bias=use_bias),
                   norm_layer(ndf * mult), nn.LeakyReLU(0.2, True),
                   nn.Conv2d(ndf * mult, 1, 4, stride=1, padding=1)]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


# ---------------------------------------------------------------------------
# Factories
# ---------------------------------------------------------------------------
GENERATORS = ("unet", "unet_noskip", "resnet9")
DISCRIMINATORS = {"pixel": 0, "patch70": 3, "image": 5}


def build_generator(name: str = "unet", input_nc: int = 3, output_nc: int = 3,
                    ngf: int = 64) -> nn.Module:
    if name == "unet":
        net = UnetGenerator(input_nc, output_nc, ngf=ngf, use_skip=True)
    elif name == "unet_noskip":
        net = UnetGenerator(input_nc, output_nc, ngf=ngf, use_skip=False)
    elif name == "resnet9":
        net = ResnetGenerator(input_nc, output_nc, ngf=ngf, n_blocks=9)
    else:
        raise ValueError(f"unknown generator '{name}', expected one of {GENERATORS}")
    return init_weights(net)


def build_discriminator(name: str = "patch70", input_nc: int = 6, ndf: int = 64) -> nn.Module:
    if name not in DISCRIMINATORS:
        raise ValueError(f"unknown discriminator '{name}', expected one of {tuple(DISCRIMINATORS)}")
    return init_weights(NLayerDiscriminator(input_nc, ndf, n_layers=DISCRIMINATORS[name]))


def count_parameters(net: nn.Module) -> int:
    return sum(p.numel() for p in net.parameters() if p.requires_grad)


def receptive_field(name: str) -> int:
    """Theoretical receptive field in pixels, for the discriminator table."""
    return {"pixel": 1, "patch70": 70, "image": 286}[name]


class GANLoss(nn.Module):
    """BCE-with-logits against soft real/fake targets."""

    def __init__(self, target_real: float = 1.0, target_fake: float = 0.0):
        super().__init__()
        self.register_buffer("real_label", torch.tensor(target_real))
        self.register_buffer("fake_label", torch.tensor(target_fake))
        self.loss = nn.BCEWithLogitsLoss()

    def forward(self, pred: torch.Tensor, target_is_real: bool) -> torch.Tensor:
        target = (self.real_label if target_is_real else self.fake_label)
        return self.loss(pred, target.expand_as(pred).to(pred.device))
