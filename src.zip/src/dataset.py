"""
Dataset and splitting logic.

Two things here matter for the midterm rubric:

1. Transform ordering. The split is decided on FILE IDENTITY before any
   transform is constructed. Augmentation is attached to the training split
   only; val and test get the deterministic path. Nothing is fit on val/test.

2. Stratification. This is a generative task, so there are no class labels to
   stratify on. Instead we stratify on scene composition -- the fraction of
   each tile occupied by road / building / vegetation / water colours in the
   map domain -- so that dense-urban and green-dominant tiles appear in the
   same proportion in every split. compute_composition_features() produces
   those features; assign_strata() bins them.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

import config

# PIL resampling filters by name, so config can stay stringly-typed.
RESAMPLE = {
    "nearest": Image.NEAREST,
    "bilinear": Image.BILINEAR,
    "bicubic": Image.BICUBIC,
    "lanczos": Image.LANCZOS,
}


# ---------------------------------------------------------------------------
# Raw file handling
# ---------------------------------------------------------------------------
def list_pairs(split_dir: Path) -> list[Path]:
    """All paired JPEGs in a directory, sorted for reproducibility."""
    files = sorted(
        p for p in Path(split_dir).iterdir()
        if p.suffix.lower() in {".jpg", ".jpeg", ".png"}
    )
    if not files:
        raise FileNotFoundError(
            f"No images found in {split_dir}. Check config.DATA_ROOT -- it "
            f"should contain train/ and val/ subdirectories of 1200x600 JPEGs."
        )
    return files


def split_pair(img: Image.Image) -> tuple[Image.Image, Image.Image]:
    """
    Split one 1200x600 source image into (satellite, map).

    Honours config.SATELLITE_SIDE so a mis-ordered dataset is a one-line fix
    rather than a bug hunt.
    """
    w, h = img.size
    half = w // 2
    left = img.crop((0, 0, half, h))
    right = img.crop((half, 0, w, h))
    if config.SATELLITE_SIDE == "left":
        return left, right
    return right, left


def load_pair(path: Path) -> tuple[Image.Image, Image.Image]:
    with Image.open(path) as im:
        im = im.convert("RGB")
        return split_pair(im)


# ---------------------------------------------------------------------------
# Composition features -> strata
# ---------------------------------------------------------------------------
# Approximate anchors for the Google Maps cartographic palette. These are
# refined empirically by scripts/01_dataset_stats.py, which runs k-means on
# real map pixels and prints the true centroids; update these if the printed
# centroids differ materially.
PALETTE_ANCHORS = {
    "road_major":  (255, 255, 255),
    "road_minor":  (253, 245, 211),
    "background":  (242, 239, 233),
    "building":    (222, 215, 205),
    "vegetation":  (200, 224, 185),
    "water":       (170, 211, 223),
}


def composition_vector(map_img: Image.Image, sample_size: int = 128) -> dict[str, float]:
    """
    Fraction of a map tile nearest to each palette anchor.

    Downsamples with NEAREST first so the measurement is not contaminated by
    interpolated colours that do not exist in the source tile.
    """
    small = map_img.resize((sample_size, sample_size), Image.NEAREST)
    arr = np.asarray(small, dtype=np.float32).reshape(-1, 3)

    names = list(PALETTE_ANCHORS)
    anchors = np.array([PALETTE_ANCHORS[n] for n in names], dtype=np.float32)

    # (N, 1, 3) - (1, K, 3) -> (N, K) squared distances
    d2 = ((arr[:, None, :] - anchors[None, :, :]) ** 2).sum(axis=2)
    nearest = d2.argmin(axis=1)

    counts = np.bincount(nearest, minlength=len(names)).astype(np.float64)
    fracs = counts / counts.sum()
    return {n: float(f) for n, f in zip(names, fracs)}


def compute_composition_features(paths: list[Path], sample_size: int = 128,
                                 progress: bool = True) -> tuple[np.ndarray, list[str]]:
    """Composition vectors for a list of paired files. Returns (N, K) array."""
    rows, names = [], list(PALETTE_ANCHORS)
    for i, p in enumerate(paths):
        if progress and i % 200 == 0:
            print(f"    composition {i}/{len(paths)}", flush=True)
        _, map_img = load_pair(p)
        cv = composition_vector(map_img, sample_size)
        rows.append([cv[n] for n in names])
    return np.array(rows, dtype=np.float64), names


def assign_strata(features: np.ndarray, n_strata: int = config.N_STRATA,
                  seed: int = config.SPLIT_SEED) -> np.ndarray:
    """
    Bin tiles into composition strata via k-means.

    Falls back to quantile bins on the built-up fraction if sklearn is absent,
    so the pipeline never hard-depends on it.
    """
    try:
        from sklearn.cluster import KMeans
        km = KMeans(n_clusters=n_strata, random_state=seed, n_init=10)
        return km.fit_predict(features)
    except ImportError:
        built_up = features[:, :4].sum(axis=1)
        edges = np.quantile(built_up, np.linspace(0, 1, n_strata + 1)[1:-1])
        return np.digitize(built_up, edges)


def stratified_split(paths: list[Path], strata: np.ndarray, frac: float,
                     seed: int = config.SPLIT_SEED) -> tuple[list[Path], list[Path]]:
    """
    Split paths into (A, B) with A holding `frac` of each stratum.

    Splitting within each stratum -- rather than globally -- is what keeps the
    composition mix identical across splits.
    """
    rng = random.Random(seed)
    a, b = [], []
    for s in np.unique(strata):
        members = [p for p, m in zip(paths, strata) if m == s]
        rng.shuffle(members)
        cut = int(round(len(members) * frac))
        a.extend(members[:cut])
        b.extend(members[cut:])
    a.sort()
    b.sort()
    return a, b


# ---------------------------------------------------------------------------
# Split manifest
# ---------------------------------------------------------------------------
@dataclass
class SplitManifest:
    """A written record of exactly which file landed in which split."""
    train: list[str]
    val: list[str]
    test: list[str]
    seed: int
    n_strata: int
    notes: str = ""

    def save(self, path: Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls, path: Path) -> "SplitManifest":
        return cls(**json.loads(Path(path).read_text()))

    @property
    def sizes(self) -> dict[str, int]:
        return {"train": len(self.train), "val": len(self.val), "test": len(self.test)}


def build_splits(data_root: Path = config.DATA_ROOT,
                 seed: int = config.SPLIT_SEED,
                 save_to: Path | None = None) -> SplitManifest:
    """
    Produce the train/val/test manifest.

    The author-provided train/ directory is used verbatim so our numbers stay
    comparable with published results. The provided val/ directory is split in
    half -- stratified by composition -- into our val and test sets.
    """
    train_paths = list_pairs(Path(data_root) / "train")
    provided_val = list_pairs(Path(data_root) / "val")

    print(f"  computing composition features for {len(provided_val)} val tiles...")
    feats, _ = compute_composition_features(provided_val)
    strata = assign_strata(feats, seed=seed)

    val_paths, test_paths = stratified_split(
        provided_val, strata, config.VAL_FRACTION_OF_PROVIDED_VAL, seed
    )

    manifest = SplitManifest(
        train=[str(p) for p in train_paths],
        val=[str(p) for p in val_paths],
        test=[str(p) for p in test_paths],
        seed=seed,
        n_strata=config.N_STRATA,
        notes=(
            "train/ used verbatim from the dataset authors for comparability "
            "with published baselines. The provided val/ directory was split "
            "50/50 into val and test, stratified on map-composition k-means "
            "strata so the urban/green/water mix matches across splits."
        ),
    )
    if save_to:
        manifest.save(save_to)
    return manifest


# ---------------------------------------------------------------------------
# Torch dataset
# ---------------------------------------------------------------------------
class MapsDataset(Dataset):
    """
    Paired satellite/map tiles.

    Augmentation is only ever constructed when augment=True, which is passed
    for the training split alone. Val and test take the deterministic branch:
    direct resize to CROP_SIZE, no jitter, no flip.
    """

    def __init__(self, paths: list[str] | list[Path], direction: str = config.DEFAULT_DIRECTION,
                 augment: bool = False, crop_size: int = config.CROP_SIZE,
                 load_size: int = config.LOAD_SIZE,
                 sat_interp: str = config.SATELLITE_INTERP,
                 map_interp: str = config.MAP_INTERP,
                 seed: int | None = None):
        if direction not in config.DIRECTIONS:
            raise ValueError(f"direction must be one of {config.DIRECTIONS}")
        self.paths = [Path(p) for p in paths]
        self.direction = direction
        self.augment = augment
        self.crop_size = crop_size
        self.load_size = load_size
        self.sat_interp = sat_interp
        self.map_interp = map_interp
        self._rng = random.Random(seed)

    def __len__(self) -> int:
        return len(self.paths)

    @staticmethod
    def _to_tensor(img: Image.Image) -> torch.Tensor:
        arr = np.asarray(img, dtype=np.float32) / 255.0          # [0, 1]
        t = torch.from_numpy(arr).permute(2, 0, 1)               # CHW
        return (t - config.NORM_MEAN) / config.NORM_STD          # [-1, 1]

    def __getitem__(self, idx: int) -> dict:
        path = self.paths[idx]
        sat, mp = load_pair(path)

        sat_f = RESAMPLE[self.sat_interp]
        map_f = RESAMPLE[self.map_interp]

        if self.augment:
            # Random jitter: upsize then crop the SAME window from both halves
            # so the pair stays pixel-aligned.
            sat = sat.resize((self.load_size, self.load_size), sat_f)
            mp = mp.resize((self.load_size, self.load_size), map_f)

            max_off = self.load_size - self.crop_size
            x = self._rng.randint(0, max_off)
            y = self._rng.randint(0, max_off)
            box = (x, y, x + self.crop_size, y + self.crop_size)
            sat, mp = sat.crop(box), mp.crop(box)

            if self._rng.random() < 0.5:
                sat = sat.transpose(Image.FLIP_LEFT_RIGHT)
                mp = mp.transpose(Image.FLIP_LEFT_RIGHT)
        else:
            sat = sat.resize((self.crop_size, self.crop_size), sat_f)
            mp = mp.resize((self.crop_size, self.crop_size), map_f)

        sat_t, map_t = self._to_tensor(sat), self._to_tensor(mp)

        if self.direction == "sat2map":
            src, tgt = sat_t, map_t
        else:
            src, tgt = map_t, sat_t

        return {"src": src, "tgt": tgt, "path": str(path)}


def denormalize(t: torch.Tensor) -> np.ndarray:
    """[-1,1] CHW tensor -> uint8 HWC array, for metrics and figures."""
    t = t.detach().cpu().float()
    t = t * config.NORM_STD + config.NORM_MEAN
    t = t.clamp(0, 1)
    if t.dim() == 4:
        return (t.permute(0, 2, 3, 1).numpy() * 255).round().astype(np.uint8)
    return (t.permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
